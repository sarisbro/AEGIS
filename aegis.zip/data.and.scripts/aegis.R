# Detect epistatsis with a maximum tree
# written by Jean Claude Nshogozabahizi
# supervisor: Stéphane Aris-Brosou

# R packages needed for analysis

library(ape)
library(seqinr)
library(doMC)
library(foreach)
library(locfit)


# Register how many cores are needed for parallel backend
# for exapmle: 4 cores
registerDoMC(cores=4)

# choose where to run this script:
#     - Local computer: 0
#     - Computer cluster: 1
run_on_cluster <- 0

curdir <- getwd() # pathway to file containing all R packages and sequence alignments needed for epistatic detection analysis
if(run_on_cluster){
	curdir <- paste("/export", curdir,sep="") #export: file containing all R            packages needed on Computer cluster
}

###################################################
# read amino acid sequence alignments
# for example: Adam03M2.fasta of Adam03M2 data set
###################################################
aln_file_name <- "Adam03M2.fasta"
aln <- read.fasta(aln_file_name, seqtype = "AA") #read sequence alignment in fasta format
aln_len <- length(aln) # number of sequences in alignment

#################################################################################################################################
# Estimate maximum likelihood (ML) and bootstrapped trees
#################################################################################################################################

########################################################
# I. Estimate ML tree (AA data)
#########################################################
if(run_on_cluster){
	system(paste("/export/apps/FastTree -gamma ", aln_file_name," > MLE.trees",sep=""))
}else{
	system(paste("fasttree -gamma ", aln_file_name," > MLE.trees",sep=""))
}
mle_tr <- read.tree("MLE.trees")
     # FastTree program to estimate tree with gamma model to account for among-site rate variation


########################
# save current analysis
#######################
save.image("step1.RData")

################################################################
# I.A. Treat ML tree
################################################################

tr <- mle_tr
tr_rooted_nooutgroup <- tr


# extracts dates
tr$tip.label
dates_tr <- substr(tr$tip.label, nchar(tr$tip.label)-3, nchar(tr$tip.label))
for(j in 1:length(dates_tr)){ #write year in four numbers
    if(as.numeric(substr(dates_tr[j], 3, 4)) < 67){
        dates_tr[j] <- sub("\\d\\/", "20", dates_tr[j])
    }else{
        dates_tr[j] <- sub("\\d\\/", "19", dates_tr[j])
    }
}
dates_tr <- as.numeric(dates_tr)


# root tree with earliest sequence
min(dates_tr)
dates_tr == min(dates_tr)
which(dates_tr == min(dates_tr))
tr$tip.label[which(dates_tr == min(dates_tr))]
tr_rooted_ori <- root(tr,tr$tip.label[which(dates_tr == min(dates_tr))][1],resolve.root=T)

# BayesTraits requires not to have node.label in tree
tr_rooted_ori$node.label <- NULL
# correct negative edge.lengh
tr_rooted_ori$edge.length[tr_rooted_ori$edge.length<.0001] <-.0001

write.nexus(tr_rooted_ori, file="ml_rooted.trees") #Bayestraits read a tree in nexus format

# save rooted tree
save.image("step2.RData")

##########################################################################
#I.B. Recode amino acid sequences as ancestoral  and derived states
##########################################################################

# verify if phylogenetic tip.labels are the same as alignment sequence names

length(attributes(aln)$names) == length(tr_rooted_ori$tip.label)  # must be TRUE


#extract oldest sequences
# in Adam03M2.fasta: the date of oldest sequences is 1968

treeOut <-substr(grep(pattern = "1968", x=getAnnot(aln), value= TRUE),2,nchar(grep(pattern = "1968", x=getAnnot(aln), value= TRUE)))
seqLen <- length(aln[[1]])

alnMat <- matrix(NA,ncol=(length(aln[[1]])), nrow=length(aln), dimnames=list(c(getAnnot(aln)),seq(1:length(aln[[1]]))))

for (i in 1:nrow(alnMat)){
    for (j in 1:ncol(alnMat)){
        alnMat[i,j] <- aln[[i]][j]
    }
}
save.image("treeout.RData")


nSeq <- length(tr$tip.label)
# Here we capture the labels as an object that can later define which labels the tree contains
tLabels <- tr$tip.label

# definition
traitMat <- matrix(NA,nrow = nSeq, ncol = seqLen)


#nOut <- length(treeOut)

tRows <- NULL
for (x in 1:length(treeOut)){
    tRows <- c(tRows,which(substr(attr(alnMat, which="dimnames")[[1]],2,nchar(attr(alnMat, which="dimnames")[[1]])) == treeOut[x]))
}

# We initialize our AAVec for comparison downstream
AAVec <- c("K", "R", "A", "N", "C", "Q", "G", "H", "I", "L", "M", "F", "P", "S", "T", "W", "Y", "V", "D", "E")
# Here we go through a majority rule means of defining what is an outgroup sequence.  Where knowing the number of sequences
# which we consider to be an outgroup we look at the amino acid present at a given site, find which amino acids are present
# in at least 50% of the outgroup sequences and then define those as being ancestral.
for (j in 1:seqLen){
    tLen <- length(attr(table(alnMat[tRows,j]), which="dimnames")[[1]])
    tSum <- 0
    for (x in 1:tLen){
        tSum <- tSum + table(alnMat[tRows,j])[[x]]
    }
    
    # We define an outgroup AA as one which is at least 50% present
    # This outgroup is defined as consensus sequence
    # 0 is assigned as  ancestoral state at each site along sequence
    # 1 is assigned as  derived state at each site along sequence
    AA_outVec <- attr(which(table(alnMat[tRows,j]) >= tSum * 0.5), which="names")
    for (i in 1:nSeq){
        # If there is a special character such as a gap "-" then we assign a value of 2
        if (toupper(alnMat[i,j]) == "-") { traitMat[i,j] <- 2 }
        # If the AA in alnMat[i,j] does not match our outgroup AAs this is derived = 0
        else if (length(intersect(toupper(alnMat[i,j]),AA_outVec)) == 0) {traitMat[i,j] <- 0}
        # If the AA in alnMat[j,i] does match at least one of our outgroup AAs it is outgroup = 1
        else if (length(intersect(toupper(alnMat[i,j]),AA_outVec)) > 0) {traitMat[i,j] <- 1}
    }
}

traitMat

myres1 <- traitMat

# length of AA sequence
seqlen <- length(aln[[1]])
# find number of sequences in aln
nseq <- length(dates_tr)



# matrix simplification
all_identical <- function(v) all(sapply( as.list(v[-1]),
FUN=function(z) {identical(z, v[1])}))
myres2 <- matrix(nrow = nseq, ncol = seqlen)
siteID <- list()

nb_site_patterns <- 0
for(j in 1:seqlen){
	if(!(all_identical(myres1[,j]))){ # then this site is polymorphic
		# test if site pattern is a new one
		if(j > 1){
			# first we need to parse recoded site patterns to test if at least one is new
			nb_nonidentical_site_patterns <- 0
			for(i in 1:nb_site_patterns){
				if(sum(abs(myres2[,i] - myres1[,j]),na.rm=T) != 0){ # then we have a new site pattern
					nb_nonidentical_site_patterns <- nb_nonidentical_site_patterns + 1
				}
			}
			# if there are fewer nb_nonidentical_site_patterns than nb_site_patterns
			# then the current pattern already exists
			if(nb_nonidentical_site_patterns < nb_site_patterns){
				for(i in 1:nb_site_patterns){
					if(sum(abs(myres2[,i] - myres1[,j]),na.rm=T) == 0){
						nb_site_patterns <- nb_site_patterns + 1
						myres2[,i] <- myres1[,j]
						siteID[[i]] <- c(siteID[[i]],j)
						
					}
					break
				}
			}else{
				# otherwise, it is a new site pattern
				nb_site_patterns <- nb_site_patterns + 1
				myres2[,nb_site_patterns] <- myres1[,j]
				siteID[[nb_site_patterns]] <- j # indexing the sites
			}
		}else{ # if(j > 1)
			# the first site in myres2 is always a new site pattern!
			nb_site_patterns <- 1
			myres2[,nb_site_patterns] <- myres1[,j]
		    siteID[[nb_site_patterns]] <- 1
		}
	}
	
}
myres2
siteID

myres3 <- myres2[,1:length(siteID)]
myres3
# write as characters
myres3_char <- matrix(nrow = nseq, ncol = length(siteID))
for(j in 1: length(siteID)){
     for(i in 1:nseq){
        if(myres3[i,j] == 2){
            myres3_char[i,j] <- "-"
        }else{
            myres3_char[i,j] <- as.character(myres3[i,j])
        }
    }
}
myres3_char

#save matrix containing all polymeriphic sites to be analyzed by Bayestraits
save.image("step3.RData")

#################################################################################
# I.C.Bayestraits analysis
##################################################################################

# initialize object containing results
lkl_res <- matrix(nr=1,nc=6)
# starts the clock
ptm <- proc.time()
# start the loops; only inner loop forks processes
for(i in 2:length(siteID)){
    lkl_res_tmp <- foreach(j = 1:(i-1),.combine='rbind') %dopar% {
        print(paste("Now doing pair of sites ",j," / ",i,sep=""))
        sp_names <- attributes(aln)$names
        col1 <- col1bis <- myres3_char[,j]
        col2 <- col2bis <- myres3_char[,i]
        
        # remove cols w/ "-"
        col1bis[which(col2bis=="-")] <- NA
        col2bis[which(col2bis=="-")] <- NA
        col2bis[which(col1bis=="-")] <- NA
        col1bis[which(col1bis=="-")] <- NA
        if(!identical(col1bis,col2bis)){
            trait_data <- data.frame(sp_names, col1, col2)
            colnames(trait_data) <- NULL
            write.table(trait_data, paste("traits.",i,".",j,".txt",sep=""),quote=F,row.names=F)
            
            # run BayesTraits under the dependent and indep models
            if(run_on_cluster){
	            system(paste("/export/apps/BayesTraits ",curdir,"/ml_rooted.trees ",paste(curdir,"/traits.",i,".",j,".txt",sep="")," < ", curdir,"/InputBT_ML_indep.txt > ",paste(curdir,"/traits_res_indep.",i,".",j,".txt",sep=""),sep=""))
	            system(paste("/export/apps/BayesTraits ",curdir,"/ml_rooted.trees ",paste(curdir,"/traits.",i,".",j,".txt",sep="")," < ", curdir,"/InputBT_ML_dep.txt > ",paste(curdir,"/traits_res_dep.",i,".",j,".txt",sep=""),sep=""))
            }else{
	            system(paste("BayesTraits ",curdir,"/ml_rooted.trees ",paste(curdir,"/traits.",i,".",j,".txt",sep="")," < ", curdir,"/InputBT_ML_indep.txt > ",paste(curdir,"/traits_res_indep.",i,".",j,".txt",sep=""),sep=""))
	            system(paste("BayesTraits ",curdir,"/ml_rooted.trees ",paste(curdir,"/traits.",i,".",j,".txt",sep="")," < ", curdir,"/InputBT_ML_dep.txt > ",paste(curdir,"/traits_res_dep.",i,".",j,".txt",sep=""),sep=""))
            }
            
            # extract likelihood values
            system(paste("wc -l traits_res_indep.",i,".",j,".txt > wc",i,".",j,".txt",sep=""))
            wc <- read.table(paste("wc",i,".",j,".txt",sep=""))
            res_indep <- read.table(paste("traits_res_indep.",i,".",j,".txt",sep=""),header=F,fill=T,skip=as.numeric(wc[1]-1))
            system(paste("wc -l traits_res_dep.",i,".",j,".txt > wc",i,".",j,".txt",sep=""))
            wc <- read.table(paste("wc",i,".",j,".txt",sep=""))
            res_dep <- read.table(paste("traits_res_dep.",i,".",j,".txt",sep=""),header=F,fill=T,skip=as.numeric(wc[1]-1))
            
            # cleanup tmp files
            unlink(paste("traits_res_indep.",i,".",j,".txt",sep=""))
            unlink(paste("traits_res_dep.",i,".",j,".txt",sep=""))
            unlink(paste("traits.",i,".",j,".txt",sep=""))
            unlink(paste("traits.",i,".",j,".txt.log.txt",sep=""))
            unlink(paste("wc",i,".",j,".txt",sep=""))
            if((res_indep[,2] < 0) & (res_dep[,2] < 0)){
                test_stat <- 2 * abs(res_indep[,2] - res_dep[,2])
                # this should be the last instruction of the foreach loop
                return(c(j, i, res_indep[,2], res_dep[,2], test_stat, 1-pchisq(test_stat,4)))
            }
        }
    }
    # merge objects
    lkl_res <- rbind(lkl_res, lkl_res_tmp)
}
# save results generated by BayesTraits
save.image("Bayestraitsanalysis.RData")

####################################################################
## I.D. Analyze BayesTraits results
#####################################################################


# Stop the clock
time_par1 <- proc.time() - ptm
colnames(lkl_res) <- c("siteID_1","siteID_2","lkl_indep","lkl_dep","test_stat","pvalue")
lkl_res <- na.omit(lkl_res)
lkl_res <- data.frame(lkl_res)
#plot histogram of generated results
hist(-log(lkl_res$pvalue,10),100)

# FDR calculation, add actual site positions and sort by P-value
adj_p <- p.adjust(lkl_res$pvalue, "BH")


# correct siteID by grouping together all identical siteID


lkl_res_adj <- cbind(lkl_res, adj_p,0, 0)


for (j in 1:nrow(lkl_res_adj)){
	
    for( i in 1:ncol(myres1)){
        if (mean(myres1[, (siteID[[lkl_res_adj[j,1]]])]== myres1[,i])==1)
        
        {lkl_res_adj[j,8] <- paste(lkl_res_adj[j,8],i,sep=".")}
        
        if (mean(myres1[, (siteID[[lkl_res_adj[j,2]]])]== myres1[,i])==1)
        
        {lkl_res_adj[j,9] <- paste(lkl_res_adj[j,9],i,sep=".")}
    }
}

for (d in 1:nrow(lkl_res_adj)){lkl_res_adj[d,8] <- substr(lkl_res_adj[d,8],3,nchar(lkl_res_adj[d,8])); lkl_res_adj[d,9]<-substr(lkl_res_adj[d,9],3,nchar(lkl_res_adj[d,9])) }
colnames(lkl_res_adj) <- c(colnames(lkl_res), "pvalue_fdr", "site_1", "site_2")

# sort results by pvalue

lkl_res_adj_sorted <- lkl_res_adj[order(lkl_res_adj$pvalue),]

# write results to .csv file
write.csv(lkl_res_adj_sorted, "lkl_res_par2.csv", quote=F, row.names=F) # relocated and set row.names to "F"

#################################
# save this step
save.image("step4.RData")
##############################





##############################################################################################################################################################################################################################################

# II. Bootrapping analysis
#############################################################################################################################################################################################################################################

# II.A.Generates bootstrapped trees
##############################################################

# input number of bootstrap replicates
n_boot <- 100

# estimate BT and  save them as a list

boot_trees <- vector("list", n_boot)
for(i in 1:n_boot){
	y <- length(aln[[1]])
	boot1.samp <- unlist(sample(y, replace = T))
	boot_aln <- aln
	for(j in 1:aln_len){
		for(k in 1:y){
			boot_aln[[j]][k] <- aln[[j]][boot1.samp[k]]
		}
	}
	write.fasta(sequences = boot_aln, names = names(boot_aln), nbchar = 80, file.out = "boot1.fasta")
	if(run_on_cluster){
		system("/export/apps/FastTree -gamma  boot1.fasta > boot1.trees")
	}else{
		system("fasttree -gamma  boot1.fasta > boot1.trees")
	}
	boot_trees[[i]] <- read.tree("boot1.trees")
	unlink("boot1.fasta"); unlink("boot1.trees")
}
class(boot_trees) <- "multiPhylo"
write.tree(boot_trees, "boot.trees")

#######################################################################
# II.B.Treat bootstrapped trees
##################################################################

tr <- boot_trees

tr_rooted_nooutgroup <- tr


for(i in 1:length(tr)){
    # extracts dates
    tr[[i]]$tip.label
    
    # correct year dates to four numbers
    dates_tr <- substr(tr[[i]]$tip.label, nchar(tr[[i]]$tip.label)-3, nchar(tr[[i]]$tip.label))
    for(j in 1:length(dates_tr)){
        if(as.numeric(substr(dates_tr[j], 3, 4)) < 67){
            dates_tr[j] <- sub("\\d\\/", "20", dates_tr[j])
        }else{
            dates_tr[j] <- sub("\\d\\/", "19", dates_tr[j])
        }
    }
    dates_tr <- as.numeric(dates_tr)
    
    
    # root tree with earliest sequence and eliminate them
    min(dates_tr)
    dates_tr == min(dates_tr)
    which(dates_tr == min(dates_tr))
    tr[[i]]$tip.label[which(dates_tr == min(dates_tr))]
    tr_rooted_ori_tmp <- root(tr[[i]],tr[[i]]$tip.label[which(dates_tr == min(dates_tr))][1],resolve.root=T)
     tr_rooted_ori_tmp <- multi2di(tr_rooted_ori_tmp)
    tr_rooted_ori_tmp$node.label <- NULL # required by BayesTraits (no support values)
    tr_rooted_ori_tmp$edge.length[tr_rooted_ori_tmp$edge.length<.0001] <-.0001
    
    
    
    tr_rooted_nooutgroup[[i]] <- tr_rooted_ori_tmp
} # end of for loop in i

for(i in 1:length(tr)){
    print(length(tr_rooted_nooutgroup[[i]]$tip.label))
}

#save trees
write.nexus(tr_rooted_nooutgroup, file = "ml_rooted_boot.trees")

save.image("step5.RData")


################################################
#II.C Bayestraits analysis of bootstrapping
################################################

# initialize object containing results
ncol <- 2 + 4 * length(tr)
lkl_res_boot <- matrix(nr=1,nc=ncol)
# starts the clock
ptm <- proc.time()
# start the loops; only inner loop forks processes
for(i in 2:length(siteID)){
    lkl_res_boot_tmp <- foreach(j = 1:(i-1),.combine='rbind') %dopar% {
        print(paste("Now doing pair of sites ",j," / ",i,sep=""))
        sp_names <- attributes(aln)$names
        col1 <- col1bis <- myres3_char[,j]
        col2 <- col2bis <- myres3_char[,i]
        
        # remove cols w/ "-"
        col1bis[which(col2bis=="-")] <- NA
        col2bis[which(col2bis=="-")] <- NA
        col2bis[which(col1bis=="-")] <- NA
        col1bis[which(col1bis=="-")] <- NA
        if(!identical(col1bis,col2bis)){
            trait_data <- data.frame(sp_names, col1, col2)
            colnames(trait_data) <- NULL
            write.table(trait_data, paste("boot_traits.",i,".",j,".txt",sep=""),quote=F,row.names=F)
            
            
            # run BayesTraits under the dependent and indep models
            if(run_on_cluster){
	            system(paste("/export/apps/BayesTraits ",curdir,"/ml_rooted_boot.trees ",paste(curdir,"/boot_traits.",i,".",j,".txt",sep="")," < ", curdir,"/InputBT_ML_indep.txt > ",paste(curdir,"/boot_traits_res_indep.",i,".",j,".txt",sep=""),sep=""))
	            system(paste("/export/apps/BayesTraits ",curdir,"/ml_rooted_boot.trees ",paste(curdir,"/boot_traits.",i,".",j,".txt",sep="")," < ", curdir,"/InputBT_ML_dep.txt > ",paste(curdir,"/boot_traits_res_dep.",i,".",j,".txt",sep=""),sep=""))
            }else{
	            system(paste("BayesTraits ",curdir,"/ml_rooted_boot.trees ",paste(curdir,"/boot_traits.",i,".",j,".txt",sep="")," < ", curdir,"/InputBT_ML_indep.txt > ",paste(curdir,"/boot_traits_res_indep.",i,".",j,".txt",sep=""),sep=""))
	            system(paste("BayesTraits ",curdir,"/ml_rooted_boot.trees ",paste(curdir,"/boot_traits.",i,".",j,".txt",sep="")," < ", curdir,"/InputBT_ML_dep.txt > ",paste(curdir,"/boot_traits_res_dep.",i,".",j,".txt",sep=""),sep=""))
            }
            
            # extract likelihood values
            system(paste("wc -l boot_traits_res_indep.",i,".",j,".txt > wc",i,".",j,".txt",sep=""))
            wc <- read.table(paste("wc",i,".",j,".txt",sep=""))
            res_indep <- read.table(paste("boot_traits_res_indep.",i,".",j,".txt",sep=""),header=F,fill=T,skip=as.numeric(wc[1]-n_boot))
            system(paste("wc -l boot_traits_res_dep.",i,".",j,".txt > wc",i,".",j,".txt",sep=""))
            wc <- read.table(paste("wc",i,".",j,".txt",sep=""))
            res_dep <- read.table(paste("boot_traits_res_dep.",i,".",j,".txt",sep=""),header=F,fill=T,skip=as.numeric(wc[1]-n_boot))
            
            # cleanup tmp files
            unlink(paste("boot_traits_res_indep.",i,".",j,".txt",sep=""))
            unlink(paste("boot_traits_res_dep.",i,".",j,".txt",sep=""))
            unlink(paste("boot_traits.",i,".",j,".txt",sep=""))
            unlink(paste("boot_traits.",i,".",j,".txt.log.txt",sep=""))
            unlink(paste("wc",i,".",j,".txt",sep=""))
            if((res_indep[,2] < 0) & (res_dep[,2] < 0)){
                test_stat <- 2 * abs(res_indep[,2] - res_dep[,2])
                # this should be the last instruction of the foreach loop
                return(c(j, i, res_indep[,2], res_dep[,2], test_stat, 1-pchisq(test_stat,4)))
            }
        }
    }
    # merge objects
    lkl_res_boot <- rbind(lkl_res_boot, lkl_res_boot_tmp)
    lkl_res_boot <- na.omit(lkl_res_boot)
}
# Stop the clock
time_par2 <- proc.time() - ptm

# save Bayestraits bootstrapping results
save.image("step6.RData")


##############################################
# II.D. read out res for boot trees #
#################################################

# structure of lkl_res_boot:
# S1	S2	res_indep[n_boot]	res_dep[n_boot]	test_stat[n_boot]	P[n_boot]
# over n(n-1)/2 rows [actually: fewer rows as some comparisons are not valid...]

#L <- length(siteID)
lkl_res_boot <- na.omit(lkl_res_boot)
nb_comp <- length(lkl_res_boot[,1]) #L * (L - 1) / 2
nrow_matres <- length(tr) * nb_comp
bootstrap_res <- matrix(nrow = nrow_matres, ncol = 7)
colnames(bootstrap_res) <- c("boot_tree","S1","S2","lkl1","lkl2","t","P")
for(j in 1:nb_comp){
	for(i in 1:n_boot){
	    bootstrap_res[(j-1) * n_boot + i, 1] <- i                		# trees
	    bootstrap_res[(j-1) * n_boot + i, 2] <- lkl_res_boot[j, 1]    	# siteID1
	    bootstrap_res[(j-1) * n_boot + i, 3] <- lkl_res_boot[j, 2]    	# siteID2
	    bootstrap_res[(j-1) * n_boot + i, 4] <- lkl_res_boot[j, 2 + i]
	    bootstrap_res[(j-1) * n_boot + i, 5] <- lkl_res_boot[j, 2 + n_boot + i]
	    bootstrap_res[(j-1) * n_boot + i, 6] <- lkl_res_boot[j, 2 + 2*n_boot + i]
	    bootstrap_res[(j-1) * n_boot + i, 7] <- lkl_res_boot[j, 2 + 3*n_boot + i]
	}
	
}
bootstrap_res

################################################
#II.E. Plotting results: P-values by pairs of sites #
################################################

# sort by S2
bootstrap_res_byS2 <- bootstrap_res[order(bootstrap_res[,3]),]
# sort by S1
bootstrap_res_byS1S2 <- bootstrap_res_byS2[order(bootstrap_res_byS2[,2]),]

pdf("P-distr.pdf",width=15,height=18)
par(oma = c(0,0,0,0), mar = c(4, 4, 1, 1), mfrow=c(5,4))
for(i in 2:length(siteID)){
	for(j in 1:(i-1)){
		if(length(bootstrap_res[(bootstrap_res[,2] == j) & (bootstrap_res[,3] == i),7]) > 0){
			# locfit can have some issues when n_boot too small, so use hist() for now
			if(n_boot < 50){
				hist(bootstrap_res[(bootstrap_res[,2] == j) & (bootstrap_res[,3] == i),7], xlab="P-value", main=paste("SiteIDs ",j," / ",i," (Positions in aln: ",siteID[[j]]," / ",siteID[[i]],")",sep=""), xlim=c(0,1))
			}else{
				plot( locfit( ~ lp(bootstrap_res[(bootstrap_res[,2] == j) & (bootstrap_res[,3] == i),7], nn=.4)), xlab="P-value", main=paste("SiteIDs ",j," / ",i," (Positions in aln: ",siteID[[j]]," / ",siteID[[i]],")",sep=""), xlim=c(0,1) )
			}
			pvalue <- lkl_res[(lkl_res[,1] == j) & (lkl_res[,2] == i),6]
			if(pvalue < 0.01){
				abline(v = pvalue, col="red", lwd=2, lty=2)
				print(paste("SiteIDs ",j," / ",i," (Positions in aln: ",siteID[[j]]," / ",siteID[[i]],")",sep=""))
			}else{
				abline(v = pvalue, col="blue", lwd=2, lty=2)
			}
		}
	}
}
dev.off()


#######################################################
# II.F. Plotting results: FDR value by pairs of sites #
######################################################

# sort results by bootstrap tree
bootstrap_resbytree <- bootstrap_res[order(bootstrap_res[,1]),]
bootstrap_FDR <- c()

for(i in 1:n_boot){
	pvalue <- bootstrap_resbytree[,7][bootstrap_resbytree[,1] == i]
	adj_p <- p.adjust(pvalue, "BH")
	bootstrap_FDR <- c(bootstrap_FDR, adj_p)
}

bootstrap_resbytree_FDR <- cbind(bootstrap_resbytree, bootstrap_FDR)

# write results of bootrapping with FRD calculated to .csv file
write.csv(bootstrap_resbytree_FDR, "bootstrap_resbytree_FDR.csv", quote=F, row.names=F) # relocated and set row.names to "F"


pdf("P-distr-FDR.pdf",width=15,height=18)
par(oma = c(0,0,0,0), mar = c(4, 4, 1, 1), mfrow=c(5,4))
for(i in 2:length(siteID)){
	for(j in 1:(i-1)){
		if(length(bootstrap_resbytree_FDR[(bootstrap_resbytree_FDR[,2] == j) & (bootstrap_resbytree_FDR[,3] == i),7]) > 0){
			# locfit can have some issues when n_boot too small, so use hist() for now
			if(n_boot < 50){
				hist(bootstrap_resbytree_FDR[(bootstrap_resbytree_FDR[,2] == j) & (bootstrap_resbytree_FDR[,3] == i),8], xlab="P-value", main=paste("SiteIDs ",j," / ",i," (Positions in aln: ",siteID[[j]]," / ",siteID[[i]],")",sep=""), xlim=c(0,1))
                }else{
				plot( locfit( ~ lp(bootstrap_resbytree_FDR[(bootstrap_resbytree_FDR[,2] == j) & (bootstrap_resbytree_FDR[,3] == i),8], nn=.4)), xlab="P-value", main=paste("SiteIDs ",j," / ",i," (Positions in aln: ",siteID[[j]]," / ",siteID[[i]],")",sep=""), xlim=c(0,1) )
			}
			pvalue_fdr <- lkl_res_adj_sorted[(lkl_res_adj_sorted[,1] == j) & (lkl_res_adj_sorted[,2] == i),7]
			if(pvalue_fdr < 0.01){
				abline(v = pvalue_fdr, col="red", lwd=2, lty=2)
				print(paste("SiteIDs ",j," / ",i," (Positions in aln: ",siteID[[j]]," / ",siteID[[i]],")",sep=""))
			}else{
				abline(v = pvalue_fdr, col="blue", lwd=2, lty=2)
			}
		}
	}
}
dev.off()




################################################################################################
# end
################################################################################################

save.image("step7.RData")
q(save="no")
# save the final jobß
################################################################################################
################################################################################################






