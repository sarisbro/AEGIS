# This is created to build all the necessary files and folders that will be part of my
# Simulation studies of epistatic recovery.  This version is created to generate the pair value combinations for
# each given job and then create a folder into which each will sit

# File naming structure follows N#_D# where n represents the length of the sequence and d the number of aligned seqeunces

# This is for MasterseqLen.v.1.r or later

# This is where all the new folders and files hould be created
wDir <- "/Users/Jdench/Desktop/SimulationRuns/PhaseSims/Pilots/seqLen/"
setwd(wDir)

# This reads in the Master Run Script file as an object to be later used
mFile <- readLines("MasterseqLen.v.1.r", -1)
# This is a simple object which defines the name of the Phase control files we want to copy
mControl <- "Sim_Phase_Control.sim"

################ These are optional parameters I can define here to more easily change whne writting files ###############
# This is an object for defining which system these jobs are intended to be run upon.
# 1 - Aleph, 2- HPCVL, anything else is interpreted as local machine, we use 0 as convention,
# Note local machine is null at present as my shell is not setup with a queue to be submitted toward.
# However, this script could still be used to create the folders
mSystem <- 2
# This is if we want to redefine the number of epistatic paris to be simulated
mPairs <- 1
# This is to help in defining the sequence length
mseqLen <- c(10,20,40,80,160,320,640,1280)
# This is to help in defining the number of replicates tob edone
mReps <- 10
# This variable used when multiple file pathing structures exist across varying systems
mAcc <- 1
##########################################################################################################################

# These are some objects that should not be varried to maintain consistency, any changes here must be recorded and affects how we may
# cycle through combinatory analysis later on.

# This is required to prevent R from taking 0.0005 and making it into scientific notation, which INDELible can't use
options("scipen"=100, "digits"=6)
# These are used to interpret certain objects that are factors in our simulation but do not follow a simple 
# arithmetic series.  Usefull since we loop through simple series' to create our names and files\folers.
mLen <- c("0.0005", "0.001", "0.005", "0.01", "0.05", "0.1","0.00025","0.00075", "0.0025", "0.0075", "0.025", "0.075")
# These are kept as multiples of two in order to facilitate all tree types to be simulated
# NOTE: With tree type3 (user data) these are not factors!
mDer <- c(16,32,64,128)
# this is no longer a factor being considered in our experimentation
mOut <- 0

# this is used to handle the location where R exists, not mSystem !=1,2 are null as we wouldn't submit jobs in this way
if (mSystem == 1){
    rDir <- "/export/apps/R-3.1.1/bin/"
}else if (mSystem == 2){
	if (mAcc == 1) {rDir <- "/home/hpc3058/bin/R-3.1.2/bin/"}
	else if (mAcc == 2){rDir <- "/home/hpc3058/bin/R-3.1.2/bin/"}
	else if (mAcc == 3){rDir <- "/home/hpc3058/bin/R-3.1.2/bin/"}
}else{
    rDir <- ""

}

# For this writter we will be working with a number of objects that are different from a normal sim run, but for convenience we 
# will simply define certain aspects now used downstream in writting out .r Master file
l <- 4
o <- 1
tr <- 1
e <- 1

######## THESE ARE SOME PARAMETERS WHICH CAN BE SET WITH treeType == 3 ###############
# These define name of the user tree file and the outgroup sequences therein, called by their label.
# NOTE this tree must be present in the wDir folder as indicated in this script!
mtPath <- paste('"','JDett_Original.tree"',sep="")
mtOut <- 'c("S1","S3","S6","S8")'



# we create new working directories for each tree type and number of sequence combinations, into which we will be putting equivalent jobs
for (tr in 1){
	for (d in mDer[4]){
		for (n in mseqLen){
			
			# Now we decide if the seqLen is long enough to break into separate reps or if we simply keep it as one job, here we
			# are deciding that anything with sequence length of 200 or more should be separated by jobs
			if (n >= 200){
				# Here we create our new working directory into which we will write separate runs by replicate
				system(paste("mkdir -p /Users/Jdench/Desktop/SimulationRuns/PhaseSims/Pilots/seqLen/N",n,"_D",d,sep=""))
				wDir <- paste("/Users/Jdench/Desktop/SimulationRuns/PhaseSims/Pilots/seqLen/N",n,"_D",d,"/",sep="")
				setwd(wDir)
				for (mkD in 1:mReps){
					rName <- paste("Rep",mkD,sep="")
					# Now we create replicate directories and call them the rName and runDir
					system(paste("mkdir -p ",wDir,rName,sep=""))
					
					# This creates the job's specific submit file, at pressent if it's not on Aleph it's going to HPCVL, local machine doesn't need submits....
					if (mSystem !=2){
						cat(paste("qsub -N N",n,"D",d,"_R",mkD," -pe orte 4 -cwd -j y -b y ",rDir,"R CMD BATCH Master",rName,".r", sep=""), file= paste(wDir, rName, "/Sub", rName, ".sh", sep=""), append=TRUE)
					} else {
						# the reason for the difference on HPCVL is to request a specific queue where x86 architecture is supported.
						cat(paste("qsub -q abaqus.q -N N",n,"D",d,"_R",mkD," -pe dist.pe 4 -cwd -j y -b y ",rDir,"R CMD BATCH Master",rName,".r", sep=""), file= paste(wDir, rName, "/Sub", rName, ".sh", sep=""), append=TRUE)
					}
					# Must make the shell files executable for the runs to work, gives permissions to all users
					system(paste("chmod a+x ", wDir, rName, "/Sub", rName, ".sh", sep=""))
					
					# This create the Master submit job file, one for each D,O and T, each master will represent 12 jobs (E x L)
					# This adds all the job calls to the MasterSubmit job file
					cat(paste("cd ../", rName, sep=""), file= paste(wDir, "MasterSubmissionN",n,"D",d,".sh", sep=""), append=TRUE, sep="\n")
					cat(paste("./Sub", rName, ".sh", sep=""), file= paste(wDir, "MasterSubmissionN",n,"D",d,".sh", sep=""), append=TRUE, sep="\n")
					
					# This writes the Master R file which will execute the run
					# Here since each replicate is it's own job we simply make this value 1
					mFile[35] <- paste("nReps <- 1", sep="")
					mFile[36] <- paste("seqLen <- ", n, sep="")
					# We multiply the number of ePairs by e, since e controls if this will be zero or have epistasis
					mFile[38] <- paste("ePairs <- ", mPairs*e, sep="")
					mFile[45] <- paste("sEpi <- ", e, sep="")
					mFile[49] <- paste("wSystem <- ", mSystem, sep="")
					# Here we make the account based adjustment for HPCVL locations, where mAcc == 1, jonathan; mAcc == 2 Stephane's
					if (mAcc == 1){
						# For jonathan's account this is the folder system
						mFile[59] <- '    bDir <- "/home/hpc3058/jonathan/"'
						mFile[60] <- '    phaseLoc <- "/home/hpc3058/bin/phase2.0/"'
						mFile[61] <- '    bayesLoc <- "/home/hpc3058/bin/BayesTraitsV2/"'
					} else if (mAcc == 2){
						# for another account this would be the folder system
						mFile[59] <- '    bDir <- "/home/hpc3058/jonathan/"'
						mFile[60] <- '    phaseLoc <- "/home/hpc3058/bin/phase2.0/"'
						mFile[61] <- '    bayesLoc <- "/home/hpc3058/bin/BayesTraitsV2/"'
					} else if (mAcc == 3){
						# for another account this would be the folder system
						mFile[59] <- '    bDir <- "/home/hpc3058/jonathan/"'
						mFile[60] <- '    phaseLoc <- "/home/hpc3058/bin/phase2.0/"'
						mFile[61] <- '    bayesLoc <- "/home/hpc3058/bin/BayesTraitsV2/"'
					}
					mFile[71] <- paste('wDir <- "SimulationRuns/PhaseSims/Pilots/seqLen/N',n,'_D',d,'/"',sep="")
					mFile[73] <- paste('xDir <- "', rName,'" ',sep="")
					mFile[92] <- paste("nDer <- ", d, sep="")
					mFile[94] <- paste("nOut <- ", mOut[o], sep="")
					mFile[99] <- paste("rDepth <- 0.60",sep="")
					mFile[100] <- paste("bLen <- ", mLen[l],sep="")
					mFile[103] <- paste("treeType <- ", tr, sep="")
					# Here we set the treetype3 specific items
					if (tr == 3){
						mFile[106] <- paste("treePath <- ", mtPath, sep="")
						mFile[109] <- paste("treeOut <- ", mtOut, sep="")
					}
					# We now write out the Master.r script for this particular run
					writeLines(mFile, paste(wDir, rName, "/Master",rName,".r", sep=""))
					# This copies a phase control file into the proper directory
					system(paste("cp /Users/Jdench/Desktop/SimulationRuns/PhaseSims/Pilots/seqLen/",mControl," ",wDir,rName,sep=""))
					system(paste("cp /Users/Jdench/Desktop/SimulationRuns/PhaseSims/Pilots/seqLen/REV.mod ",wDir,sep=""))
					system(paste("cp /Users/Jdench/Desktop/SimulationRuns/PhaseSims/Pilots/seqLen/epiPattern",d,".RData ",wDir,rName,sep=""))
				}			
				# This fixes the first job called in each MAsterSubmit file 
				mSub <- readLines(paste(wDir, "MasterSubmissionN",n,"D",d,".sh", sep=""),-1)
				# This will always be the first job called from any run since we bundle Master files by branch length
				mSub[1] <- paste("cd Rep1", sep="")
				writeLines(mSub, paste(wDir, "MasterSubmissionN",n,"D",d,".sh", sep=""))
				# Must make the shell files executable for the runs to work
				system(paste("chmod a+x ", wDir, "MasterSubmissionN",n,"D",d,".sh", sep=""))
			} else {
				# We create ou run directory as being the seqLen and nSeq values
				system(paste("mkdir -p /Users/Jdench/Desktop/SimulationRuns/PhaseSims/Pilots/seqLen/N",n,"_D",d,sep=""))
				# We set the run directory and run name based on nSeq and seqLen values
				rName <- paste("N",n,"_D",d,sep="")
				
				# This creates the job's specific submit file, at pressent if it's not on Aleph it's going to HPCVL, local machine doesn't need submits....
				if (mSystem !=2){
					cat(paste("qsub -N N",n,"D",d," -pe orte 4 -cwd -j y -b y ",rDir,"R CMD BATCH Master",rName,".r", sep=""), file= paste(wDir, rName, "/Sub", rName, ".sh", sep=""), append=TRUE)
				} else {
					# the reason for the difference on HPCVL is to request a specific queue where x86 architecture is supported.
					cat(paste("qsub -q abaqus.q -N N",n,"D",d," -pe dist.pe 4 -cwd -j y -b y ",rDir,"R CMD BATCH Master",rName,".r", sep=""), file= paste(wDir, rName, "/Sub", rName, ".sh", sep=""), append=TRUE)
				}
				# Must make the shell files executable for the runs to work, gives permissions to all users
				system(paste("chmod a+x ", wDir, rName, "/Sub", rName, ".sh", sep=""))
				
				# This create the Master submit job file, one for each D,O and T, each master will represent 12 jobs (E x L)
				# This adds all the job calls to the MasterSubmit job file
				cat(paste("cd ../", rName, sep=""), file= paste(wDir, "MasterSubmissionD",d,".sh", sep=""), append=TRUE, sep="\n")
				cat(paste("./Sub", rName, ".sh", sep=""), file= paste(wDir, "MasterSubmissionD",d,".sh", sep=""), append=TRUE, sep="\n")
				
				# This writes the Master R file which will execute the run
				mFile[35] <- paste("nReps <- ", mReps, sep="")
				mFile[36] <- paste("seqLen <- ", n, sep="")
				# We multiply the number of ePairs by e, since e controls if this will be zero or have epistasis
				mFile[38] <- paste("ePairs <- ", mPairs*e, sep="")
				mFile[45] <- paste("sEpi <- ", e, sep="")
				mFile[49] <- paste("wSystem <- ", mSystem, sep="")
				# Here we make the account based adjustment for HPCVL locations, where mAcc == 1, jonathan; mAcc == 2 Stephane's
				if (mAcc == 1){
					# For jonathan's account this is the folder system
					mFile[59] <- '    bDir <- "/home/hpc3058/jonathan/"'
					mFile[60] <- '    phaseLoc <- "/home/hpc3058/bin/phase2.0/"'
					mFile[61] <- '    bayesLoc <- "/home/hpc3058/bin/BayesTraitsV2/"'
				} else if (mAcc == 2){
					# for another account this would be the folder system
					mFile[59] <- '    bDir <- "/home/hpc3058/jonathan/"'
					mFile[60] <- '    phaseLoc <- "/home/hpc3058/bin/phase2.0/"'
					mFile[61] <- '    bayesLoc <- "/home/hpc3058/bin/BayesTraitsV2/"'
				} else if (mAcc == 3){
					# for another account this would be the folder system
					mFile[59] <- '    bDir <- "/home/hpc3058/jonathan/"'
					mFile[60] <- '    phaseLoc <- "/home/hpc3058/bin/phase2.0/"'
					mFile[61] <- '    bayesLoc <- "/home/hpc3058/bin/BayesTraitsV2/"'
				}
				mFile[71] <- paste('wDir <- "SimulationRuns/PhaseSims/Pilots/seqLen/"',sep="")
				mFile[73] <- paste('xDir <- "', rName,'" ',sep="")
				mFile[92] <- paste("nDer <- ", d, sep="")
				mFile[94] <- paste("nOut <- ", mOut[o], sep="")
				mFile[99] <- paste("rDepth <- 0.60",sep="")
				mFile[100] <- paste("bLen <- ", mLen[l],sep="")
				mFile[103] <- paste("treeType <- ", tr, sep="")
				# Here we set the treetype3 specific items
				if (tr == 3){
					mFile[106] <- paste("treePath <- ", mtPath, sep="")
					mFile[109] <- paste("treeOut <- ", mtOut, sep="")
				}
				# We now write out the Master.r script for this particular run
				writeLines(mFile, paste(wDir, rName, "/Master",rName,".r", sep=""))
				# This copies a phase control file into the proper directory
				system(paste("cp ",wDir,mControl," ",wDir,rName,sep=""))
				system(paste("cp /Users/Jdench/Desktop/SimulationRuns/PhaseSims/Pilots/seqLen/epiPattern",d,".RData ",wDir,rName,sep=""))			
				# This fixes the first job called in each MAsterSubmit file 
				mSub <- readLines(paste(wDir, "MasterSubmissionD",d,".sh", sep=""),-1)
				# This will always be the first job called from any run since we bundle Master files by branch length
				mSub[1] <- paste("cd N10_D",d, sep="")
				writeLines(mSub, paste(wDir, "MasterSubmissionD",d,".sh", sep=""))
				# Must make the shell files executable for the runs to work
				system(paste("chmod a+x ", wDir, "MasterSubmissionD",d,".sh", sep=""))
			}
		}
	}
}
