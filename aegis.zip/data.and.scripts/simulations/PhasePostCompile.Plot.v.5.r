# This script will combine all the post analysis files from our Simulation runs of the Phase simulations
# All information will be loaded into a single large data frame to make statistical analysis and comparison simplified.
# This script could be used for any similar data set of simulation work.

library(ape)
library(seqinr)
# This library is for certain plotting calls like errbar()
library(Hmisc)
# This library is to handle populations of unequal size


# Identify how many replicates there were in the simulation run being analysed.
tRep <- 100
# This is a list of the filenames to be reviewed for run output  
fNames <- c("RunPostAnalysis_FDR.csv","RunPostAnalysis.csv")
# This is the name of the compilation file to be created\used by this plotting, update this when dealing with new data
# This will then make the compilation call once and skip in future pass through.
compFile <- "TreeType_nSeq_bLen_RunComp.RData"
# These are dimensional layer names, items used for filling in the data.frame and plots
cLabel <- c("TP", "FP", "TN", "FN")
sLabel <- c("Sensitivity","Specificity")
aLabel <- c("q=0.05")
eLabel <- c("No Simulated Epistasis", "Epistasis Simulated")
bLabel <- c("0.00024414","0.00048828","0.00097656", "0.0019531", "0.0039062", "0.0078125","0.015625","0.03125", "0.0625", "0.125", "0.25", "0.5", "0")
dLabel <- c("16", "32", "64", "128")
tLabel <- c("Symetrical", "Pectinate", "Empirical")
# These are lists of setting for output in plots to assign colour and character points for bLen plots
colSeq <- c("red1","blue1","gray60")
colMat <- matrix(c("hotpink1","red1","red3","cornflowerblue","blue1","blue4","gray60","gray40","black"),ncol=length(colSeq))
pchSeq <- c(15,16,17)


# This is requiblack to prevent R from taking 0.0005 and making it into scientific notation, which INDELible can't use
options("scipen"=1000, "digits"=6)

# Set our working directory object
wDir <- ("/Users/Jdench/Desktop/SimulationRuns/PhaseSims/bLen/")
# This is the output folder out plots
pDir <- "PostAnalPlots/"

# Set the wd to be the one where we write our post analysis plots
setwd(paste(wDir,pDir,sep="")) 

# This function will determine the largest power of 2 that is less than the number entered
# This is only established to function with positive powers of 2.
sQrt <- function(vAlue){
	cOunt <- 0
	# If the value is less than 2 then we return this as 0 and stop
	if (vAlue >= 2){
		# Otherwise we know that this is at least a power of 2, this adjustment is needed 
		# as determined from practice
		cOunt <- 1
		# create a temporray value to compare against vAlue
		tmpNum <- 1
		while (tmpNum < vAlue){
			tmpNum <- tmpNum *2
			# This line account for when vAlue is larger than the current assesed power of 2
			# but not larger than that next value
			if (tmpNum *2 <= vAlue) { cOunt <- cOunt + 1 }
		}
		
	}
	return(cOunt)
}

#################################################################################################
########################### Building the Compiled Data Frame ####################################
#################################################################################################

# This is a simple counter to identify if a run has been missed 
missRun <- FALSE

# Here we run through all the folders that contain the output of runs, this process need only be run once
# it will then save an object of this compilation which can be loaded later
# str(compFrame - data frame with the columns of Rep, TP, FP, TN, FN, Num_ePairs, All_ePairs, IDed_TP, Run_Time, Tree_Type, nSeq, bLen, sEpi

# This will first search for the designed output file and only run compilation if not present 
if (file.exists(paste(wDir,compFile,sep="")) == FALSE){
	# We loop through all factors of the experiment to grab the relevant run outputs and build the data frame sequentially
	# Tree type 3 is a special case
	
	# Here we use the treeType 3 scenario to initialise the compFrame object for later use in buiding of our compiled information
	compFrame <- compFrame_noFDR <- data.frame("Rep"=0,"TP"=0,"FP"=0,"TN"=0,"FN"=0,"Num_ePairs"=0,"All_ePairs"=0,"IDed_TP"=0,"Run_Time"=0,"Tree_Type"=0,"nSeq"=0,"bLen"=0,"sEpi"=0)

	# Now we cycle through factors and rbind each file within folders.
	for (tr in 1:3){
		# This is the number of sequences factor, limit of [2] is for tr3 situation
		for (d in if (tr !=3) { as.numeric(dLabel)} else { 2 }){
			# Here we create tmpFrame and tmpFrame_noFDR in order to speed up run times by writting to smaller frames more often
			tmpFrame <- tmpFrame_noFDR <- data.frame("Rep"=0,"TP"=0,"FP"=0,"TN"=0,"FN"=0,"Num_ePairs"=0,"All_ePairs"=0,"IDed_TP"=0,"Run_Time"=0,"Tree_Type"=0,"nSeq"=0,"bLen"=0,"sEpi"=0)
				
			# This is the branch length factor, -1 is for the tr != 3 situation since bLength of 0 is a special character to indicate empirical lengths used
			for (l in if (tr != 3) { 1:(length(bLabel)-1) } else { 1:(length(bLabel)) }){
				# This is epistasis simulation factor
				for (e in c(0,1)){
					# First make certain their is a file to be read, otherwise write out that this run is not completed
					if (file.exists(paste(wDir,"T",tr,"_L",l,"_D",d,"_E",e,"/",fNames[1],sep=""))){
						# Now we simply open each appropriate folder, and rbind the (cbind(fNames file + factors)) to our compFrame 
						tmpFrame <- rbind(tmpFrame, cbind(read.csv(paste(wDir,"T",tr,"_L",l,"_D",d,"_E",e,"/",fNames[1],sep=""),header=TRUE),"Tree_Type"=tr,"nSeq"= if (tr !=3){ d } else { 32 },"bLen"=bLabel[l],"sEpi"=eLabel[e+1]))
						tmpFrame_noFDR <- rbind(tmpFrame_noFDR, cbind(read.csv(paste(wDir,"T",tr,"_L",l,"_D",d,"_E",e,"/",fNames[2],sep=""),header=TRUE),"Tree_Type"=tr,"nSeq"= if (tr !=3){ d } else { 32 },"bLen"=bLabel[l],"sEpi"=eLabel[e+1]))
					
					} else {
						print(paste("The run T",tr,"_L",l,"_D",d,"_E",e, " is not yet completed",sep=""))
						missRun <- TRUE
					}
				}
			}
			# Now we rBind our growing tmp frame and our growing large final frame
			compFrame <- rbind(compFrame, tmpFrame)
			compFrame_noFDR <- rbind(compFrame_noFDR,tmpFrame_noFDR)
		}
	}
	# Remove the first initialising rows, which will be those with replicates states as zeroes
	compFrame <- compFrame[-which(as.numeric(compFrame$Rep) == 0),]
	compFrame_noFDR <- compFrame_noFDR[--which(as.numeric(compFrame$Rep) == 0),]
	# Now we introduce the sensitivity and specificity columns to our data frame
	compFrame$Sensitivity <- (compFrame$TP/(compFrame$TP+compFrame$FN))
	compFrame$Specificity <- (compFrame$TN/(compFrame$TN+compFrame$FP))

	compFrame_noFDR$Sensitivity <- (compFrame_noFDR$TP/(compFrame_noFDR$TP+compFrame_noFDR$FN))
	compFrame_noFDR$Specificity <- (compFrame_noFDR$TN/(compFrame_noFDR$TN+compFrame_noFDR$FP))

	# We want to look at total number of substitutions or rather total evolutionary time 
	# First is to actually create a new column in our compFrame which accounts for the total evolutionary time, this can be infered by 
	# the number of sequences, branch length and the tree type.  For the user generated tree this is not practical as it is not ultrametric.
	# We will use the distribution of these results to infer where along the spectrum this trees falls.
	compFrame$Totlen <- unlist(apply(compFrame,1,function(x){
		tValue <- "Undef"
		# Here we identify first what tree type this is, that will allow us to know how we handle the total length
		if (as.numeric(x[10]) == 2){
			# Now we create the value of of the total length based on the number of sequences * bLen - 1 (the root is not calculated by phase)
			tValue <- (as.numeric(x[11])-1) * as.numeric(x[12])
		} else if (as.numeric(x[10]) == 1){
			# For bifurcating tree the depth of the tree is the power of 2 which relates to nSeq, we then multiply this by bLen
			tValue <- sQrt(as.numeric(x[11])) * as.numeric(x[12])
		}
		return(tValue)
	}))
	
	compFrame_noFDR$Totlen <- unlist(apply(compFrame_noFDR,1,function(x){
		tValue <- "Undef"
		# Here we identify first what tree type this is, that will allow us to know how we handle the total length
		if (as.numeric(x[10]) == 2){
			# Now we create the value of of the total length based on the number of sequences * bLen - 1 (the root is not calculated by phase)
			tValue <- (as.numeric(x[11])-1) * as.numeric(x[12])
		} else if (as.numeric(x[10]) == 1){
			# For bifurcating tree the depth of the tree is the power of 2 which relates to nSeq, we then multiply this by bLen
			tValue <- sQrt(as.numeric(x[11])) * as.numeric(x[12])
		}
		return(tValue)
	}))
	# Now we adjust certain of the compFrame items to become factors, or not be factors
	compFrame$Tree_Type <- factor(compFrame$Tree_Type)
	compFrame_noFDR$Tree_Type <- factor(compFrame_noFDR$Tree_Type)
	# This adjustment to compFrame will introduce NA's for the "User" value we had previously assigned
	compFrame$bLen <- as.numeric(as.character(compFrame$bLen))
	compFrame_noFDR$bLen <- as.numeric(as.character(compFrame_noFDR$bLen))
	
	if (missRun == FALSE){
		# Now we write out the compiled compFrame object so that for later runs it can be loaded and save time
		save(compFrame,compFrame_noFDR, file=paste(wDir,compFile,sep=""))
	}			
} else {
	load(paste(wDir,compFile,sep=""))
}

#################################################################################################
################  Branch Length by: Tree - nSeq Sensitivity\Specificity Plots ###################
#################################################################################################

# This allows us to separate out our information by sensitivity and specifcity, a more standard and visualy clear way to plot confusion info
for (tCon in sLabel){
	# We create some data output matrices to hold information that we will want to plot
	tIqr <- tSdev <- tMean <- array(NA, dim=c(length(dLabel[-1]),length(bLabel),length(tLabel)), dimnames=list(dLabel[-1],bLabel,tLabel))
	# This allows us to cycle through for each tree_type, NOTE# that the user tree type is a special case, hence we only use tree types 1 & 2
	for (tr in 1:length(tLabel)){
		for (i in dLabel[-1]){
			for (j in bLabel){
				# This takes out the small intersection of data we need for this particular cross section of nSeq, bLen, tree_type and sEpi
				wFrame <- compFrame[intersect(intersect(which(compFrame$nSeq == as.numeric(i)),which(compFrame$bLen == j)),intersect(which(compFrame$sEpi == eLabel[2]),which(compFrame$Tree_Type == tr))),]
				# Now we will fill up our tMean and tSdev matrices 
				tMean[i,j,tr] <- mean(wFrame[,tCon])
				tSdev[i,j,tr] <- sd(wFrame[,tCon])
				tIqr[i,j,tr] <- IQR(wFrame[,tCon])
			}
		}
	}
	
	# This assigns the y-axis label based on this run
	tYlab <- paste("Mean ",tolower(tCon),sep="")
	# Now we will identify the y-axis limits by knowing that sensitivity and specificity lie between 0 and 1
	if (tCon == "Sensitivity"){ tYseq <- seq(0,1,by=0.2) } else if (tCon == "Specificity") { tYseq <- seq(0.9,1,by=0.01) }
	# Now we create a simple object with the x-axis values, this is for clarity 
	tXseq <- log(as.numeric(bLabel[-length(bLabel)]),2)
	
	# We want to plot each number of sequences, we will match all same tree elements by colour, and distinguish nSeq elemetns by pch character.
	for (k in 1:dim(tMean)[3]){
		# further we want to plot each tree type, thus the array 3rd dimension
		for (i in if (k != 3 ){ 1:dim(tMean)[1] } else { which(dimnames(tMean)[[1]] == "32") }) {
			# for our first scenario we need to set-up the plot
			if (i == 1 && k == 1){
				# Now we start by opening the connection to the output device - pdf. 
				pdf(paste("bLen_",tCon,".pdf", sep=""),width=12,height=8)
				# Now we start building our plot from the first row of the tMean matrix and working through the other's
				plot(tXseq,tMean[i,-dim(tMean)[2],k],xlim = c(min(tXseq*1.01),max(tXseq*0.80)),
					if (tCon == "Sensitivity"){ ylim = c(0,max(tYseq)) } else if (tCon == "Specificity") { ylim = c(min(tYseq),max(tYseq)) },   
					ylab = tYlab, xlab = "Branch length (log2)", xpd=FALSE, type="b", col=colMat[i,k], pch = pchSeq[i], axes=FALSE, lwd = 2, lty = 1, cex=1.25)
				# Arrows funciton is used to plot the error bars where we define the x,y coords of the upper and lower arrows respectively
				# Which is then followed by the colour, angle of the arrow head and "code" defines which set of coords are used - 3 options and code=3 is both.
				arrows(tXseq,(tMean[i,-dim(tMean)[2],k]+tSdev[i,-dim(tMean)[2],k]), tXseq,(tMean[i,-dim(tMean)[2],k]-tSdev[i,-dim(tMean)[2],k]),col=colMat[i,k],angle=90,length=0.05,code=3, lwd = 1, lty = 2)
				axis(1, at = tXseq, labels = round(tXseq,0), cex = 1)
				axis(2, at = tYseq, labels= tYseq)
				# This is a counter object to help us keep track of which plot element we are working on, this affects the xSeq adjustment to stagger elements
				aCounter <- 1		
			# In all other cases we can simply add points and arrows (error bars)	
			} else {
				# points adds a new data series to our growing plot.
				points(tXseq+(0.05*aCounter),tMean[i,-dim(tMean)[2],k], col=colMat[i,k], pch = pchSeq[i], type = "b", lwd = 2, lty = 1)
				arrows(tXseq+(0.05*aCounter),(tMean[i,-dim(tMean)[2],k]+tSdev[i,-dim(tMean)[2],k]), tXseq+(0.05*aCounter),(tMean[i,-dim(tMean)[2],k]-tSdev[i,-dim(tMean)[2],k]),col=colMat[i,k],angle=90,length=0.05,code=3, lwd =1, lty=2)
				# Now we advance our counter
				aCounter <- aCounter + 1
			}
		}
	}
	# Here we create a grid which is the combinations of tMean dimensions that have been plotted and need legend references, 
	# the first and 3rd dimensions represent nSeq and tree_type respectively
	tLeg <- expand.grid(unlist(dimnames(tMean)[1]),unlist(dimnames(tMean)[3]))
	# Now we add our legend which tells us that the number of sequences is divided by shape and the tree type by colour.  the ncol here uses the number of tLeg columns
	# to divide up our series evenly so that each column will be one type of the second dimension of tLeg, in this case tree_type
	legend(if (tCon == "Sensitivity"){ "top" } else if (tCon == "Specificity"){ "bottom" },inset=c(0.5,0),cex=1.25,c(paste(tLeg[1:7,1]," seq. ",tolower(tLeg[1:7,2])," tree",sep="")),bty="n",col=colMat[1:7], pch= pchSeq, ncol=dim(tMean)[3])
	dev.off()
}

#################################################################################################
#########  Branch Length by: No Error Bars TREES Tree - nSeq Sensitivity\Specificity Plots ######
#################################################################################################

# This allows us to separate out our information by sensitivity and specifcity, a more standard and visualy clear way to plot confusion info
for (tCon in sLabel){
	# We create some data output matrices to hold information that we will want to plot
	tIqr <- tSdev <- tMean <- array(NA, dim=c(length(dLabel[-1]),length(bLabel),length(tLabel)), dimnames=list(dLabel[-1],bLabel,tLabel))
	# This allows us to cycle through for each tree_type, NOTE# that the user tree type is a special case, hence we only use tree types 1 & 2
	for (tr in 1:length(tLabel)){
		for (i in dLabel[-1]){
			for (j in bLabel){
				# This takes out the small intersection of data we need for this particular cross section of nSeq, bLen, tree_type and sEpi
				wFrame <- compFrame[intersect(intersect(which(compFrame$nSeq == as.numeric(i)),which(compFrame$bLen == j)),intersect(which(compFrame$sEpi == eLabel[2]),which(compFrame$Tree_Type == tr))),]
				# Now we will fill up our tMean and tSdev matrices 
				tMean[i,j,tr] <- mean(wFrame[,tCon])
				tSdev[i,j,tr] <- sd(wFrame[,tCon])
				tIqr[i,j,tr] <- IQR(wFrame[,tCon])
			}
		}
	}
	
	# This assigns the y-axis label based on this run
	tYlab <- paste("Mean ",tolower(tCon),sep="")
	# Now we will identify the y-axis limits by knowing that sensitivity and specificity lie between 0 and 1
	if (tCon == "Sensitivity"){ tYseq <- seq(0,1,by=0.2) } else if (tCon == "Specificity") { tYseq <- seq(0.9,1,by=0.01) }
	# Now we create a simple object with the x-axis values, this is for clarity 
	tXseq <- log(as.numeric(bLabel[-length(bLabel)]),2)
	
	# We want to plot each number of sequences, we will match all same tree elements by colour, and distinguish nSeq elemetns by pch character.
	for (k in 1:dim(tMean)[3]){
		# further we want to plot each tree type, thus the array 3rd dimension
		for (i in if (k != 3 ){ 1:dim(tMean)[1] } else { which(dimnames(tMean)[[1]] == "32") }) {
			# for our first scenario we need to set-up the plot
			if (i == 1 && k == 1){
				# Now we start by opening the connection to the output device - pdf. 
				pdf(paste("bLen_",tCon,"_noErr.pdf", sep=""),width=10,height=7.5)
				# Now we start building our plot from the first row of the tMean matrix and working through the other's
				plot(tXseq,tMean[i,-dim(tMean)[2],k],xlim = c(min(tXseq*1.01),max(tXseq*0.80)),
					if (tCon == "Sensitivity"){ ylim = c(0,max(tYseq)) } else if (tCon == "Specificity") { ylim = c(min(tYseq),max(tYseq)) },   
					ylab = tYlab, xlab = "Branch length (log2)", xpd=FALSE, type="b", col=colMat[i,k], pch = pchSeq[i], axes=FALSE, lwd = 3, lty = 1, cex=1.25, cex.lab=1.5)
				# Arrows funciton is used to plot the error bars where we define the x,y coords of the upper and lower arrows respectively
				# Which is then followed by the colour, angle of the arrow head and "code" defines which set of coords are used - 3 options and code=3 is both.
				#arrows(tXseq,(tMean[i,-dim(tMean)[2],k]+tSdev[i,-dim(tMean)[2],k]), tXseq,(tMean[i,-dim(tMean)[2],k]-tSdev[i,-dim(tMean)[2],k]),col=colMat[i,k],angle=90,length=0.05,code=3, lwd = 1, lty = 2)
				axis(1, at = tXseq, labels = round(tXseq,0), cex = 1)
				axis(2, at = tYseq, labels= tYseq)
				# This is a counter object to help us keep track of which plot element we are working on, this affects the xSeq adjustment to stagger elements
				aCounter <- 1		
			# In all other cases we can simply add points and arrows (error bars)	
			} else {
				# points adds a new data series to our growing plot.
				points(tXseq,tMean[i,-dim(tMean)[2],k], col=colMat[i,k], pch = pchSeq[i], type = "b", lwd = 3, lty = 1)
				#points(tXseq+(0.02*aCounter),tMean[i,-dim(tMean)[2],k], col=colMat[i,k], pch = pchSeq[i], type = "b", lwd = 2, lty = 1)
				#arrows(tXseq+(0.02*aCounter),(tMean[i,-dim(tMean)[2],k]+tSdev[i,-dim(tMean)[2],k]), tXseq+(0.02*aCounter),(tMean[i,-dim(tMean)[2],k]-tSdev[i,-dim(tMean)[2],k]),col=colMat[i,k],angle=90,length=0.05,code=3, lwd =1, lty=2)
				# Now we advance our counter
				aCounter <- aCounter + 1
			}
		}
	}
	# Here we create a grid which is the combinations of tMean dimensions that have been plotted and need legend references, 
	# the first and 3rd dimensions represent nSeq and tree_type respectively
	tLeg <- expand.grid(unlist(dimnames(tMean)[1]),unlist(dimnames(tMean)[3]))
	# Now we add our legend which tells us that the number of sequences is divided by shape and the tree type by colour.  the ncol here uses the number of tLeg columns
	# to divide up our series evenly so that each column will be one type of the second dimension of tLeg, in this case tree_type
	legend(if (tCon == "Sensitivity"){ "top" } else if (tCon == "Specificity"){ "bottom" },inset=c(0.5,0),cex=1.25,c(paste(tLeg[1:7,1]," seq. ",tolower(tLeg[1:7,2])," tree",sep="")),bty="n",col=colMat[1:7], pch= pchSeq, ncol=dim(tMean)[3])
	dev.off()
}

#################################################################################################
####################################  PAPER WITH JC PUBLICATION PLOTS ###########################
#################################################################################################

# This allows us to separate out our information by sensitivity and specifcity, a more standard and visualy clear way to plot confusion info
for (tCon in sLabel){
	# We create some data output matrices to hold information that we will want to plot
	tIqr <- tSdev <- tMean <- array(NA, dim=c(length(dLabel[-1]),length(bLabel),length(tLabel)), dimnames=list(dLabel[-1],bLabel,tLabel))
	# This allows us to cycle through for each tree_type, NOTE# that the user tree type is a special case, hence we only use tree types 1 & 2
	#for (tr in 1:length(tLabel)){
	for (tr in 1:2){
		for (i in dLabel[-1]){
			for (j in bLabel){
				# This takes out the small intersection of data we need for this particular cross section of nSeq, bLen, tree_type and sEpi
				wFrame <- compFrame[intersect(intersect(which(compFrame$nSeq == as.numeric(i)),which(compFrame$bLen == j)),intersect(which(compFrame$sEpi == eLabel[2]),which(compFrame$Tree_Type == tr))),]
				# Now we will fill up our tMean and tSdev matrices 
				tMean[i,j,tr] <- mean(wFrame[,tCon])
				tSdev[i,j,tr] <- sd(wFrame[,tCon])
				tIqr[i,j,tr] <- IQR(wFrame[,tCon])
			}
		}
	}
	
	# This assigns the y-axis label based on this run
	tYlab <- paste("Mean ",tolower(tCon),sep="")
	# Now we will identify the y-axis limits by knowing that sensitivity and specificity lie between 0 and 1
	if (tCon == "Sensitivity"){ tYseq <- seq(0,1,by=0.2) } else if (tCon == "Specificity") { tYseq <- seq(0.9,1,by=0.01) }
	# Now we create a simple object with the x-axis values, this is for clarity 
	tXseq <- log(as.numeric(bLabel[-length(bLabel)]),2)
	
	# We want to plot each number of sequences, we will match all same tree elements by colour, and distinguish nSeq elemetns by pch character.
	for (k in 1:dim(tMean)[3]){
		# further we want to plot each tree type, thus the array 3rd dimension
		for (i in if (k != 3 ){ 1:dim(tMean)[1] } else { which(dimnames(tMean)[[1]] == "32") }) {
			# for our first scenario we need to set-up the plot
			if (i == 1 && k == 1){
				# Now we start by opening the connection to the output device - pdf. 
				pdf(paste("bLen_",tCon,"_PubPlots.pdf", sep=""),width=10,height=7.5)
				# Now we start building our plot from the first row of the tMean matrix and working through the other's
				plot(tXseq,tMean[i,-dim(tMean)[2],k],xlim = c(min(tXseq*1.01),max(tXseq*0.80)),
					if (tCon == "Sensitivity"){ ylim = c(0,max(tYseq)) } else if (tCon == "Specificity") { ylim = c(min(tYseq),max(tYseq)) },   
					ylab = tYlab, xlab = "Branch length (log2)", xpd=FALSE, type="b", col=colMat[i,k], pch = pchSeq[i], axes=FALSE, lwd = 3, lty = 1, cex=1.25, cex.lab=1.5)
				# Arrows funciton is used to plot the error bars where we define the x,y coords of the upper and lower arrows respectively
				# Which is then followed by the colour, angle of the arrow head and "code" defines which set of coords are used - 3 options and code=3 is both.
				#arrows(tXseq,(tMean[i,-dim(tMean)[2],k]+tSdev[i,-dim(tMean)[2],k]), tXseq,(tMean[i,-dim(tMean)[2],k]-tSdev[i,-dim(tMean)[2],k]),col=colMat[i,k],angle=90,length=0.05,code=3, lwd = 1, lty = 2)
				axis(1, at = tXseq, labels = round(tXseq,0), cex = 1)
				axis(2, at = tYseq, labels= tYseq)
				# This is a counter object to help us keep track of which plot element we are working on, this affects the xSeq adjustment to stagger elements
				#aCounter <- 1		
			# In all other cases we can simply add points and arrows (error bars)	
			} else {
				# points adds a new data series to our growing plot.
				points(tXseq,tMean[i,-dim(tMean)[2],k], col=colMat[i,k], pch = pchSeq[i], type = "b", lwd = 3, lty = 1)
				#points(tXseq+(0.02*aCounter),tMean[i,-dim(tMean)[2],k], col=colMat[i,k], pch = pchSeq[i], type = "b", lwd = 2, lty = 1)
				#arrows(tXseq+(0.02*aCounter),(tMean[i,-dim(tMean)[2],k]+tSdev[i,-dim(tMean)[2],k]), tXseq+(0.02*aCounter),(tMean[i,-dim(tMean)[2],k]-tSdev[i,-dim(tMean)[2],k]),col=colMat[i,k],angle=90,length=0.05,code=3, lwd =1, lty=2)
				# Now we advance our counter
				#aCounter <- aCounter + 1
			}
		}
	}
	# Here we create a grid which is the combinations of tMean dimensions that have been plotted and need legend references, 
	# the first and 3rd dimensions represent nSeq and tree_type respectively
	tLeg <- expand.grid(unlist(dimnames(tMean)[1]),unlist(dimnames(tMean)[3]))
	# Now we add our legend which tells us that the number of sequences is divided by shape and the tree type by colour.  the ncol here uses the number of tLeg columns
	# to divide up our series evenly so that each column will be one type of the second dimension of tLeg, in this case tree_type
	legend(if (tCon == "Sensitivity"){ "top" } else if (tCon == "Specificity"){ "bottom" },inset=c(0.5,0),cex=1.5,c(paste(tLeg[1:6,1]," seq. ",tolower(tLeg[1:6,2])," tree",sep="")),bty="n",col=colMat[1:6], pch= pchSeq, ncol=dim(tMean)[3]-1)
	dev.off()
}

#### This is the nSeq plot ####

# This allows us to separate out our information by sensitivity and specifcity, a more standard and visualy clear way to plot confusion info
for (tCon in "Sensitivity"){
	# We create some data output matrices to hold information that we will want to plot
	tIqr <- tSdev <- tMean <- matrix(NA, ncol=length(dLabel),nrow=length(tLabel), dimnames=list(tLabel, dLabel))
	# This allows us to cycle through for each tree_type, NOTE# that the user tree type is a special case, hence we only use tree types 1 & 2
	for (tr in 1:2){
		for (i in dLabel){
			# This takes out the small intersection of data we need for this particular cross section of nSeq, bLen, tree_type and sEpi
			wFrame <- compFrame[intersect(which(compFrame$nSeq == i),intersect(which(compFrame$sEpi == eLabel[2]),which(compFrame$Tree_Type == tr))),]
			# Now we will fill up our tMean and tSdev matrices, we will adjust any NaN or NA values to simply be zero, this represents a failure
			# to have found any TP or FP, otherwise something would have calculated because (Sensitivity = TP/TP+FN)
			tMean[tr,i] <- if (mean(wFrame[,tCon]) == "NaN"){0} else { mean(wFrame[,tCon])}
			tSdev[tr,i] <- if (length(attr(na.omit(sd(wFrame[,tCon])),which="na.action")) > 0){0} else { sd(wFrame[,tCon])}
			tIqr[tr,i] <- if (length(attr(na.omit(IQR(wFrame[,tCon])),which="na.action")) > 0){0} else { IQR(wFrame[,tCon])}
		}
	}
	
	# This assigns the y-axis label based on this run
	tYlab <- paste("Mean ",tolower(tCon),sep="")
	# Now we will identify the y-axis limits by knowing that sensitivity and specificity lie between 0 and 1
	tYseq <- seq(0,1,by=0.2)
	
	# Now we create our barplot of which will take each column as a single x-axis element and then plot the rows beside one another, creating
	# a nSeq grouped by Tree_Type tCon plot
	pdf(paste("/Users/Jdench/Desktop/Jonathan_Dench/MyResearch/MyPapers/Epistasis_Validation/nSeq_", tCon,".pdf", sep=""),width=6,height=4)
	myP <- barplot(tMean, ylab=tYlab, xlab="Number of aligned sequences", ylim=c(0,max(tYseq)), names.arg=(dLabel), col=colSeq, beside=TRUE, cex.lab = 1.2, cex.axis = 1.1)
	legend("topleft", c(paste(tLabel[1:2]," tree",sep="")) ,fill = colSeq[1:2], bty="n", cex=0.8)
	#arrows(myP,tMean+tSdev, myP, tMean-tSdev, angle=90, code=3, length=0.05)
	dev.off()	
}



#################################################################################################
################  Branch Length by: Tree - nSeq TP Plots 					  ###################
################  NO FDR compFrame_noFDR values considered here 			  ###################
#################################################################################################

# This allows us to separate out our information by sensitivity and specifcity, a more standard and visualy clear way to plot confusion info
for (tCon in sLabel){
	# We create some data output matrices to hold information that we will want to plot
	tIqr <- tSdev <- tMean <- array(NA, dim=c(length(dLabel[-1]),length(bLabel),2), dimnames=list(dLabel[-1],bLabel,tLabel[1:2]))
	# This allows us to cycle through for each tree_type, NOTE# that the user tree type is a special case, hence we only use tree types 1 & 2
	for (tr in 1:2){
		for (i in dLabel[-1]){
			for (j in bLabel){
				# This takes out the small intersection of data we need for this particular cross section of nSeq, bLen, tree_type and sEpi
				wFrame <- compFrame_noFDR[intersect(intersect(which(compFrame_noFDR$nSeq == i),which(compFrame_noFDR$bLen == j)),intersect(which(compFrame_noFDR$sEpi == eLabel[2]),which(compFrame_noFDR$Tree_Type == tr))),]
				# Now we will fill up our tMean and tSdev matrices
				tMean[i,j,tr] <- mean(wFrame[,tCon])
				tSdev[i,j,tr] <- sd(wFrame[,tCon])
				tIqr[i,j,tr] <- IQR(wFrame[,tCon])
			}
		}
	}
	
	# This assigns the y-axis label based on this run
	tYlab <- paste("Mean ",tolower(tCon),sep="")
	# Now we will identify the y-axis limits by knowing that sensitivity and specificity lie between 0 and 1
	tYseq <- seq(0,1,by=0.2)
	# Now we create a simple object with the x-axis values, this is for clarity 
	tXseq <- log(as.numeric(bLabel),10)
	
	# We want to plot each number of sequences, we will match all same tree elements by colour, and distinguish nSeq elemetns by pch character.
	for (i in 1:nrow(tMean)){
		# further we want to plot each tree type, thus the array 3rd dimension
		for (k in 1:dim(tMean)[3]){
			# for our first scenario we need to set-up the plot
			if (i == 1 && k == 1){
				# Now we start by opening the connection to the output device - pdf. 
				pdf(paste("bLen_",tCon,"_noFDR.pdf", sep=""),width=12,height=8)
				# Now we start building our plot from the first row of the tMean matrix and working through the other's
				plot(tXseq,tMean[i,,k],xlim = c(min(tXseq*1.01),max(tXseq*0.80)), ylim = c(0,max(tYseq)) ,ylab = tYlab, xlab = "Branch length", xpd=FALSE, type="b", col=colMat[i,k], pch = pchSeq[i], axes=FALSE, lwd=2,lty=1)
				# Arrows funciton is used to plot the error bars where we define the x,y coords of the upper and lower arrows respectively
				# Which is then followed by the colour, angle of the arrow head and "code" defines which set of coords are used - 3 options and code=3 is both.
				arrows(tXseq,(tMean[i,,k]+tSdev[i,,k]), tXseq,(tMean[i,,k]-tSdev[i,,k]),col=colMat[i,k],angle=90,length=0.05,code=3,lwd=1,lty=2)
				axis(1, at = tXseq, labels = bLabel, cex = 0.8)
				axis(2, at = tYseq, labels= tYseq)
				# This is a counter object to help us keep track of which plot element we are working on, this affects the xSeq adjustment to stagger elements
				aCounter <- 1
			# In all other cases we can simply add points and arrows (error bars)	
			} else {
				# points adds a new data series to our growing plot.
				points(tXseq+(0.02*aCounter),tMean[i,,k], col=colMat[i,k], pch = pchSeq[i], type = "b",lwd=2,lty=1)
				arrows(tXseq+(0.02*aCounter),(tMean[i,,k]+tSdev[i,,k]), tXseq+(0.02*aCounter),(tMean[i,,k]-tSdev[i,,k]),col=colMat[i,k],angle=90,length=0.05,code=3,lwd=1,lty=2)
				# Now we advance our counter
				aCounter <- aCounter + 1
			}
		}
	}
	# Here we create a grid which is the combinations of tMean dimensions that have been plotted and need legend references, 
	# the first and 3rd dimensions represent nSeq and tree_type respectively
	tLeg <- expand.grid(unlist(dimnames(tMean)[1]),unlist(dimnames(tMean)[3]))
	# Now we add our legend which tells us that the number of sequences is divided by shape and the tree type by colour.  the ncol here uses the number of tLeg columns
	# to divide up our series evenly so that each column will be one type of the second dimension of tLeg, in this case tree_type
	legend("bottom",inset=c(0.2,0),cex=0.80,c(paste(tLeg[,1]," sequences ",tolower(tLeg[,2])," tree",sep="")),bty="n",col=colMat, pch= pchSeq, ncol=ncol(tLeg))
	dev.off()
}

#################################################################################################
################  Root Depth Length by: Tree - nSeq Sensitivity\Specificity Plots ###############
#################################################################################################

# This allows us to separate out our information by sensitivity and specifcity, a more standard and visualy clear way to plot confusion info
for (tCon in sLabel){
	# We create some data output matrices to hold information that we will want to plot
	tIqr <- tSdev <- tMean <- array(NA, dim=c(length(dLabel[-1]),length(bLabel),2), dimnames=list(dLabel[-1],bLabel,tLabel[1:2]))
	tXseq <- list()
	# This allows us to cycle through for each tree_type, NOTE# that the user tree type is a special case, hence we only use tree types 1 & 2
	for (tr in 1:2){
		for (i in dLabel[-1]){
			# Here we set our working frame to the subset of confusion type, tree_type and nSeq so that we can identify the exitent root depth factor levels
			wFrame <- compFrame[intersect(which(compFrame$nSeq == i),intersect(which(compFrame$sEpi == eLabel[2]),which(compFrame$Tree_Type == tr))),]
			tRdepth <- factor(wFrame$Totlen)	
			for (j in tRdepth){
				# This takes out the small intersection of data we need for this particular cross section of nSeq, Totlen, tree_type and sEpi
				# Now we will fill up our tMean and tSdev matrices, we need to call the levels of Totlen as factor to indeitfy the proper j index
				tMean[i,which(levels(factor(wFrame$Totlen)) == j),tr] <- mean(wFrame[which(wFrame$Totlen == as.numeric(as.character(j))),tCon])
				tSdev[i,which(levels(factor(wFrame$Totlen)) == j),tr] <- sd(wFrame[which(wFrame$Totlen == as.numeric(as.character(j))),tCon])
				tIqr[i,which(levels(factor(wFrame$Totlen)) == j),tr] <- IQR(wFrame[which(wFrame$Totlen == as.numeric(as.character(j))),tCon])
				
			}
		# Now we create a simple object with the x-axis values, this takes the ordered set of the levels of Totlen that matter for this particular subset of data
		# This becomes important since we are plotting all subsects on the same graph.
		# We add a multiple of the tree type value -1 and the length of dLabel so that each tree is separated into it's own list elements.
		tXseq[[(which(dLabel == i) -1)+(length(dLabel[-1])*(tr-1))]] <- log(as.numeric(levels(factor(wFrame$Totlen))[order(as.numeric(levels(factor(wFrame$Totlen))))]),10)
		}
	}
	
	# This assigns the y-axis label based on this run
	tYlab <- paste("Mean ",tolower(tCon),sep="")
	# Now we will identify the y-axis limits by knowing that sensitivity and specificity lie between 0 and 1
	tYseq <- seq(0,1,by=0.2)
	
	# We want to plot each number of sequences, we will match all same tree elements by colour, and distinguish nSeq elemetns by pch character.
	for (i in 1:nrow(tMean)){
		# further we want to plot each tree type, thus the array 3rd dimension
		for (k in 1:dim(tMean)[3]){
			# for our first scenario we need to set-up the plot
			if (i == 1 && k == 1){
				# Now we start by opening the connection to the output device - pdf. 
				pdf(paste("rDepth_",tCon,".pdf", sep=""),width=18,height=8)
				### The tXseq adjustment of i + (nrow(tMean) * k -1) is to adjust so that we grab the right values for each tree type and nSeq (rows of tMean)
				# Now we start building our plot from the first row of the tMean matrix and working through the other's
				plot(tXseq[[i+ (nrow(tMean) * (k -1))]],tMean[i,,k],xlim = c(min(unlist(tXseq)*1.02),max(unlist(tXseq)*1.02)), ylim = c(0,max(tYseq)) ,ylab = tYlab, xlab = "Root depth", xpd=FALSE, type="b", col=colMat[i,k], pch = pchSeq[i], axes=FALSE,lwd=2,lty=1)
				# Arrows funciton is used to plot the error bars where we define the x,y coords of the upper and lower arrows respectively
				# Which is then followed by the colour, angle of the arrow head and "code" defines which set of coords are used - 3 options and code=3 is both.
				arrows(tXseq[[i+ (nrow(tMean) * (k -1))]],(tMean[i,,k]+tSdev[i,,k]), tXseq[[i+ (nrow(tMean) * (k -1))]],(tMean[i,,k]-tSdev[i,,k]),col=colMat[i,k],angle=90,length=0.05,code=3,lwd=1,lty=2)
				axis(1, at = unlist(tXseq)[order(unlist(tXseq))], labels = 10^unlist(tXseq), cex = 0.8)
				axis(2, at = tYseq, labels= tYseq)
			# In all other cases we can simply add points and arrows (error bars)	
			} else {
				# points adds a new data series to our growing plot.
				points(tXseq[[i+ (nrow(tMean) * (k -1))]],tMean[i,,k], col=colMat[i,k], pch = pchSeq[i], type = "b",lwd=2,lty=1)
				arrows(tXseq[[i+ (nrow(tMean) * (k -1))]],(tMean[i,,k]+tSdev[i,,k]), tXseq[[i+ (nrow(tMean) * (k -1))]],(tMean[i,,k]-tSdev[i,,k]),col=colMat[i,k],angle=90,length=0.05,code=3,lwd=1,lty=2)
			}
		}
	}
	# Here we create a grid which is the combinations of tMean dimensions that have been plotted and need legend references, 
	# the first and 3rd dimensions represent nSeq and tree_type respectively
	tLeg <- expand.grid(unlist(dimnames(tMean)[1]),unlist(dimnames(tMean)[3]))
	# Now we add our legend which tells us that the number of sequences is divided by shape and the tree type by colour.  the ncol here uses the number of tLeg columns
	# to divide up our series evenly so that each column will be one type of the second dimension of tLeg, in this case tree_type
	legend("bottomcenter",inset=c(0.05,0),cex=1.0,c(paste(tLeg[,1]," sequences ",tolower(tLeg[,2])," tree",sep="")),bty="n",col=colMat, pch= pchSeq, horiz=TRUE)
	dev.off()
}
#################################################################################################
################  nSeq by: Tree - nSeq Sensitivity\Specificity Plots ############################
#################################################################################################
# We do not include bLen in this as we are including the nSeq =13 and Tree_Type = 3 factors which when we assay significance of interaction
# actually removes bLen from being a relevant factor.  This plays into our "story" of how and why we are performing these studies.

# This allows us to separate out our information by sensitivity and specifcity, a more standard and visualy clear way to plot confusion info
for (tCon in sLabel){
	# We create some data output matrices to hold information that we will want to plot
	tIqr <- tSdev <- tMean <- matrix(NA, ncol=length(dLabel),nrow=length(tLabel), dimnames=list(tLabel, dLabel))
	# This allows us to cycle through for each tree_type, NOTE# that the user tree type is a special case, hence we only use tree types 1 & 2
	for (tr in 1:length(tLabel)){
		for (i in dLabel){
			# This takes out the small intersection of data we need for this particular cross section of nSeq, bLen, tree_type and sEpi
			wFrame <- compFrame[intersect(which(compFrame$nSeq == i),intersect(which(compFrame$sEpi == eLabel[2]),which(compFrame$Tree_Type == tr))),]
			# Now we will fill up our tMean and tSdev matrices, we will adjust any NaN or NA values to simply be zero, this represents a failure
			# to have found any TP or FP, otherwise something would have calculated because (Sensitivity = TP/TP+FN)
			tMean[tr,i] <- if (mean(wFrame[,tCon]) == "NaN"){0} else { mean(wFrame[,tCon])}
			tSdev[tr,i] <- if (length(attr(na.omit(sd(wFrame[,tCon])),which="na.action")) > 0){0} else { sd(wFrame[,tCon])}
			tIqr[tr,i] <- if (length(attr(na.omit(IQR(wFrame[,tCon])),which="na.action")) > 0){0} else { IQR(wFrame[,tCon])}
		}
	}
	
	# This assigns the y-axis label based on this run
	tYlab <- paste("Mean ",tolower(tCon),sep="")
	# Now we will identify the y-axis limits by knowing that sensitivity and specificity lie between 0 and 1
	tYseq <- seq(0,1,by=0.2)
	
	# Now we create our barplot of which will take each column as a single x-axis element and then plot the rows beside one another, creating
	# a nSeq grouped by Tree_Type tCon plot
	pdf(paste("nSeq_", tCon,".pdf", sep=""),width=6,height=4)
	myP <- barplot(tMean, ylab=tYlab, xlab="Number of aligned sequences", ylim=c(0,max(tYseq)), names.arg=(dLabel), col=colSeq, beside=TRUE, cex.lab = 1.2, cex.axis = 1.1)
	legend("topleft", c(paste(tLabel," tree",sep="")) ,fill = colSeq, bty="n", cex=0.8)
	#arrows(myP,tMean+tSdev, myP, tMean-tSdev, angle=90, code=3, length=0.05)
	dev.off()	
}

#################################################################################################
################  nSeq by: Tree - nSeq TN Plot ##################################################
#################################################################################################
# We do not include bLen in this as we are including the nSeq =13 and Tree_Type = 3 factors which when we assay significance of interaction
# actually removes bLen from being a relevant factor.  This plays into our "story" of how and why we are performing these studies.

# This allows us to separate out our information by sensitivity and specifcity, a more standard and visualy clear way to plot confusion info
for (tCon in "TN"){
	# We create some data output matrices to hold information that we will want to plot
	tIqr <- tSdev <- tMean <- matrix(NA, ncol=length(dLabel),nrow=length(tLabel), dimnames=list(tLabel, dLabel))
	# This allows us to cycle through for each tree_type, NOTE# that the user tree type is a special case, hence we only use tree types 1 & 2
	for (tr in 1:length(tLabel)){
		for (i in dLabel){
			# This takes out the small intersection of data we need for this particular cross section of nSeq, bLen, tree_type and sEpi
			wFrame <- compFrame[intersect(which(compFrame$nSeq == i),intersect(which(compFrame$sEpi == eLabel[2]),which(compFrame$Tree_Type == tr))),]
			# Now we will fill up our tMean and tSdev matrices, we will adjust any NaN or NA values to simply be zero, this represents a failure
			# to have found any TP or FP, otherwise something would have calculated because (Sensitivity = TP/TP+FN)
			tMean[tr,i] <- if (mean(wFrame[,tCon]) == "NaN"){0} else { mean(wFrame[,tCon])}
			tSdev[tr,i] <- if (length(attr(na.omit(sd(wFrame[,tCon])),which="na.action")) > 0){0} else { sd(wFrame[,tCon])}
			tIqr[tr,i] <- if (length(attr(na.omit(IQR(wFrame[,tCon])),which="na.action")) > 0){0} else { IQR(wFrame[,tCon])}
		}
	}
	
	# This assigns the y-axis label based on this run
	tYlab <- paste("Mean ",tCon,sep="")
	# Now we will identify the y-axis limits by knowing that sensitivity and specificity lie between 0 and 1
	tYseq <- round(seq(0,max(tMean)*1.05,by=(max(tMean)*1.05/6)),2)
	
	# Now we create our barplot of which will take each column as a single x-axis element and then plot the rows beside one another, creating
	# a nSeq grouped by Tree_Type tCon plot
	pdf(paste("nSeq_", tCon,".pdf", sep=""),width=6,height=4)
	myP <- barplot(tMean, ylab=tYlab, xlab="Tree Types by Number of Sequences", ylim=c(0,max(tYseq)*1.05), names.arg=(dLabel), col=colSeq, beside=TRUE)
	legend("topleft", c(paste(tLabel," tree",sep="")) ,fill = colSeq, bty="n", cex=0.65)
	arrows(myP,tMean+tSdev, myP, tMean-tSdev, angle=90, code=3, length=0.05)
	dev.off()	
}


#################################################################################################
#################################################################################################
#################################################################################################
################  Below Here Are Old LEss Interesting Plots #####################################
#################################################################################################
#################################################################################################
#################################################################################################


#################################################################################################
################  Branch Length by nSeq: Persp plot Sensitivity #################################
#################################################################################################

### Once the new tree length data returns we can remove the [1:6] instances from bLabel calls ###

for (tCon in sLabel[1]){
	# We create some data output matrices to hold information that we will want to plot
	tIqr <- tSdev <- tMean <- array(NA, dim=c(length(dLabel[-1]),length(bLabel[1:6]),2), dimnames=list(dLabel[-1],bLabel[1:6],tLabel[1:2]))
	# This allows us to cycle through for each tree_type, NOTE# that the user tree type is a special case, hence we only use tree types 1 & 2
	for (tr in 1:2){
		for (i in dLabel[-1]){
			for (j in bLabel[1:6]){
				# This takes out the small intersection of data we need for this particular cross section of nSeq, bLen, tree_type and sEpi
				wFrame <- compFrame[intersect(intersect(which(compFrame$nSeq == i),which(compFrame$bLen == j)),intersect(which(compFrame$sEpi == eLabel[2]),which(compFrame$Tree_Type == tr))),]
				# Now we will fill up our tMean and tSdev matrices 
				tMean[i,j,tr] <- mean(wFrame[,tCon])
				tSdev[i,j,tr] <- sd(wFrame[,tCon])
				tIqr[i,j,tr] <- IQR(wFrame[,tCon])
			}
		}
	}

	# Now we will identify the y-axis limits by knowing that sensitivity and specificity lie between 0 and 1
	tXseq <- c(as.numeric(dLabel[-1]))
	tYseq <- c(log(as.numeric(bLabel[1:6]),10))
}
# This sets up our initial plot of our 3d structure using the first tree type
myPersp <- persp(tXseq,tYseq,tMean[,,1],theta=-45, phi = 25,xlab="Number of Sequences", ylab="Branch Length",zlab="Sensitivity")
# Now we round and trime our myPersp object which is usefull for identifying the shape we hold when adding new data
# expand.grid takes an x and y vector input and creates grid coordinates for them, this means we can in one step cbind 
# our z coordinate points which are identified by the tMean second layer which here represents tree_type ==2, we have plotted #1.
xyzCoor <- cbind(expand.grid(tXseq,tYseq),c(sapply(tMean[,,2],function(x){return(x)})))
# This will add the second tree type to our plot
points(trans3d(xyzCoor[,1], xyzCoor[,2], xyzCoor[,3], pmat = myPersp))
lines (trans3d(xyzCoor[,1], xyzCoor[,2], xyzCoor[,3], pmat = myPersp), col = "red")

#################################################################################################
################  Branch Length by: Tree - nSeq Sensitivity\Specificity Plots ###################
################  Not log adjusted x-lim									  ###################
#################################################################################################

# This allows us to separate out our information by sensitivity and specifcity, a more standard and visualy clear way to plot confusion info
for (tCon in sLabel){
	# We create some data output matrices to hold information that we will want to plot
	tIqr <- tSdev <- tMean <- array(NA, dim=c(length(dLabel[-1]),length(bLabel),2), dimnames=list(dLabel[-1],bLabel,tLabel[1:2]))
	# This allows us to cycle through for each tree_type, NOTE# that the user tree type is a special case, hence we only use tree types 1 & 2
	for (tr in 1:2){
		for (i in dLabel[-1]){
			for (j in bLabel){
				# This takes out the small intersection of data we need for this particular cross section of nSeq, bLen, tree_type and sEpi
				wFrame <- compFrame[intersect(intersect(which(compFrame$nSeq == i),which(compFrame$bLen == j)),intersect(which(compFrame$sEpi == eLabel[2]),which(compFrame$Tree_Type == tr))),]
				# Now we will fill up our tMean and tSdev matrices 
				tMean[i,j,tr] <- mean(wFrame[,tCon])
				tSdev[i,j,tr] <- sd(wFrame[,tCon])
				tIqr[i,j,tr] <- IQR(wFrame[,tCon])
			}
		}
	}
	
	# This assigns the y-axis label based on this run
	tYlab <- paste("Mean ",tolower(tCon),sep="")
	# Now we will identify the y-axis limits by knowing that sensitivity and specificity lie between 0 and 1
	tYseq <- seq(0,1,by=0.2)
	# Now we create a simple object with the x-axis values, this is for clarity 
	tXseq <- as.numeric(bLabel)
	
	# We want to plot each number of sequences, we will match all same tree elements by colour, and distinguish nSeq elemetns by pch character.
	for (i in 1:nrow(tMean)){
		# further we want to plot each tree type, thus the array 3rd dimension
		for (k in 1:dim(tMean)[3]){
			# for our first scenario we need to set-up the plot
			if (i == 1 && k == 1){
				# Now we start by opening the connection to the output device - pdf. 
				pdf(paste("bLen_",tCon,"_noLogX.pdf", sep=""),width=12,height=8)
				# Now we start building our plot from the first row of the tMean matrix and working through the other's
				plot(tXseq,tMean[i,,k],xlim = c(min(tXseq*0.95),max(tXseq*1.05)), ylim = c(0,max(tYseq)) ,ylab = tYlab, xlab = "Branch length", xpd=FALSE, type="b", col=colMat[i,k], pch = pchSeq[i], axes=FALSE)
				# Arrows funciton is used to plot the error bars where we define the x,y coords of the upper and lower arrows respectively
				# Which is then followed by the colour, angle of the arrow head and "code" defines which set of coords are used - 3 options and code=3 is both.
				arrows(tXseq,(tMean[i,,k]+tSdev[i,,k]), tXseq,(tMean[i,,k]-tSdev[i,,k]),col=colMat[i,k],angle=90,length=0.05,code=3)
				axis(1, at = tXseq, labels = bLabel, cex = 0.8)
				axis(2, at = tYseq, labels= tYseq)
				# This is a counter object to help us keep track of which plot element we are working on, this affects the xSeq adjustment to stagger elements
				aCounter <- 1
			# In all other cases we can simply add points and arrows (error bars)	
			} else {
				# points adds a new data series to our growing plot.
				points(tXseq+(0.02*aCounter),tMean[i,,k], col=colMat[i,k], pch = pchSeq[i], type = "b")
				arrows(tXseq+(0.02*aCounter),(tMean[i,,k]+tSdev[i,,k]), tXseq+(0.02*aCounter),(tMean[i,,k]-tSdev[i,,k]),col=colMat[i,k],angle=90,length=0.05,code=3)
				# Now we advance our counter
				aCounter <- aCounter + 1
			}
		}
	}
	# Here we create a grid which is the combinations of tMean dimensions that have been plotted and need legend references, 
	# the first and 3rd dimensions represent nSeq and tree_type respectively
	tLeg <- expand.grid(unlist(dimnames(tMean)[1]),unlist(dimnames(tMean)[3]))
	# Now we add our legend which tells us that the number of sequences is divided by shape and the tree type by colour.  the ncol here uses the number of tLeg columns
	# to divide up our series evenly so that each column will be one type of the second dimension of tLeg, in this case tree_type
	legend("bottomleft",inset=c(0.2,0),cex=0.80,c(paste(tLeg[,1]," sequences ",tolower(tLeg[,2])," tree",sep="")),bty="n",col=colMat, pch= pchSeq, ncol=ncol(tLeg))
	dev.off()
}