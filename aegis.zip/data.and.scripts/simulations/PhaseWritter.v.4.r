# This is created to build all the necessary files and folders that will be part of my
# Simulation studies of epistatic recovery.  This version is manged for nOut being removed as a factor
# and to remove treeType3 branch length as being a factor

# File naming structure follows E#_D#_L#_T#_N#, where e is insertion of esites, d is tree depth, 
# l is branch length, t is the tree topology and n is the number of sequences in an alignment

# This is for MasterPhase.v.6.r or later

# This is where all the new folders and files hould be created
wDir <- "/Users/Jdench/Desktop/SimulationRuns/PhaseSims/bLen/"
setwd(wDir)

# This reads in the Master Run Script file as an object to be later used
mFile <- readLines("MasterPhase.v.8.r", -1)
# This is a simple object which defines the name of the Phase control files we want to copy
mControl <- "Sim_Phase_Control.sim"

################ These are optional parameters I can define here to more easily change whne writting files ###############
# This is an object for defining which system these jobs are intended to be run upon.
# 1 - Aleph, 2- HPCVL, anything else is interpreted as local machine, we use 0 as convention,
# Note local machine is null at present as my shell is not setup with a queue to be submitted toward.
# However, this script could still be used to create the folders
mSystem <- 2
# This is if we want to redefine the number of epistatic paris to be simulated
mPairs <- 3
# This is to help in defining the sequence length
mseqLen <- 100
# This is to help in defining the number of replicates tob edone
mReps <- 100
# This variable used when multiple file pathing structures exist across varying systems
mAcc <- 1
##########################################################################################################################

# These are some objects that should not be varried to maintain consistency, any changes here must be recorded and affects how we may
# cycle through combinatory analysis later on.

# This is required to prevent R from taking 0.0005 and making it into scientific notation, which INDELible can't use
options("scipen"=1000, "digits"=6)
# These are used to interpret certain objects that are factors in our simulation but do not follow a simple 
# arithmetic series.  Usefull since we loop through simple series' to create our names and files\folers.
# These represent the branch lengths we will be simulating, these represent 2^-12 -> 2^-1
mLen <- c("0.00024414","0.00048828","0.00097656", "0.0019531", "0.0039062", "0.0078125","0.015625","0.03125", "0.0625", "0.125", "0.25", "0.5")
# These are kept as multiples of two in order to facilitate all tree types to be simulated
# NOTE: With tree type3 (user data) these are not factors!
mDer <- c(16,32,64,128)
# this is no longer a factor being considered in our experimentation
mOut <- 0

# this is used to handle the location where R exists, not mSystem !=1,2 are null as we wouldn't submit jobs in this way
if (mSystem == 1){
    rDir <- "/export/apps/R-3.1.1/bin/"
}else if (mSystem == 2){
	if (mAcc == 1) {rDir <- "/home/hpc3058/bin/R-3.1.2/bin/"}
	else if (mAcc == 2){rDir <- "/home/hpc3058/bin/R-3.1.2/bin/"}
	else if (mAcc == 3){rDir <- "/home/hpc3058/bin/R-3.1.2/bin/"}
}else{
    rDir <- ""

}

######## THESE ARE SOME PARAMETERS WHICH CAN BE SET WITH treeType == 3 ###############
# These define name of the user tree file and the outgroup sequences therein, called by their label.
# NOTE this tree must be present in the wDir folder as indicated in this script!
mtPath <- paste('"','JDett_Original.tree"',sep="")
mtOut <- 'c("S1","S3","S6","S8")'

####### STRUCTURE OF THE NOMENCLATURE FOR RUNS ##############
# E - epistasis is not simulate or is {0,1}
# D - # of dervied sequences simulated
# O - # of outgroup sequences simulated
# T - # the tree topology type used, being 1-symmetrical,2-pectinate,3-user defined
# L - Branch length 1-12 for {"0.00024414","0.00048828","0.00097656", "0.0019531", "0.0039062", "0.0078125","0.015625","0.03125", "0.0625", "0.125", "0.25", "0.5"}

# We will group jobs by branch lengths, previously we had thought by nDer and sEpi, but that would mean some jobs running much longer
# than others and since we have limited submission permissions to HPCVL it was best to take groups of 6
#############################################################

# This will run through all parameter permutations and create the approrpiate files
# NOTE: When changing a specific line, the index number should be the Smultron line number +1 (from experience)

for (tr in 1:3){
	# Here we make an exception of the case with a user tree topology, we will set d and o to 1
	# and the bLen to have 1 value as we only really need one file written and nOut, nDer and nSeq are handled internally
	# Same with branch length
	if (tr ==3) {
		mDer <- 2
		mOut <- 1
		mLen <- c(mLen,"0")
	}
	for (o in 1){ # This would be used only if I were to vary the number of outgroup sequences included in simulated trees - a functionality removed in intermediate versions.
		for (d in 1:length(mDer)){
			for (e in c(0,1)){
				for (l in 1:length(mLen)){
					# This identifier is the runName identifier
					rName <- paste("T",tr,"_L",l,"_D",mDer[d],"_E",e, sep="")
					# This creates the new folder for this particular run
					system(paste("mkdir -p ", wDir, rName))
					# This creates the job's specific submit file, at pressent if it's not on Alepg it's going to HPCVL, local machine doesn't need submits....
					if (mSystem !=2){
						cat(paste("qsub -N T",tr,"L",l,"D",mDer[d],"E", e," -pe orte 4 -cwd -j y -b y ",rDir,"R CMD BATCH Master",rName,".r", sep=""), file= paste(wDir, rName, "/Sub", rName, ".sh", sep=""), append=TRUE)
					} else {
						# the reason for the difference on HPCVL is to request a specific queue where x86 architecture is supported.
						cat(paste("qsub -q abaqus.q -N T",tr,"L",l,"D",mDer[d],"E", e," -pe dist.pe 4 -cwd -j y -b y ",rDir,"R CMD BATCH Master",rName,".r", sep=""), file= paste(wDir, rName, "/Sub", rName, ".sh", sep=""), append=TRUE)
					}
					# Must make the shell files executable for the runs to work, gives permissions to all users
					system(paste("chmod a+x ", wDir, rName, "/Sub", rName, ".sh", sep=""))
					
					# This create the Master submit job file, one for each D,O and T, each master will represent 12 jobs (E x L)
					# This adds all the job calls to the MasterSubmit job file
					cat(paste("cd ../", rName, sep=""), file= paste(wDir, "MasterT", tr,"D", d,"E",e,".sh", sep=""), append=TRUE, sep="\n")
				    cat(paste("./Sub", rName, ".sh", sep=""), file= paste(wDir, "MasterT", tr,"D", d,"E",e,".sh", sep=""), append=TRUE, sep="\n")
					
					
					# This writes the Master R file which will execute the run
					mFile[35] <- paste("nReps <- ", mReps, sep="")
					mFile[36] <- paste("seqLen <- ", mseqLen, sep="")
					# We multiply the number of ePairs by e, since e controls if this will be zero or have epistasis
					mFile[38] <- paste("ePairs <- ", mPairs*e, sep="")
					mFile[45] <- paste("sEpi <- ", e, sep="")
					mFile[49] <- paste("wSystem <- ", mSystem, sep="")
					# Here we make the account based adjustment for HPCVL locations, where mAcc == 1, jonathan; mAcc == 2 Stephane's
					if (mAcc == 1){
						# For jonathan's account this is the folder system
						mFile[59] <- '    bDir <- "/home/hpc3058/jonathan/"'
						mFile[60] <- '    phaseLoc <- "/home/hpc3058/bin/phase2.0/"'
						mFile[61] <- '    bayesLoc <- "/home/hpc3058/bin/BayesTraitsV2/"'
						mFile[71] <- 'wDir <- "SimulationRuns/PhaseSims/bLen/"'
					} else if (mAcc == 2){
						# for Stephane's account this is the folder system
						mFile[59] <- '    bDir <- "/home/hpc3028/groupWork/"'
						mFile[60] <- '    phaseLoc <- "/home/hpc3028/bin/phase2.0/"'
						mFile[61] <- '    bayesLoc <- "/home/hpc3028/bin/BayesTraitsV2/"'
						mFile[71] <- 'wDir <- "simulation/epistasis/p1/"'
					} else if (mAcc == 3){
						# for Stephane's account this is the folder system
						mFile[59] <- '    bDir <- "/home/hpc3060/support/"'
						mFile[60] <- '    phaseLoc <- "/home/hpc3060/bin/phase2.0/"'
						mFile[61] <- '    bayesLoc <- "/home/hpc3060/bin/BayesTraitsV2/"'
						mFile[71] <- 'wDir <- "dribble/newwork/job1/"'
					}
					mFile[73] <- paste('xDir <- "', rName,'" ',sep="")
					mFile[92] <- paste("nDer <- ", mDer[d], sep="")
					mFile[94] <- paste("nOut <- ", mOut[o], sep="")
					mFile[100] <- paste("bLen <- ", mLen[l],sep="")
					mFile[103] <- paste("treeType <- ", tr, sep="")
					
					# Here we set the treetype3 specific items
					if (tr == 3){
						mFile[106] <- paste("treePath <- ", mtPath, sep="")
						mFile[109] <- paste("treeOut <- ", mtOut, sep="")
					}
					# We now write out the Master.r script for this particular run
					writeLines(mFile, paste(wDir, rName, "/Master",rName,".r", sep=""))
					# This copies a phase control file into the proper directory
					system(paste("cp ",wDir,mControl," ",wDir,rName,sep=""))
				}
				# This fixes the first job called in each MAsterSubmit file 
			mSub <- readLines(paste(wDir, "MasterT", tr,"D", d,"E",e,".sh", sep=""),-1)
			# This will always be the first job called from any run since we bundle Master files by branch length
			mSub[1] <- paste("cd T", tr,"_L1_D",mDer[d],"_E",e, sep="")
			writeLines(mSub, paste(wDir, "MasterT", tr,"D", d,"E",e,".sh", sep=""))
			# Must make the shell files executable for the runs to work
			system(paste("chmod a+x ", wDir, "MasterT", tr,"D", d,"E",e,".sh", sep=""))
			}
		}
	}
}