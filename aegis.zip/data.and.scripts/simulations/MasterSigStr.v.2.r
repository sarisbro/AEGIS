# This will be the master file that combines all portions previously written and considered
# condensed as a single run file uses script previously used written by:
# Main Author: Jonathan Dench -
# Contributing Authors: Jean-Claude N., Stephane Aris-Brossou for some historical portions not entirely re-written
# also their experience and support has helped produce this.

# This program is designed to detect epistasis at the SNP level from nucleotide sequences
# It considers an outgroup as being sequence(s) which have not experienced the selection
# of interest that may be creating epistasis (basically if the character state has not changed from the ancestral sequence simulated)

# load library to read alignments
library(ape)
library(seqinr)
library(doMC)
library(foreach)
# library(locfit) # This used to be used for certain plotting functions, but not at present.

# First clean the session to make certain there are no other objects or items loaded
# This removes any hidden previous session info
system("rm .RData")
# This also removes any objects
rm(list=ls())
# This is to accomodate when we are writting files with particularly small branch lengths, it ensures numbers are not written in scientific format.
options("scipen"=1000, "digits"=6)

###################################################################################################
################# BEGIN OF PREDEFINITIONS #########################################################
###################################################################################################
# This section includes those objects/variables that the user should predefine before running the script
# It is a convenient way to change the input output of many downstream files

############# Run Definitions ##############
# It would be best to have the nReps, nSeq, bLen items read in from user input, but I have not chosen to implement this.....
# The number of replicates to be performed and total sequence length desired
nReps <- 100
seqLen <- 300
# This defines the number of epistatic pairs that we want to simulate (Note 2 n.t will be simulate for each pair)
ePairs <- 3
# Here we create a list of the possible characters our n.t.s can take, ### Note: this is no longer in use, we replaced it with ntVec downstream
#nTs <- c("A", "C", "G", "T")
# These are vectors defining which characters are purines or pyrimidines, no longer implemented in this version
#transPur <- c("A","G")
#transPyr <- c("C","T")
# Here we define if this run will have epistasis simulated 1 = Yes, 0 = No
sEpi <- 1

############# System Definitions ##############
# which computer is this script intended to be run on  -- NOTE: this was circumstancial to our computer resources, most users would use 0
wSystem <- 0 	# 1: run on uOttawa SGE cluster, #2: run on HPCVL, any other value local machine
# define how many cores we will request with doPar
registerDoMC(cores=4)
# This is the root file path dependent on the location that a run is submitted.  Also wcAdj adjusts the wc value to report on data. ## NOTE You may find your local machine needs a different wcAdj value, this is based on how the BayesTraits output tables are written by your system
if (wSystem == 1){
    bDir <- "/export/home/jonathan/"
    phaseLoc <- "/export/home/jonathan/phase2.0/"
    bayesLoc <- "/export/apps/"
    wcAdj <- 1
}else if (wSystem == 2){
    bDir <- "/home/hpc3058/jonathan/"
    phaseLoc <- "/home/hpc3058/bin/phase2.0/"
    bayesLoc <- "/home/hpc3058/bin/BayesTraitsV2/"
    wcAdj <- 2
}else{
    bDir <- "/Users/Jdench/Desktop/"
    phaseLoc <- "/Users/Jdench/Desktop/Jonathan_Dench/3rd_Party_Software/phase-2.0-src/"
    bayesLoc <- "/Users/Jdench/Desktop/Jonathan_Dench/3rd_Party_Software/BayesTraitsV2-Beta-OSX/"
    wcAdj <- 1
}

# This is the working directory which should share the same filepath across all machines for ease of later compilation
wDir <- "SimulationRuns/PhaseSims/Pilots/"
# This sets the true working directory where a particular run will take place, NOTE this directory must exist (yes I could implement a mkdir -p call but I didn't)
xDir <- "ToyProof"

# We set a single object for the true working directory to save time on filepath calls later on.
trueWD <- paste(bDir,wDir,xDir, sep="")
# Create one subfolder for each replicate run that will be performed as indicated by nReps
for (d in 1:nReps) system(paste("mkdir -p ",trueWD,"/Rep",d,sep=""))
# set the working directory for R
setwd(trueWD)

############# Tree Definitions ##############
# This section is to define tree topology to be used, and key downstream information

# NOTE NOTE NOTE the read.tree might allow me to obtain most of this infor directly from tree file
# Thus I may be able to to set the tree type first and then read.tree to file out nSeq and or other tree info.

## NOTE: If using real data this must be known ##
# Define the number of dervied sequences this tree will hold
# NOTE: If treeType == 1 then this should be a multiple of 2 or the lowest multiple
# of two will correspond to how many sequences are generated.
nDer <- 32
# Define the number of outgroup sequences this tree will hold
nOut <- 0
# This is the total number of sequences that will be in this tree
# Note this is subject to change as it may be re-evaluated once the tree is read
nSeq <- nDer + nOut
# This will represent the length of the branches and nodes, note they will all be the same
# This value is not important if using a pre-defined tree.
bLen <- 0.01
# This is an object that will have defined values to indicate if the tree to be used will be 
# 1 - symmetrical, 2 - pectinate, 3- predefined tree (ex: from real data)
treeType <- 1
###### USER TREE INFO ######### Only for treeType <- 3, otherwise downstream will change these values
# This is the filename of the user tree we want to load, note this tree must exist in each run base folder
treePath <- "JDett_Original.tree"
# This needs to be the branch labels which identify an outgroup sequences
# If these are not absolutely correct there will be downstream errors with proper analysis of derived state.
treeOut <- c("S1","S3","S6","S8")

###################################################################################################
################# END OF PREDEFINITIONS ###########################################################
###################################################################################################

###################################################################################################
###################### Start Definition of Functions ##############################################
###################################################################################################

# This function will determine the largest power of 2 that is less than the number entered
# This is only established to function with positive powers of 2.
sQrt <- function(vAlue){
	cOunt <- 0
	# If the value is less than 2 then we return this as 0 and stop
	if (vAlue >= 2){
		# Otherwise we know that this is at least a power of 2, this adjustment is needed 
		# as determined from practice
		cOunt <- 1
		# create a temporray value to compare against vAlue
		tmpNum <- 1
		while (tmpNum < vAlue){
			tmpNum <- tmpNum *2
			# This line account for when vAlue is larger than the current assesed power of 2
			# but not larger than that next value
			if (tmpNum *2 <= vAlue) { cOunt <- cOunt + 1 }
		}
		
	}
	return(cOunt)
}

# This will help us rebuild the true siteID once we have collapsed our traitMat into our builtMat
# Since we only analyse the builtMat, those sites we compare can each be equivalent to numerous other sites
# This scans each siteID value, and rebuilds that list[[]] into a list of all matching traitMat columns
trueSite <- function(siteList){
	trueList <- lapply(siteList,function(x){
		for (j in x:ncol(traitMat)){
			# If we find a matching column then we add it to the list of trueID's
			if (all(traitMat[,j] == traitMat[,x])) {x <- c(x, j)}
		}
		# The since we chekc the actual siteID traitMat column as the first value we must remove it afterward
		return(x[-1])
	})
	return(trueList)
}

# This is a function to take a list or vector and return a string of all the items separated by underscores
aString <- function(iVec){
	tmpVec <- NULL
	for (i in 1:length(iVec)){
		tmpVec <- paste(tmpVec,iVec[i],sep="_")
	}
	# Now we trim off the initial _ that get's placed
	tmpVec <- substr(tmpVec,2,nchar(tmpVec))
	return(tmpVec)
}

# This function will accept any site pattern matrix produced by the pipeline, entered as inpMat
# aLpha is the signficance alpha value to be considered
# s1Col, s2Col and pCol should be the column number of the inpMat column to identify proper columns
# to be used in calculations
postAnal <- function(inpMat, aLpha, s1Col, s2Col, pCol){
	### NOTE this postAnalysis accounts for true siteID's and is adjusted such that even though total # of comparisons
	# made is less than the presented FN, we are weighting all these values by the fact that the calculations are identical
	# across all comparisons of equal trueID, BUT not adjusted for the fact that monomorphic sites are not evaluated.
	
	############## Here we initialise certain objects for use downstream ########################
	# This will capture the name of the object passed into it, to be used in writting files
	objName <- deparse(substitute(inpMat))	
	# This dataframe will hold the summary information we care about
	sumMat <- data.frame("Rep"=tRep,"TP"=0, "FP"=0, "TN"=0, "FN"=0, "Num_ePairs"=ePairs,"All_ePairs"="", "IDed_TP"="", "Run_Time"=0,"p_Value"=0,"S1_Pat"=0,"S2_Pat"=0)
	# This will hold the rows at which we have significant sites as identified by pCol and aLpha		
	sigRow <- which(inpMat[,pCol] <= aLpha)
	# The number of ePairs defines the total number of epistatic pairs we should find
	# and the first ePairs*2 positions in the sequence will be the pairs such that if ePairs = 3
	# the first six sites will be ePair sites and pairs are (1,2),(3,4),(5,6)
	# This will be a means of easily identifying hwich sites should be considered as significant
	if (sEpi == 1){
		# We create a list of all possible ePairs, but if we did not simulate epistasis this is null
		eSites <- c(1:(2*ePairs))
		for (e in 1:ePairs){
			# Since epistatic pairs are the sequential first ePair # of pairs we just combine 1 and 2 +
			# an adjustment of 2*(e-1) for the number of iterations we've done
			sumMat$All_ePairs <- paste(sumMat$All_ePairs,1+(2*(e-1)),".",2+(2*(e-1)),"_",sep="")
		}
		# We just tidy up sumMat$IDed_TP a bit by removing that last _
		sumMat$All_ePairs <- substr(sumMat$All_ePairs,1,(nchar(sumMat$All_ePairs)-1))
		# We identify the number of TP
		# To do this we scan the significant site pairs and confirm which are true positives
		for (r in sigRow){
			# If there is a epistatic site that was found we proceed
			if (length(intersect(trueID[[as.numeric(inpMat[r,s1Col])]],eSites)) > 0){
				# First identify the significant site identified
				sigSite1 <- intersect(trueID[[as.numeric(inpMat[r,s1Col])]],eSites)
				# Now we need to identify if the paired site is present, since each odd# is paried with the subsequent
				# even numbered position this becomes an easy calculation
				# We loop this calculation for each element of sigSite1
				sigSite2 <- sapply(sigSite1,function(x){
					if (x %% 2 == 0){
						# This means the number is even so we look to sigSite - 1
						return(x - 1)
					} else {
						# This means the number is odd so we look to sigSite + 1
						return(x + 1)
					}
				})
				if (length(intersect(trueID[[as.numeric(inpMat[r,s2Col])]],(sigSite2))) > 0){ 
					# We multiply the number of TP by the number of coordinated intersections there was between
					# This is identified by the length of the intersect between s2's trueID[[]] and the sigSite2 object
					# intersections
					sumMat$TP <- as.numeric(sumMat$TP) + 1*(length(intersect(trueID[[as.numeric(inpMat[r,s2Col])]],(sigSite2))))
					# Now to we store the trueID of the sigSite's that were recovered, this is done by taking the indexes of sigSite1 and sigSite2 which had intersections
					for (z in which(sigSite2==intersect(trueID[[as.numeric(inpMat[r,s2Col])]],(sigSite2)))){
						sumMat$IDed_TP <- paste(sumMat$IDed_TP,sigSite1[z],".",sigSite2[z],"_",sep="")
					}
					# If we have a true significant pair then we want to store their site patterns for latter use, we create a string to fit them within this table
					#sumMat$S1_Pat <- aString(builtMat[,inpMat[r,s1Col]])
					#sumMat$S2_Pat <- aString(builtMat[,inpMat[r,s2Col]])
				}			
			} 
		}
		# If no significant sites were found then there will be nothing written in IDed_TP so we handle this in two cases
		# First is when there were no sigRows
		if (length(sigRow)==0){sumMat$IDed_TP <- sumMat$S1_Pat <- sumMat$S2_Pat <- "None "}
		# The other is when there were not sigRows that had two properly paired sites meaning out identifier is blank
		if (sumMat$IDed_TP == ""){sumMat$IDed_TP <- sumMat$S1_Pat <- sumMat$S2_Pat <- "None "}
		# We just tidy up sumMat$IDed_TP a bit by removing that last _
		sumMat$IDed_TP <- substr(sumMat$IDed_TP,1,(nchar(sumMat$IDed_TP)-1))
	} else if (sEpi == 0){
		# There are no true positives thus we simply assign
		sumMat$S1_Pat <- sumMat$S2_Pat <- "None"
		sumMat$IDed_TP <- sumMat$All_ePairs <- "None"
		sumMat$TP <- 0
	}
		
	# Now we add a number of FP for the length of the trueID's that matches s1 and s2 within each sigRow and adjusting by simply subtracting the number of TP's
	# we simply loop throug each sigRow, take the length of the trueID[[]] at both site's and multiply them
	# One condition is that this calculation changes if sigRow is == 0, in which case FP simply equals 0, which is our default value
	if (length(sigRow) > 0){
		sumMat$FP <- sum(sapply(sigRow,function(r){
			as.numeric(sumMat$FP) + 1*(length(trueID[[as.numeric(inpMat[r,s1Col])]])*length(trueID[[as.numeric(inpMat[r,s2Col])]]))
		}))
		# This is the final adjustment of removing those TP we have found, however it is possible we found more TP than FP
		# in which case we simply leave the number false positives as 0.  Note this shouldn't be possible considering how we calculate FP
		# but this acts as a fail safe, such that if #TP is greater than #FP we leave the value as is (i.e. zero the initial value 
		if (as.numeric(sumMat$FP) >= as.numeric(sumMat$TP)){
			sumMat$FP <- as.numeric(sumMat$FP) - as.numeric(sumMat$TP)
		}
	}
	
	# We identify the number of FN, this is simply the total number of pairs possible - TP
	sumMat$FN <- ePairs - as.numeric(sumMat$TP)
	
	# We identify the number of TN, this is simply the number of comparrisons made that were not TP, FP or TN
	# The number of comaprisons made, in a pariwise system will be n(n-1)/2
	sumMat$TN <- ((seqLen-numMono)*(seqLen-numMono-1)/2) - sumMat$FN - sumMat$TP - sumMat$FP
	
	# The time taken to perform the BayesTraits Analysis
	sumMat$Run_Time <- sum(time_par1[1:5])
	
	########## THESE LAST TWO ARE sigStr simulation specific ###############
	# We will assign the p-value associated to this run which is the p value column of the input matrix
	sumMat$p_Value <- inpMat[,pCol]
	# Here we will just add the site patterns for our sites regardless of the outcoume
	sumMat$S1_Pat <- aString(builtMat[,1])
	sumMat$S2_Pat <- aString(builtMat[,2])
	
	# Here we write out files for latter batch analysis
	return(sumMat)
}
	
###################################################################################################
######################### End Definition of Functions #############################################
###################################################################################################

#########################################################################################
####### Brief interuption to handle mid-point data loading of analysis table ############
#########################################################################################
# We saved the site pattern for this file as created by the sigStr file writter, this gets us a sitePattern object
load(file=paste(trueWD,"/",xDir,"/sitePattern.RData",sep=""))

# Here we establish two data frames that will handle all our post analysis information
#analMat <- data.frame("Rep"=0,"TP"=0, "FP"=0, "TN"=0, "FN"=0,"Num_ePairs"=ePairs, "All_ePairs"="", "IDed_TP"="", "Run_Time"=0,"p_Value"=0,S1_Pat"=0,"S2_Pat"=0)
fdrMat <- data.frame("Rep"=0,"TP"=0, "FP"=0, "TN"=0, "FN"=0,"Num_ePairs"=ePairs, "All_ePairs"="", "IDed_TP"="", "Run_Time"=0,"p_Value"=0,"S1_Pat"=0,"S2_Pat"=0)
#########################################################################################
#########################################################################################

# Here we will lopp through shuffled combinations of the site pattern order within the tree 500 reps was decided as 
# sufficient to shuffle the placement and generate a trend/approach expectation that is unnafected by placement
# Since each combination of values has this same shuffle and we will analyse relative strengths of p-value &\OR q-value
for (tRep in 1:nReps){
	# Here we generate a vector of the order by which we assign each the pair values to rows, in this way the final
	# site pattern is randomised across each replicate - to some extent - while the number of pair value types will 
	# remain unchanged.  This should control for tree shape when considering the signal strength
	tOrder <- sample(1:nSeq,nSeq,replace=FALSE)
	
	# We generate our builtMat which will store our pair values shuffled from sitePattern matrix that we created in sigStr writter
	builtMat <- sitePattern[tOrder,]
	
	# We set the curDir object which dictates the directory of this job
	curDir <- paste(trueWD,"/",xDir,"/Rep",tRep,"/",sep="")
	
	###################################################################################################
	######################### Start of BayesTraits Anaylis ############################################
	###################################################################################################
	# parallel version 1
	# We read in our tree just to get label names
	tTree <- read.tree(file=paste(trueWD,"/FullSimTree.tree",sep=""))
	sp_names <- tTree$tip.label
	
	# initialize object containing results
	pairAMat<- matrix(nrow=1,ncol=6)
	# starts the clock
	ptm <- proc.time()
	# start the loops; only inner loop forks processes
	for(i in 2:ncol(builtMat)){
	    for (j in 1){
	        print(paste("Now doing pair of sites ",j," / ",i,sep=""))
	        #sp_names <- attributes(aln)$names
	        col1 <- col1bis <- builtMat[,j]
	        col2 <- col2bis <- builtMat[,i]
	        
	        # remove cols w/ "-" if there is an "-" in either site both sites are NAed
	        col1bis[which(col2bis=="-")] <- NA
	        col2bis[which(col2bis=="-")] <- NA
	        col2bis[which(col1bis=="-")] <- NA
	        col1bis[which(col1bis=="-")] <- NA
	        if(!identical(col1bis,col2bis)){
	            trait_data <- data.frame(sp_names, col1, col2)
	            colnames(trait_data) <- NULL
	            write.table(trait_data, paste(curDir,"traits.",i,".",j,".txt",sep=""),quote=F,row.names=F)
	            
	            # run BayesTraits under the dependent and indep models
	            ########### NOTE: The Input files InputBT_ML_indep.txt, InputBT_ML_dep.txt must be placed into each wd
	            system(paste(bayesLoc, "BayesTraits ",trueWD,"/NexusSimTree.tree ",curDir,"traits.",i,".",j,".txt < ", trueWD,"/InputBT_ML_indep.txt > ",curDir,"traits_res_indep.",i,".",j,".txt",sep=""))
	            system(paste(bayesLoc, "BayesTraits ",trueWD,"/NexusSimTree.tree ",curDir,"traits.",i,".",j,".txt < ", trueWD,"/InputBT_ML_dep.txt > ",curDir,"traits_res_dep.",i,".",j,".txt",sep=""))
	            
	            # extract likelihood values, by counting the # of lines in the traits_res_indep.i.j.txt file
	            system(paste("wc -l ",curDir,"traits_res_indep.",i,".",j,".txt > ",curDir,"wc",i,".",j,".txt",sep=""))
	            # This reads the wc file produce which should have simply the number of lines in the file
	            wc <- read.table(paste(curDir,"wc",i,".",j,".txt",sep=""))
	            # Since the last line in the "traits" file is the valuable output from ByesTraits, we skip wc[1] -1 lines, to read the last.
	            res_indep <- read.table(paste(curDir,"traits_res_indep.",i,".",j,".txt",sep=""),header=F,fill=T,skip=as.numeric(wc[1]-wcAdj))
	            # Repeat now for the dependent model
	            system(paste("wc -l ",curDir,"traits_res_dep.",i,".",j,".txt > ",curDir,"wc",i,".",j,".txt",sep=""))
	            wc <- read.table(paste(curDir,"wc",i,".",j,".txt",sep=""))
	            res_dep <- read.table(paste(curDir,"traits_res_dep.",i,".",j,".txt",sep=""),header=F,fill=T,skip=as.numeric(wc[1]-wcAdj))
	            # This adjustment is required only beacuse on the HPCVL server the traits_res_indep & _dep files contain an additional line
	            # after results section leading to a table read in with 2 rows, yet we only need to 1 row's value.
	            res_dep <- res_dep[1,]
	            res_indep <- res_indep[1,]
	            # cleanup tmp files releasing them from memory
	            unlink(paste(curDir,"traits_res_indep.",i,".",j,".txt",sep=""))
	            unlink(paste(curDir,"traits_res_dep.",i,".",j,".txt",sep=""))
	            unlink(paste(curDir,"traits.",i,".",j,".txt",sep=""))
	            unlink(paste(curDir,"traits.",i,".",j,".txt.log.txt",sep=""))
	            unlink(paste(curDir,"wc",i,".",j,".txt",sep=""))
	            unlink(paste(curDir,"traits.",i,".",j,".txt.log.txt.Schedule.txt",sep=""))
	            
	            # Since we expect our Bayes values to be negative this tests to assure us we are within expectations otherwise ignore
	            if((res_indep[,2] < 0) & (res_dep[,2] < 0)){
	                # As this is a two sided test we multiply our test stat by two
	                test_stat <- 2 * abs(res_indep[,2] - res_dep[,2])
	                # this should be the last instruction of the foreach loop
	                # This caculatees the significance of our Bayes Factor and other information in a vector
	                pairAMat_tmp <- (c(j, i, res_indep[,2], res_dep[,2], test_stat, 1-pchisq(test_stat,4)))
	            }
	        }
	    }
	    # merge objects into pairAMatto build a memory of each bayesTraits run
	    pairAMat<- rbind(pairAMat, pairAMat_tmp)
	}
	# Stop the clock
	time_par1 <- proc.time() - ptm
	
	colnames(pairAMat) <- c("siteID_1","siteID_2","lkl_indep","lkl_dep","test_stat","pvalue")
	pairAMat<- na.omit(pairAMat)
	pairAMat<- data.frame(pairAMat)
	
	# FDR calculation, add actual site positions and sort by P-value
	adj_p <- p.adjust(pairAMat$pvalue, "BH")
	pairAMat_adj <- cbind(pairAMat, adj_p)
	
	colnames(pairAMat_adj) <- c(colnames(pairAMat), "pvalue_fdr")
	pairAMat_adj_sorted <- pairAMat_adj[order(pairAMat_adj$pvalue),]
	
	# Here we rebuilt the list of all true SiteID's, since siteID only has the indexes of sites from builtMat (which is reduced in site length)
	trueID <- list(1,2)
	
	# We initialise two new columns that we will populate with trueIDs, I used to have a less explicit description for adding
	# these two new columns, it seemed cleaner, but gotr rejected on HPCVL servers.  so this more cumbersome but explicit
	# manner has been adopted.
	pairAMat_adj_sorted <- cbind(pairAMat_adj_sorted,rep(0,nrow(pairAMat_adj_sorted)),rep(0,nrow(pairAMat_adj_sorted)))
	colnames(pairAMat_adj_sorted) <- c("siteID_1","siteID_2","lkl_indep","lkl_dep","test_stat","pvalue","pvalue_fdr","true_S1","true_S2")
	
	# Now we add a few new column values to our dataframe with our trueID's
	for (s in 1:length(trueID)){
		# The if statements are to prevent a crash in the event there is no intersection
		# The actions taken are to assign strings of those trueId's which match the siteID's identified.  Done for site 1 and 2
		# We take advatage of the fact that siteID and trueID have the same length and the siteID's identified are by 1:length(siteID)
		# as defined by our builtMat column #'s
		if (length(which(pairAMat_adj_sorted$siteID_1==s))!=0){
			pairAMat_adj_sorted$true_S1[which(pairAMat_adj_sorted$siteID_1== s)] <- aString(trueID[[s]])
		}
		if (length(which(pairAMat_adj_sorted$siteID_2==s))!=0){
			pairAMat_adj_sorted$true_S2[which(pairAMat_adj_sorted$siteID_2== s)] <- aString(trueID[[s]])
		}
	
	}
	
	# write results to file
	write.csv(pairAMat_adj_sorted, paste(curDir,"pairAMat_adj_sorted.csv",sep=""), quote=F, row.names=F) # relocated and set row.names to "F"

	###################################################################################################
	######################### End of of BayesTraits Anaylis ###########################################
	###################################################################################################
	
	###################################################################################################
	######################### Start of Post Analysis  #################################################
	###################################################################################################
	
	# Here we will run the post analysis for our two matrices of interest pairAMat, pairAMat_adj
	# And within those for the alpha value of interest
	
	# This is done because it was found when sEpi <- 0 and ePairs <- 0, somehow ePairs was being considered as <- 3
	# in final analysis, so here we are trying to force the situation to test where the issue is arising.
	#if (sEpi == 0){ePairs <- 0}
	# This object assignment is due to the nature of this run type
	numMono <- 0
	# q-value and p-value are equivalent in this simulation since # comparissons = 1
	# analMat <- rbind(analMat, postAnal(pairAMat,0.05,1,2,6))
	fdrMat <- rbind(fdrMat, postAnal(pairAMat_adj,0.05,1,2,7))

	save.image(paste(curDir,"step1.RData",sep=""))
	################################################################################################
	################################################################################################  
}  

# Now we write out our two post analysis matrices without the first initialising row
#write.csv(analMat[-1,], paste(trueWD,"/",xDir,"/RunPostAnalysis.csv",sep=""), quote=F, row.names=F)
write.csv(fdrMat[-1,], paste(trueWD,"/",xDir,"/RunPostAnalysis_FDR.csv",sep=""), quote=F, row.names=F)	

q(save="no")
