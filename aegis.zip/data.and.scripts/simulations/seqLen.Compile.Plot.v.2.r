# This script will combine all the post analysis files from our Simulation runs of the seqLen runs.
# Here we will generate a large data series to analyse the effects of length of a sequence on the FDR corrected p-value


library(MASS) # I don't like the plots this made, however the call to plot with it still exists in this script for posterity.

#################################################################################################
############################## Predefinitions Section ###########################################
#################################################################################################

# Identify how many replicates there were in the simulation run being analysed.
nRep <- 10
# This is a list of the filenames to be reviewed for run output  
fNames <- c("RunPostAnalysis_FDR.csv")
# This is the name of the compilation file to be created\used by this plotting, update this when dealing with new data
# This will then make the compilation call once and skip in future pass through.
compFile <- "seqLen_Compiled.RData"
# Here we define the name of the RData information that should be stored in each tree_sequence's folder telling us which jobs were run
runFile <- "Job_Matrices.RData"
# These are dimensional layer names, items used for filling in the data.frame and plots
cLabel <- c("TP", "FP", "TN", "FN")
dLabel <- c("16", "32", "64", "128")
lLabel <- c("10","20","40","80","160","320","640","1280")
tLabel <- c("Symetrical", "Pectinate", "Empirical Data")
cdSeq <- seq(1,10,by=1)
# These are lists of setting for output in plots to assign colour and character points for bLen plots
colSig <- c("blue","cyan","yellow","orange","red")
colSeq <- c("red","purple","blue")
colMat <- matrix(c("hotpink1","red1","red3","cornflowerblue","blue1","blue4","gray60","gray40","black"),ncol=length(colSeq))
pchSeq <- c(15,16,17)
# These are lists of setting for output with our barplots of treeType by nSeq
tcolSeq <- c("red1","blue1","gray60")

# This is requiblack to prevent R from taking 0.0005 and making it into scientific notation, which INDELible can't use
options("scipen"=100, "digits"=6)

# Set our working directory object
wDir <- ("/Users/Jdench/Desktop/SimulationRuns/PhaseSims/Pilots/seqLen/")
# This is the output folder out plots
pDir <- "seqLen_Plots/"

# Set the wd to be the one where we write our post analysis plots
setwd(paste(wDir,pDir,sep="")) 

#################################################################################################
################################ Funcitons Section ##############################################
#################################################################################################

# This function will determine the largest power of 2 that is less than the number entered
# This is only established to function with positive powers of 2.
sQrt <- function(vAlue){
	cOunt <- 0
	# If the value is less than 2 then we return this as 0 and stop
	if (vAlue >= 2){
		# Otherwise we know that this is at least a power of 2, this adjustment is needed 
		# as determined from practice
		cOunt <- 1
		# create a temporray value to compare against vAlue
		tmpNum <- 1
		while (tmpNum < vAlue){
			tmpNum <- tmpNum *2
			# This line account for when vAlue is larger than the current assesed power of 2
			# but not larger than that next value
			if (tmpNum *2 <= vAlue) { cOunt <- cOunt + 1 }
		}
		
	}
	return(cOunt)
}

compOutput <- function(thisDir){
	# Taking the input of which directory to search we will then be able to compile all the information
	if (file.exists(paste(wDir,thisDir,fNames,sep=""))){
		# Now we simply open each appropriate folder, and rbind the (cbind(fNames file + factors)) to our compFrame 
		compFrame <- rbind(compFrame, cbind(read.csv(paste(wDir, thisDir,fNames,sep=""),header=TRUE),"seqLen"=n,"nSeq"=d,"Run"=rName))
		# Here we verify if there have been any jobs missed, in the event of seqLen >=320 each rep is a job
		if (n < 320){
			missRun <<- rbind(missRun, c(paste("N",n,"D",d,sep=""),0))
		} else {
			missRun <<- rbind(missRun, c(paste("N",n,"D",d,"Rep",tRep,sep=""),0))
			# In the event that each rep is a separate job we need to update the rep value stored by the output file
			compFrame$Rep[nrow(compFrame)] <- tRep
		}
	} else {
		if (n < 320){
			missRun <<- rbind(missRun, c(paste("N",n,"D",d,sep=""),1))
		} else {
			missRun <<- rbind(missRun, c(paste("N",n,"D",d,"Rep",tRep,sep=""),1))
		}
	}
	return(compFrame)
}


#################################################################################################
########################### Building the Compiled Data Frame ####################################
#################################################################################################
# Here we run through all the folders that contain the output of runs, this process need only be run once
# it will then save an object of this compilation which can be loaded later

# This is a simple counter to identify if a run has been missed 
missRun <- data.frame("Run"= 0,"Missed"= 1)
# We initialise the data frame that will be used to store our post run information 
compFrame <- data.frame("Rep"=0,"TP"=0,"FP"=0,"TN"=0,"FN"=0,"Num_ePairs"=0,"All_ePairs"="","IDed_TP"="","Run_Time"=0,"p_Value"=0,"q_Value"=0,"Num_Comps"=0,"seqLen"=0,"nSeq"=0,"Run"="")
# This will first search for the designed output file and only run compilation if not present 
if (file.exists(paste(wDir,compFile,sep="")) == FALSE){
	
	# Now we cycle through factors and rbind each file within folders.
	for (d in as.numeric(dLabel[-1])){
		# This is the number of sequences factor, for tree type 3 there is only 32 sequences to be observed.
		for (n in as.numeric(lLabel)){
			# The run name is defined here
			rName <- paste("N",n,"_D",d,sep="")
			# We actually wrote our files differently so that sequence lengths of >= 320 we created separate jobs from reps
			# so here we just need to set our curDir differently when sequence length 320 or more.
			if (n < 320){
				curDir <- paste("N",n,"_D",d,"/",sep="")
				compFrame <- compOutput(curDir)
			} else {
				# This takes the number of replicates and makes certain to search each one for an output file
				for (tRep in 1:nRep){
					curDir <- paste("N",n,"_D",d,"/Rep",tRep,"/",sep="")
					# Take our curDir and then compile our dataframe
					compFrame <- compOutput(curDir)
				}
			}
		}
	}
	missRun <- missRun[-1,]
	# Now we remove the initialising row from our dataframe as well as certain other columns which are not needed, namely TN,FN, Num_ePairs, All_ePairs and IDed_TP
	compFrame <- compFrame[-1,-(7:8)]
	# We make the "Run" and other items factors so that we can use it's levels attribute to group by Run	
	compFrame$Run <- factor(compFrame$Run)
	
	# Now we create a new column for the relative q_Value, this looks at those reps within a number of sequences but across all seqLen
	for (d in dLabel[-1]){
		tmpRows <- which(compFrame$nSeq == as.numeric(d))
		wFrame <- compFrame[tmpRows,]
		# Here we find the maximum and minimum q_Values, but recall that the lowest q_Value is the most significant (thus the true MAX)
		tmpVals <- c(min(wFrame$q_Value),max(wFrame$q_Value))
		# Now we calculate the rel q_Value for those rows that correspond to our as a function (x - worst q_Value)/(best q_Value - worst q_Value)
		compFrame$Rel_q_nSeq[tmpRows] <- sapply(wFrame$q_Value,function(x){(x-tmpVals[2])/(tmpVals[1]-tmpVals[2])})
	}
		
	if (mean(as.numeric(missRun$Missed)) == 0){
		# Now we write out the compiled compFrame object so that for later runs it can be loaded and save time
		save(compFrame, file=paste(wDir,compFile,sep=""))
	}
} else {
	load(paste(wDir,compFile,sep=""))
}
#################################################################################################
########################  seqLen vs. Num_Comps per nSeq - with lmfit  ###########################
#################################################################################################

# This is for our dependent variable which in this case is the number of comparissons
for (tDepVar in "Num_Comps"){
	# We create some data output arrays to hold information that we will want to plot, the column setting of 10 reflects the number of confusion symbols we could have included 1:10
	tIqr <- tSdev <- tMean <- matrix(NA, nrow=length(dLabel[-1]),ncol=length(lLabel), dimnames=list(dLabel[-1],lLabel))
	# We create a list to hold all the linear mean models that we will calculate, we need one for each level of i
	lmList <- list()
	# This allows us to cycle through our number of aligned sequences
	for (i in 1:length(dLabel[-1])){
		# this is for the sequence length variable
		for (j in 1:length(lLabel)){
				# This takes out the small intersection of data we need for this particular cross section of nSeq, bLen, tree_type and sEpi
				wFrame <- compFrame[intersect(which(compFrame$nSeq == dLabel[i+1]),which(compFrame$seqLen == lLabel[j])),]
				# Now we will fill up our tMean and tSdev matrices 
				tMean[i,j] <- mean(log(wFrame[, tDepVar],2))
				tSdev[i,j] <- sd(log(wFrame[, tDepVar],2))
				tIqr[i,j] <- IQR(wFrame[, tDepVar])
				# We want to create a linear fit model for each number of sequences which are the different "data series"
				# The point of the +1 to dLabel is that we are ignoring nSeq == 16, yet it still exists in the object vector.
				lmList[[i]] <- lm(log(Num_Comps,2)~log(seqLen/10,2),data=compFrame[which(compFrame$nSeq == dLabel[i+1]),])
		}
	}
	
	# This assigns the y-axis label based on this run
	tYlab <- paste("log_2 of Mean ", tDepVar,sep="")
	# Now we will identify the y-axis limits by using the max values and dividing by 5
	tYseq <- seq(0,signif(max(tMean),1),by=(signif(max(tMean),1)/5))
	# the sequence length was done as a function of 10*2^n, so we plot on that scale
	tXseq <- log(as.numeric(lLabel)/10,2)
	
	# We want to plot each number of sequences, we will match all same tree elements by colour, and distinguish nSeq elemetns by pch character.
	for (i in 1:nrow(tMean)){
		# for our first scenario we need to set-up the plot
		if (i == 1){
			# Now we start by opening the connection to the output device - pdf. 
			pdf(paste("seqLen_",tDepVar,".pdf",sep=""),width=6,height=4)
			# Now we start building our plot from the first row of the tMean matrix and working through the other's
			plot(tXseq,tMean[i,],xlim = c(min(tXseq)*1.01,max(tXseq)*1.01), ylim = c(0,max(tYseq)) ,ylab = tYlab, xlab = "Sequence length (nt)", xpd=FALSE, axes=FALSE, type="p", col=colSeq[i], pch = pchSeq[i], lty = 1, lwd = 2)
			axis(1, at = tXseq, labels = lLabel)
			axis(2, at = tYseq, labels= tYseq)
			# Now we plot the linear mean of the data
			abline(lmList[[i]], col=colSeq[i], lty = 1, lwd = 2)
			# Arrows funciton is used to plot the error bars where we define the x,y coords of the upper and lower arrows respectively
			# Which is then followed by the colour, angle of the arrow head and "code" defines which set of coords are used - 3 options and code=3 is both.
			arrows(tXseq,(tMean[i,]+tSdev[i,]), tXseq,(tMean[i,]-tSdev[i,]),col=colSeq[i],angle=90,length=0.05,code=3, lty = 2, lwd = 1)
		# In all other cases we can simply add points and arrows (error bars)	
		} else {
			# points adds a new data series to our growing plot.
			points(tXseq,tMean[i,], col=colSeq[i], pch = pchSeq[i], type = "p", lty = 1, lwd = 2)
			
			# This does not seem to work properly to create lines between our points, mayb e due to CDprp not being integrated and that CD num lacks complete data.
			#lines(tXseq,tMean[i,], col=colSeq[i], pch = pchSeq[i], type = "b", lty = 1, lwd = 2)
			
			# Now we plot the linear mean of the data
			abline(lmList[[i]], col=colSeq[i], lty = 1, lwd = 2)
			
			arrows(tXseq,(tMean[i,]+tSdev[i,]), tXseq,(tMean[i,]-tSdev[i,]),col=colSeq[i],angle=90,length=0.05,code=3, lty = 2, lwd = 1)
			# Now we advance our counter
		}
	}
	# Here we create a grid which is the combinations of tMean dimensions that have been plotted and need legend references, 
	# the first and 3rd dimensions represent nSeq and tree_type respectively
	tLeg <- unlist(dimnames(tMean)[1])
	# Now we are building a vector object of the slopes from our linear model list so that we can add this to the legend
	slopeLeg <- NULL
	for(x in 1:length(lmList)){
		slopeLeg <- c(slopeLeg,round(coef(lmList[[x]])[2],3))
	}
	# Now we add our legend which tells us that the number of sequences is divided by shape and the tree type by colour.  the ncol here uses the number of tLeg columns
	# to divide up our series evenly so that each column will be one type of the second dimension of tLeg, in this case tree_type
	
	legend("bottomleft",inset=c(0.2,0),cex=0.80,c(paste(tLeg," sequences : slope = ",slopeLeg,sep="")),bty="n",col=colSeq, pch= pchSeq, horiz=TRUE)
	dev.off()
}

#################################################################################################
#########################  q_Value vs. seqLen per nSeq - with lm fit ############################
#################################################################################################

# This is for our dependent variable which in this case is the number of comparissons
for (tDepVar in "q_Value"){
	# We create some data output arrays to hold information that we will want to plot, the column setting of 10 reflects the number of confusion symbols we could have included 1:10
	tIqr <- tSdev <- tMean <- matrix(NA, nrow=length(dLabel[-1]),ncol=length(lLabel), dimnames=list(dLabel[-1],lLabel))
	# We create a list to hold all the linear mean models that we will calculate, we need one for each level of i
	lmList <- list() 
	# This allows us to cycle through our number of aligned sequences
	for (i in 1:length(dLabel[-1])){
		# this is for the sequence length variable
		for (j in 1:length(lLabel)){
			# This takes out the small intersection of data we need for this particular cross section of nSeq, bLen, tree_type and sEpi
			wFrame <- compFrame[intersect(which(compFrame$nSeq == dLabel[i+1]),which(compFrame$seqLen == lLabel[j])),]
			# Now we will fill up our tMean and tSdev matrices 
			tMean[i,j] <- mean(-log(wFrame[, tDepVar],2))
			tSdev[i,j] <- sd(-log(wFrame[, tDepVar],2))
			tIqr[i,j] <- IQR(wFrame[, tDepVar])
			lmList[[i]] <- lm(-log(q_Value,2)~ log(seqLen/10,2),data=compFrame[which(compFrame$nSeq == dLabel[i+1]),])
		}
	}
	
	# This assigns the y-axis label based on this run
	tYlab <- paste("Mean -log2 ", tolower(tDepVar),sep="")
	# Now we will identify the y-axis limits by using the max values and dividing by 5
	#tYseq <- seq(0,min(tMean)*1.20,by=(round(min(tMean)*1.05,1)/5))
	# To have this graph be more relatable to the Num_Comps graph we want the scales to have the same tick size thus 2^4
	# Using knowledge of our data we know that -52 is greater than the smallest q_Value calculated
	tYseq <- seq(0,52,by=4)
	# the sequence length was done as a function of 10*2^n, so we plot on that scale
	tXseq <- log(as.numeric(lLabel)/10,2)
	
	# We want to plot each number of sequences, we will match all same tree elements by colour, and distinguish nSeq elemetns by pch character.
	for (i in 1:nrow(tMean)){
		# for our first scenario we need to set-up the plot
		if (i == 1){
			# Now we start by opening the connection to the output device - pdf. 
			pdf(paste("seqLen_",tDepVar,".pdf",sep=""),width=10,height=7.5)
			# Now we start building our plot from the first row of the tMean matrix and working through the other's
			plot(tXseq,tMean[i,],xlim = c(min(tXseq)*1.01,max(tXseq)*1.01), ylim = c(0,max(tYseq)) ,ylab = tYlab, xlab = "Sequence length (nt)", xpd=FALSE, axes=FALSE, type="p", col=colMat[i,1], pch = pchSeq[i], lty = 1, lwd = 2, cex.lab = 1.5)
			axis(1, at = tXseq, labels = lLabel, cex.axis = 1.2)
			axis(2, at = tYseq, labels= tYseq, cex.axis = 1.2)
			# Now we plot the linear mean of the data
			abline(lmList[[i]], col=colMat[i,1], lty = 1, lwd = 2)
			# Arrows funciton is used to plot the error bars where we define the x,y coords of the upper and lower arrows respectively
			# Which is then followed by the colour, angle of the arrow head and "code" defines which set of coords are used - 3 options and code=3 is both.
			arrows(tXseq,(tMean[i,]+tSdev[i,]), tXseq,(tMean[i,]-tSdev[i,]),col=colMat[i,1],angle=90,length=0.05,code=3, lty = 2, lwd = 1)
		# In all other cases we can simply add points and arrows (error bars)	
		} else {
			# points adds a new data series to our growing plot.
			points(tXseq,tMean[i,], col=colMat[i,1], pch = pchSeq[i], type = "p", lty = 1, lwd = 2)
			
			# This does not seem to work properly to create lines between our points, mayb e due to CDprp not being integrated and that CD num lacks complete data.
			#lines(tXseq,tMean[i,], col=colSeq[i], pch = pchSeq[i], type = "b", lty = 1, lwd = 2)
			# Now we plot the linear mean of the data
			abline(lmList[[i]], col=colMat[i,1], lty = 1, lwd = 2)
			
			arrows(tXseq,(tMean[i,]+tSdev[i,]), tXseq,(tMean[i,]-tSdev[i,]),col=colMat[i,1],angle=90,length=0.05,code=3, lty = 2, lwd = 1)
			# Now we advance our counter
		}
	}
	# Now we add a line across the significance limit of 0.05 to show where the cutoff point is.
	lines(tXseq,rep(-log(0.01,2),length(tXseq)), lty=2,lwd=2, col="black")
	# Here we create a grid which is the combinations of tMean dimensions that have been plotted and need legend references, 
	# the first and 3rd dimensions represent nSeq and tree_type respectively
	tLeg <- unlist(dimnames(tMean)[1])
	# Now we are building a vector object of the slopes from our linear model list so that we can add this to the legend
	slopeLeg <- NULL
	for(x in 1:length(lmList)){
		slopeLeg <- c(slopeLeg,round(coef(lmList[[x]])[2],3))
	}
	# Now we add our legend which tells us that the number of sequences is divided by shape and the tree type by colour.  the ncol here uses the number of tLeg columns
	# to divide up our series evenly so that each column will be one type of the second dimension of tLeg, in this case tree_type
	legend("topright",inset=c(0,0),cex=1.2,c(paste(tLeg," sequences : slope = ",slopeLeg,sep="")),bty="n",col=colMat[,1], pch= pchSeq)
	dev.off()
}

#################################################################################################
###########################  rel. q_Value vs. seqLen per nSeq  ##################################
#################################################################################################

# This is for our dependent variable which in this case is the number of comparissons
for (tDepVar in "Rel_q_nSeq"){
	# We create some data output arrays to hold information that we will want to plot, the column setting of 10 reflects the number of confusion symbols we could have included 1:10
	tIqr <- tSdev <- tMean <- matrix(NA, nrow=length(dLabel[-1]),ncol=length(lLabel), dimnames=list(dLabel[-1],lLabel))
	# This allows us to cycle through our number of aligned sequences
	for (i in 1:length(dLabel[-1])){
		# this is for the sequence length variable
		for (j in 1:length(lLabel)){
				# This takes out the small intersection of data we need for this particular cross section of nSeq, bLen, tree_type and sEpi
				wFrame <- compFrame[intersect(which(compFrame$nSeq == dLabel[i+1]),which(compFrame$seqLen == lLabel[j])),]
				# Now we will fill up our tMean and tSdev matrices 
				tMean[i,j] <- mean(wFrame[, tDepVar])
				tSdev[i,j] <- sd(wFrame[, tDepVar])
				tIqr[i,j] <- IQR(wFrame[, tDepVar])
		}
	}
	
	# This assigns the y-axis label based on this run
	tYlab <- paste("Mean of relative q-value",sep="")
	# Now we will identify the y-axis limits knowing that our relative values go from 1 to 0, where 0 is the most significant q-Value
	tYseq <- seq(1,0,by=-0.2)
	# the sequence length was done as a function of 10*2^n, so we plot on that scale
	tXseq <- log(as.numeric(lLabel)/10,2)
	
	# We want to plot each number of sequences, we will match all same tree elements by colour, and distinguish nSeq elemetns by pch character.
	for (i in 1:nrow(tMean)){
		# for our first scenario we need to set-up the plot
		if (i == 1){
			# Now we start by opening the connection to the output device - pdf. 
			pdf(paste("seqLen_",tDepVar,".pdf",sep=""),width=12,height=8)
			# Now we start building our plot from the first row of the tMean matrix and working through the other's
			plot(tXseq,tMean[i,],xlim = c(min(tXseq)*1.01,max(tXseq)*1.01), ylim = c(1,0) ,ylab = tYlab, xlab = "Sequence length", xpd=FALSE, axes=FALSE, type="b", col=colSeq[i], pch = pchSeq[i], lty = 1, lwd = 2)
			axis(1, at = tXseq, labels = lLabel)
			axis(2, at = tYseq, labels= tYseq)
			# Arrows funciton is used to plot the error bars where we define the x,y coords of the upper and lower arrows respectively
			# Which is then followed by the colour, angle of the arrow head and "code" defines which set of coords are used - 3 options and code=3 is both.
			arrows(tXseq,(tMean[i,]+tSdev[i,]), tXseq,(tMean[i,]-tSdev[i,]),col=colSeq[i],angle=90,length=0.05,code=3, lty = 2, lwd = 1)
		# In all other cases we can simply add points and arrows (error bars)	
		} else {
			# points adds a new data series to our growing plot.
			points(tXseq,tMean[i,], col=colSeq[i], pch = pchSeq[i], type = "b", lty = 1, lwd = 2)
			
			# This does not seem to work properly to create lines between our points, mayb e due to CDprp not being integrated and that CD num lacks complete data.
			#lines(tXseq,tMean[i,], col=colSeq[i], pch = pchSeq[i], type = "b", lty = 1, lwd = 2)
			
			arrows(tXseq,(tMean[i,]+tSdev[i,]), tXseq,(tMean[i,]-tSdev[i,]),col=colSeq[i],angle=90,length=0.05,code=3, lty = 2, lwd = 1)
			# Now we advance our counter
		}
	}
	# Here we create a grid which is the combinations of tMean dimensions that have been plotted and need legend references, 
	# the first and 3rd dimensions represent nSeq and tree_type respectively
	tLeg <- unlist(dimnames(tMean)[1])
	# Now we add our legend which tells us that the number of sequences is divided by shape and the tree type by colour.  the ncol here uses the number of tLeg columns
	# to divide up our series evenly so that each column will be one type of the second dimension of tLeg, in this case tree_type
	legend("bottomleft",inset=c(0.2,0),cex=0.80,c(paste(tLeg," sequences ",sep="")),bty="n",col=colSeq, pch= pchSeq, horiz=TRUE)
	dev.off()
}

#################################################################################################
################  %A in AB vs. %Total of CD value: Persp plot p_Value ###########################
################  New colour means of representing significant region ###########################
#################################################################################################

for (tCon in "p_Value"){
	for (tr in 1:3){
		# Here we control for the fact that Tree_Type 3 only assumes the value of nSeq = 32
		for (d in if (tr != 3) {as.numeric(dLabel[-1])}else{32}){
			wFrame <- compFrame[intersect(which(compFrame$nSeq == d),which(compFrame$Tree_Type == tr)),] 
			# We use the factors of Run and Aprp (A proportion of AB) in order to group our data
			tXseq <- levels(factor(wFrame$Aprp))
			tYseq <- levels(factor(wFrame$CDprp))
			# Here we create our matrix that will hold all the values that will create the Z dimension of our persp plot
			tMean <- matrix(NA,nrow=length(tXseq),ncol=length(tYseq),dimnames=list(levels(factor(wFrame$Aprp)),levels(factor(wFrame$CDprp))))
			tSdev <- matrix(NA,nrow=length(tXseq),ncol=length(tYseq),dimnames=list(levels(factor(wFrame$Aprp)),levels(factor(wFrame$CDprp))))
			
			# We want to fill our tMean and tSdev matrices with the population data for a proportion (Aprp) and CD value (# of confusion patterns)
			for (i in tXseq){
				for (j in tYseq){
					# We define the rows that are relevant for taking the mean generating this mean pvalue
					tRows <- intersect(which(wFrame$Aprp== i),which(wFrame$CDprp==j))
					# Assign now our values to the matrices, the assignment of the else value is because at times the p_Value is reported as being zero, thus the -log will generate Inf
					# If this is the case we will simply assign the p_Value as being 100 times smaller than the smallest p_Value in the current data series.
					tMean[i,j] <- if (-log(mean(as.numeric(wFrame[tRows,tCon])),10) != "Inf"){-log(mean(as.numeric(wFrame[tRows,tCon])),10)} else {-log((min(as.numeric(wFrame[which(wFrame[,tCon]!=0),tCon]))/10000),10)}
					tSdev[i,j] <- sd(as.numeric(wFrame[tRows,tCon]))
				}
			}
			# This is an attempt at colours to be placed onto the graph based on the height achieved
			# First we initialise the colours matrix we will use
			fcol <- matrix("red",nrow=nrow(tMean)-1,ncol=ncol(tMean)-1)
			# now we create an intermediary for of tMean which is just a code for whether or not that cell's value is greater than or less than -log(0.005,10)
			tSigmat <- matrix(sapply(tMean,function(x){x >= -log(0.05,10)}),nrow=nrow(tMean),ncol=ncol(tMean)) 
			# Now we will create a matrix which is 1 row and 1 col smaller than our tMean (z-values) matrix but gives the sum of the steps between grid points
			# This was inspired by the demo(persp) volcano example and the zi <- ... call of the same configuration
			zInt <- tSigmat[-1,-1]+tSigmat[-1,-ncol(tSigmat)]+tSigmat[-nrow(tSigmat),-1]+tSigmat[-nrow(tSigmat),-ncol(tSigmat)]
			# Now we create a colours matrix from zInt, where any zInt value greater than 4*-log(0.05,10) is significant
			fcol <- mapply(function(x){return(colSig[x+1])},zInt)
			
			pdf(paste("sigStr_D",d,"_T", tr,"_newCol.pdf", sep=""),width=12,height=8)
			# Now we plot our persp graph with colours like a heat map.
			myPersp <- persp(x=as.numeric(tXseq),y=as.numeric(tYseq),z=tMean, theta=150,phi=30, col=fcol, xlim=c(min(as.numeric(tXseq)),max(as.numeric(tXseq))), ylim=c(min(as.numeric(tYseq)),max(as.numeric(tYseq))), xlab = "Proportion of identical positively correlated pairs", ylab = "Percent of total site pairs as negatively correlated pairs", zlab = "Mean p-value (-log10)", ticktype="detailed")	
			
			# Now we add the plane which represents our p_Value of 0.05 threshold, this will allows us to visually identify values ranges of significance
			# This will be done by creating a persp plane at the -log(0.05,10) level
			#for (x in as.numeric(as.character(tXseq))){
			#	lines(trans3d(x,c(min(as.numeric(as.character(tYseq))),max(as.numeric(as.character(tYseq)))),z=-log(0.05,10),pmat=myPersp),col="black")
			#}
			#for (y in as.numeric(as.character(tYseq))){
			#	lines(trans3d(c(min(as.numeric(as.character(tXseq))),max(as.numeric(as.character(tXseq)))),y,z=-log(0.05,10),pmat=myPersp),col="black")
			#}
			# Now we wish to add a line that shows the cut-off point of significance
			dev.off()
		}
	}
}

#################################################################################################
##############################  kde2d plots #####################################################
#################################################################################################

for (tCon in "p_Value"){
	for (tr in 1:3){
		# Here we control for the fact that Tree_Type 3 only assumes the value of nSeq = 32
		for (d in if (tr != 3) {as.numeric(dLabel[-1])}else{32}){
			wFrame <- compFrame[intersect(which(compFrame$nSeq == d),which(compFrame$Tree_Type == tr)),] 
			# We use the factors of Run and Aprp (A proportion of AB) in order to group our data
			tXseq <- levels(factor(wFrame$Aprp))
			tYseq <- levels(factor(wFrame$CDprp))
			# Here we create our matrix that will hold all the values that will create the Z dimension of our persp plot
			tMean <- matrix(NA,nrow=length(tXseq),ncol=length(tYseq),dimnames=list(levels(factor(wFrame$Aprp)),levels(factor(wFrame$CDprp))))
			tSdev <- matrix(NA,nrow=length(tXseq),ncol=length(tYseq),dimnames=list(levels(factor(wFrame$Aprp)),levels(factor(wFrame$CDprp))))
			
			# We want to fill our tMean and tSdev matrices with the population data for a proportion (Aprp) and CD value (# of confusion patterns)
			for (i in tXseq){
				for (j in tYseq){
					# We define the rows that are relevant for taking the mean generating this mean pvalue
					tRows <- intersect(which(wFrame$Aprp== i),which(wFrame$CDprp==j))
					# Assign now our values to the matrices, the assignment of the else value is because at times the p_Value is reported as being zero, thus the -log will generate Inf
					# If this is the case we will simply assign the p_Value as being 100 times smaller than the smallest p_Value in the current data series.
					tMean[i,j] <- if (-log(mean(as.numeric(wFrame[tRows,tCon])),10) != "Inf"){-log(mean(as.numeric(wFrame[tRows,tCon])),10)} else {-log((min(as.numeric(wFrame[which(wFrame[,tCon]!=0),tCon]))/10000),10)}
					tSdev[i,j] <- sd(as.numeric(wFrame[tRows,tCon]))
				}
			}
			# This is an attempt at colours to be placed onto the graph based on the height achieved
			# First we initialise the colours matrix we will use
			fcol <- matrix("red",nrow=nrow(tMean)-1,ncol=ncol(tMean)-1)
			# Now we will create a matrix which is 1 row and 1 col smaller than our tMean (z-values) matrix but gives the sum of the steps between grid points
			# This was inspired by the demo(persp) volcano example and the zi <- ... call of the same configuration
			zInt <- tMean[-1,-1]+tMean[-1,-ncol(tMean)]+tMean[-nrow(tMean),-1]+tMean[-nrow(tMean),-ncol(tMean)]
				# This is a workaround for instances where we found that tMean was creating Inf values, this means that the quantiles do not cut into unique breaks
				# and thus we must deal with this in a round about way
				tCuts <- stats::quantile(zInt, seq(0,1, length.out = nrow(zInt)))
				rmInd <- NULL
				# Here we look at every index position and if the following one is the same then the cuts are not unique and we remove it.
				for (x in 1:(length(tCuts)-1)){
					if (tCuts[x]== tCuts[x+1]){
						rmInd <- c(rmInd,x)
					}
				}
				# We remove any indexes provided that rmInd is not the NULL value
				if (length(rmInd) != 0) {tCuts <- tCuts[-rmInd]}
			# Now we adjust our colour fill matrix to be based on those inter point values of our Z value matrix.
			fcol <- heat.colors(length(tCuts))[cut(zInt, tCuts, include.lowest = TRUE)]
			
			pdf(paste("sigStr_D",d,"_T", tr,"_kde2d.pdf", sep=""),width=12,height=8)
			# Now we plot our persp graph with colours like a heat map.
			#myPersp <- persp(x=as.numeric(tXseq),y=as.numeric(tYseq),z=tMean, theta=150,phi=30, col=fcol, xlim=c(min(as.numeric(tXseq)),max(as.numeric(tXseq))), ylim=c(min(as.numeric(tYseq)),max(as.numeric(tYseq))), xlab = "Proportion of identical positively correlated pairs", ylab = "Percent of total site pairs as negatively correlated pairs", zlab = "Mean p-value (-log10)", ticktype="detailed")	
			
			tXY <- expand.grid(as.numeric(tXseq),as.numeric(tYseq))
			myCont <- kde2d(x=tXY[,1],y=tXY[,2],h=tMean, n= c(nrow(tMean),ncol(tMean)), lims= c(c(min(as.numeric(tXseq)),max(as.numeric(tXseq))),c(min(as.numeric(tYseq)),max(as.numeric(tYseq)))))
			image(myCont, zlim = c(min(tMean),max(tMean)))
			# Now we add the plane which represents our p_Value of 0.05 threshold, this will allows us to visually identify values ranges of significance
			# This will be done by creating a persp plane at the -log(0.05,10) level
			#for (x in as.numeric(as.character(tXseq))){
			#	lines(trans3d(x,c(min(as.numeric(as.character(tYseq))),max(as.numeric(as.character(tYseq)))),z=-log(0.05,10),pmat=myPersp),col="black")
			#}
			#for (y in as.numeric(as.character(tYseq))){
			#	lines(trans3d(c(min(as.numeric(as.character(tXseq))),max(as.numeric(as.character(tXseq)))),y,z=-log(0.05,10),pmat=myPersp),col="black")
			#}
			# Now we wish to add a line that shows the cut-off point of significance
			dev.off()
		}
	}
}

#################################################################################################
##################################  playground  #################################################
#################################################################################################
# This space was used for me to write small piece of code and test before implementing elsewhere.
# You'll note I've delete all my work from this area.
