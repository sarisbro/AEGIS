# This script will combine all the post analysis files from our Simulation runs of the sigStr runs.
# Here we will generate a large data series to analyse the effects of the number of double vs. dingle substitution
# site pattern entries across a phylogenetic tree.

library(MASS) # I don't believe I use this library however, it has been left as I'm too lazy to check and in terms of resources I'm not concerned
library(locfit)

#################################################################################################
############################## Predefinitions Section ###########################################
#################################################################################################

# Identify how many replicates there were in the simulation run being analysed.
tRep <- 500
# This is a list of the filenames to be reviewed for run output  
fNames <- c("RunPostAnalysis_FDR.csv")
# This is the name of the compilation file to be created\used by this plotting, update this when dealing with new data
# This will then make the compilation call once and skip in future pass through.
compFile <- "sigStr_Compiled.RData"
# Here we define the name of the RData information that should be stored in each tree_sequence's folder telling us which jobs were run
runFile <- "Job_Matrices.RData"
# These are dimensional layer names, items used for filling in the data.frame and plots
cLabel <- c("TP", "FP", "TN", "FN")
dLabel <- c("16", "32", "64", "128")
tLabel <- c("Symetrical", "Pectinate", "Empirical")
cdSeq <- seq(1,10,by=1)
# These are lists of setting for output in plots to assign colour and character points for bLen plots
colSig <- c("blue","cyan","yellow","orange","red")
colSeq <- c("red","blue","purple")
colMat <- matrix(c("hotpink1","red1","red3","cornflowerblue","blue1","blue4","mediumorchid1","darkorchid1","darkorchid"),ncol=length(colSeq))
pchSeq <- c(15,16,17)
# These are lists of setting for output with our barplots of treeType by nSeq
tcolSeq <- c("red","blue","gray80")

# This is requiblack to prevent R from taking 0.0005 and making it into scientific notation, which INDELible can't use
options("scipen"=100, "digits"=6)

# Set our working directory object
wDir <- ("/Users/Jdench/Desktop/SimulationRuns/PhaseSims/sigStr/")
# This is the output folder out plots
pDir <- "sigStrPlots/"

# Set the wd to be the one where we write our post analysis plots
setwd(paste(wDir,pDir,sep="")) 

#################################################################################################
################################ Funcitons Section ##############################################
#################################################################################################

# This function will determine the largest power of 2 that is less than the number entered
# This is only established to function with positive powers of 2.
sQrt <- function(vAlue){
	cOunt <- 0
	# If the value is less than 2 then we return this as 0 and stop
	if (vAlue >= 2){
		# Otherwise we know that this is at least a power of 2, this adjustment is needed 
		# as determined from practice
		cOunt <- 1
		# create a temporray value to compare against vAlue
		tmpNum <- 1
		while (tmpNum < vAlue){
			tmpNum <- tmpNum *2
			# This line account for when vAlue is larger than the current assesed power of 2
			# but not larger than that next value
			if (tmpNum *2 <= vAlue) { cOunt <- cOunt + 1 }
		}
		
	}
	return(cOunt)
}


#################################################################################################
########################### Building the Compiled Data Frame ####################################
#################################################################################################
# Here we run through all the folders that contain the output of runs, this process need only be run once
# it will then save an object of this compilation which can be loaded later

# This is a simple counter to identify if a run has been missed 
missRun <- data.frame("Run"= 0,"Missed"= 1)
# We initialise the data frame that will be used to store our post run information 
compFrame <- data.frame("Rep"=0,"TP"=0,"FP"=0,"TN"=0,"FN"=0,"Num_ePairs"=0,"All_ePairs"="","IDed_TP"="","Run_Time"=0,"p_Value"=0,"S1_Pat"=0,"S2_Pat"=0,"Tree_Type"=0,"nSeq"=0,"CD"=0,"A"=0,"B"=0,"C"=0,"D"=0,"CDprp"=0,"Aprp"=0,"Cprp"=0,"Run"=0)
# This will first search for the designed output file and only run compilation if not present 
if (file.exists(paste(wDir,compFile,sep="")) == FALSE){
	
	# Now we cycle through factors and rbind each file within folders.
	for (tr in 1:3){
		#browser()
		# This is the number of sequences factor, for tree type 3 there is only 32 sequences to be observed.
		for (d in if(tr!=3){as.numeric(dLabel[-1])} else {32}){
			curDir <- paste("T",tr,"_D",d,"/",sep="")
			# Load our builtMat object from the runFile which tells us what jobs were performed
			load(paste(wDir,curDir,runFile,sep=""))
			# Now we need to cycle through each job that was performed and grab the fNames output file
			for (j in 1:ncol(builtMat)){
				# We have stored the A,B,C, and D values used in runs as the 1st to 4th row values in buitlMat
				tmpA <- builtMat[1,j]
				tmpB <- builtMat[2,j]
				tmpC <- builtMat[3,j]
				tmpD <- builtMat[4,j]
				# Now we assign this for clarity, it's not strictly necessary
				rName <- paste("A",tmpA,"_B",tmpB,"_C",tmpC,"_D",tmpD,sep="")
				
				# First make certain their is a file to be read, otherwise write out that this run is not completed
				if (file.exists(paste(wDir,curDir,rName,"/",fNames,sep=""))){
					# Now we simply open each appropriate folder, and rbind the (cbind(fNames file + factors)) to our compFrame 
					compFrame <- rbind(compFrame, cbind(read.csv(paste(wDir,curDir,rName,"/",fNames,sep=""),header=TRUE),"Tree_Type"=tr,"nSeq"=d,"CD"=(tmpC+tmpD),"A"=tmpA,"B"=tmpB,"C"=tmpC,"CDprp"=round((tmpC+tmpD)/d,2),"Aprp"=round(tmpA/(tmpA+tmpB),1),"Cprp"=round(tmpC/(tmpC+tmpD),1),"D"=tmpD,"Run"=rName))
					missRun <- rbind(missRun, c(paste("T",tr,"D",d,rName,sep=""),0))
				} else {
					missRun <- rbind(missRun, c(paste("T",tr,"D",d,rName,sep=""),1))
				}
			}
		}
	}
	missRun <- missRun[-1,]
	# Now we remove the initialising row from our dataframe as well as certain other columns which are not needed, namely TN,FN, Num_ePairs, All_ePairs and IDed_TP
	compFrame <- compFrame[-1,-(4:8)]
	# We make the "Run" and other items factors so that we can use it's levels attribute to group by Run	
	compFrame$Run <- factor(compFrame$Run)
	compFrame$CD <- factor(compFrame$CD)
	compFrame$Aprp <- factor(compFrame$Aprp)
	compFrame$Cprp <- factor(compFrame$Cprp)
	compFrame$CDprp <- factor(compFrame$CDprp)
		
	if (mean(as.numeric(missRun$Missed)) == 0){
		# Now we write out the compiled compFrame object so that for later runs it can be loaded and save time
		save(compFrame, file=paste(wDir,compFile,sep=""))
	}
} else {
	load(paste(wDir,compFile,sep=""))
}

#################################################################################################
################  tree_type and nSeq Symbols vs mean-pValue #####################################
#################################################################################################

### This needs to be rethought for CDprp ###

for (tCon in "p_Value"){
	# We create some data output arrays to hold information that we will want to plot, the column setting of 10 reflects the number of confusion symbols we could have included 1:10
	tIqr <- tSdev <- tMean <- array(NA, dim=c(length(dLabel[-1]),10,length(tLabel[1:2])), dimnames=list(dLabel[-1],paste("CD_",1:10,sep=""),tLabel[1:2]))
	# This allows us to cycle through for each tree_type, NOTE# that the user tree type is a special case, hence we only use tree types 1 & 2
	for (tr in 1:2){
		for (i in dLabel[-1]){
			for (j in cdSeq){
				# This takes out the small intersection of data we need for this particular cross section of nSeq, bLen, tree_type and sEpi
				wFrame <- compFrame[intersect(intersect(which(compFrame$nSeq == i),which(compFrame$CD == j)),which(compFrame$Tree_Type == tr)),]
				# Now we will fill up our tMean and tSdev matrices 
				tMean[i,j,tr] <- mean(wFrame[,tCon])
				tSdev[i,j,tr] <- sd(wFrame[,tCon])
				tIqr[i,j,tr] <- IQR(wFrame[,tCon])
			}
		}
	}
	
	# This assigns the y-axis label based on this run
	tYlab <- paste("Mean ",tCon,sep="")
	# Now we will identify the y-axis limits by knowing that sensitivity and specificity lie between 0 and 1
	tYseq <- seq(0,1,by=0.2)
	# Now we create a simple object with the x-axis values, this is for clarity 
	tXseq <- seq(1,10,by=1)
	
	# We want to plot each number of sequences, we will match all same tree elements by colour, and distinguish nSeq elemetns by pch character.
	for (i in 1:nrow(tMean)){
		# further we want to plot each tree type, thus the array 3rd dimension
		for (k in 1:dim(tMean)[3]){
			# for our first scenario we need to set-up the plot
			if (i == 1 && k == 1){
				# Now we start by opening the connection to the output device - pdf. 
				pdf(paste("CD_",tCon,".pdf",sep=""),width=12,height=8)
				# Now we start building our plot from the first row of the tMean matrix and working through the other's
				plot(tXseq,tMean[i,,k],xlim = c(0,max(tXseq)), ylim = c(0,max(tYseq)) ,ylab = tYlab, xlab = "# of confusion pairs", xpd=FALSE, type="b", col=colMat[i,k], pch = pchSeq[i], lty = 1, lwd = 2)
				# Arrows funciton is used to plot the error bars where we define the x,y coords of the upper and lower arrows respectively
				# Which is then followed by the colour, angle of the arrow head and "code" defines which set of coords are used - 3 options and code=3 is both.
				arrows(tXseq,(tMean[i,,k]+tSdev[i,,k]), tXseq,(tMean[i,,k]-tSdev[i,,k]),col=colMat[i,k],angle=90,length=0.05,code=3, lty = 2, lwd = 1)
			# In all other cases we can simply add points and arrows (error bars)	
			} else {
				# points adds a new data series to our growing plot.
				points(tXseq,tMean[i,,k], col=colMat[i,k], pch = pchSeq[i], type = "b", lty = 1, lwd = 2)
				
				# This does not seem to work properly to create lines between our points, mayb e due to CDprp not being integrated and that CD num lacks complete data.
				#lines(tXseq,tMean[i,,k], col=colMat[i,k], pch = pchSeq[i], type = "b", lty = 1, lwd = 2)
				
				arrows(tXseq,(tMean[i,,k]+tSdev[i,,k]), tXseq,(tMean[i,,k]-tSdev[i,,k]),col=colMat[i,k],angle=90,length=0.05,code=3, lty = 2, lwd = 1)
				# Now we advance our counter
			}
		}
	}
	# Here we create a grid which is the combinations of tMean dimensions that have been plotted and need legend references, 
	# the first and 3rd dimensions represent nSeq and tree_type respectively
	tLeg <- expand.grid(unlist(dimnames(tMean)[1]),unlist(dimnames(tMean)[3]))
	# Now we add our legend which tells us that the number of sequences is divided by shape and the tree type by colour.  the ncol here uses the number of tLeg columns
	# to divide up our series evenly so that each column will be one type of the second dimension of tLeg, in this case tree_type
	legend("bottomleft",inset=c(0.2,0),cex=0.80,c(paste(tLeg[,1]," sequences ",tolower(tLeg[,2])," tree",sep="")),bty="n",col=colMat, pch= pchSeq, ncol=ncol(tLeg))
	dev.off()
}

#################################################################################################
################  %A in AB vs. %Total of CD value: Persp plot p_Value ###########################
#################################################################################################

for (tCon in "p_Value"){
	for (tr in 1){
		# Here we control for the fact that Tree_Type 3 only assumes the value of nSeq = 32
		for (d in if (tr != 3) {as.numeric(dLabel[-1])}else{32}){
			wFrame <- compFrame[intersect(which(compFrame$nSeq == d),which(compFrame$Tree_Type == tr)),] 
			# We use the factors of Run and Aprp (A proportion of AB) in order to group our data
			tXseq <- levels(factor(wFrame$Aprp))
			tYseq <- levels(factor(wFrame$CDprp))
			# Here we create our matrix that will hold all the values that will create the Z dimension of our persp plot
			tMean <- matrix(NA,nrow=length(tXseq),ncol=length(tYseq),dimnames=list(levels(factor(wFrame$Aprp)),levels(factor(wFrame$CDprp))))
			tSdev <- matrix(NA,nrow=length(tXseq),ncol=length(tYseq),dimnames=list(levels(factor(wFrame$Aprp)),levels(factor(wFrame$CDprp))))
			
			# We want to fill our tMean and tSdev matrices with the population data for a proportion (Aprp) and CD value (# of confusion patterns)
			for (i in tXseq){
				for (j in tYseq){
					# We define the rows that are relevant for taking the mean generating this mean pvalue
					tRows <- intersect(which(wFrame$Aprp== i),which(wFrame$CDprp==j))
					# Assign now our values to the matrices, the assignment of the else value is because at times the p_Value is reported as being zero, thus the -log will generate Inf
					# If this is the case we will simply assign the p_Value as being 100 times smaller than the smallest p_Value in the current data series.
					tMean[i,j] <- if (-log(mean(as.numeric(wFrame[tRows,tCon])),10) != "Inf"){-log(mean(as.numeric(wFrame[tRows,tCon])),10)} else {-log((min(as.numeric(wFrame[which(wFrame[,tCon]!=0),tCon]))/10000),10)}
					tSdev[i,j] <- sd(as.numeric(wFrame[tRows,tCon]))
				}
			}
			# This is an attempt at colours to be placed onto the graph based on the height achieved
			# First we initialise the colours matrix we will use
			fcol <- matrix("red",nrow=nrow(tMean)-1,ncol=ncol(tMean)-1)
			# Now we will create a matrix which is 1 row and 1 col smaller than our tMean (z-values) matrix but gives the sum of the steps between grid points
			# This was inspired by the demo(persp) volcano example and the zi <- ... call of the same configuration
			zInt <- tMean[-1,-1]+tMean[-1,-ncol(tMean)]+tMean[-nrow(tMean),-1]+tMean[-nrow(tMean),-ncol(tMean)]
				# This is a workaround for instances where we found that tMean was creating Inf values, this means that the quantiles do not cut into unique breaks
				# and thus we must deal with this in a round about way
				tCuts <- stats::quantile(zInt, seq(0,1, length.out = nrow(zInt)))
				rmInd <- NULL
				# Here we look at every index position and if the following one is the same then the cuts are not unique and we remove it.
				for (x in 1:(length(tCuts)-1)){
					if (tCuts[x]== tCuts[x+1]){
						rmInd <- c(rmInd,x)
					}
				}
				# We remove any indexes provided that rmInd is not the NULL value
				if (length(rmInd) != 0) {tCuts <- tCuts[-rmInd]}
			# Now we adjust our colour fill matrix to be based on those inter point values of our Z value matrix.
			fcol <- heat.colors(length(tCuts))[cut(zInt, tCuts, include.lowest = TRUE)]
			
			pdf(paste("sigStr_D",d,"_T", tr,".pdf", sep=""),width=12,height=8)
			# Now we plot our persp graph with colours like a heat map.
			myPersp <- persp(x=as.numeric(tXseq),y=as.numeric(tYseq),z=tMean, theta=150,phi=30, col=fcol, xlim=c(min(as.numeric(tXseq)),max(as.numeric(tXseq))), ylim=c(min(as.numeric(tYseq)),max(as.numeric(tYseq))), xlab = "Proportion of identical positively correlated pairs", ylab = "Percent of total site pairs as negatively correlated pairs", zlab = "Mean p-value (-log10)", ticktype="detailed")	
			
			# Now we add the plane which represents our p_Value of 0.05 threshold, this will allows us to visually identify values ranges of significance
			# This will be done by creating a persp plane at the -log(0.05,10) level
			#for (x in as.numeric(as.character(tXseq))){
			#	lines(trans3d(x,c(min(as.numeric(as.character(tYseq))),max(as.numeric(as.character(tYseq)))),z=-log(0.05,10),pmat=myPersp),col="black")
			#}
			#for (y in as.numeric(as.character(tYseq))){
			#	lines(trans3d(c(min(as.numeric(as.character(tXseq))),max(as.numeric(as.character(tXseq)))),y,z=-log(0.05,10),pmat=myPersp),col="black")
			#}
			# Now we wish to add a line that shows the cut-off point of significance
			dev.off()
		}
	}
}

#################################################################################################
##########  %A in AB vs. %Total of CD value: Persp plot p_Value - With grid lines ###############
#################################################################################################

for (tCon in "p_Value"){
	# Here we control for the fact that Tree_Type 3 only assumes the value of nSeq = 32
	for (d in as.numeric(dLabel[-1])){
		for (tr in if(d!=32){1:2}else{1:3}){
			wFrame <- compFrame[intersect(which(compFrame$nSeq == d),which(compFrame$Tree_Type == tr)),] 
			# We use the factors of Run and Aprp (A proportion of AB) in order to group our data
			tXseq <- levels(factor(wFrame$Aprp))
			tYseq <- levels(factor(wFrame$CD))
			# Here we create our matrix that will hold all the values that will create the Z dimension of our persp plot
			tMean <- matrix(NA,nrow=length(tXseq),ncol=length(tYseq),dimnames=list(levels(factor(wFrame$Aprp)),levels(factor(wFrame$CD))))
			tSdev <- matrix(NA,nrow=length(tXseq),ncol=length(tYseq),dimnames=list(levels(factor(wFrame$Aprp)),levels(factor(wFrame$CD))))
			
			# We want to fill our tMean and tSdev matrices with the population data for a proportion (Aprp) and CD value (# of confusion patterns)
			for (i in tXseq){
				for (j in tYseq){
					# We define the rows that are relevant for taking the mean generating this mean pvalue
					tRows <- intersect(which(wFrame$Aprp== i),which(wFrame$CD==j))
					# Assign now our values to the matrices, the assignment of the else value is because at times the p_Value is reported as being zero, thus the -log will generate Inf
					# If this is the case we will simply assign the p_Value as being 10000 times smaller than the smallest p_Value in the current data series.  This is done by experience, min isn't returning the absolute lowest
					# Value within the matrix.
					tMean[i,j] <- if (-log(mean(as.numeric(wFrame[tRows,tCon])),10) != "Inf"){-log(mean(as.numeric(wFrame[tRows,tCon])),10)} else {-log((min(as.numeric(wFrame[which(wFrame[,tCon]!=0),tCon]))/10000),10)}
					tSdev[i,j] <- sd(as.numeric(wFrame[tRows,tCon]))
				}
			}
			# This is an attempt at colours to be placed onto the graph based on the height achieved
			# First we initialise the colours matrix we will use
			fcol <- matrix("red",nrow=nrow(tMean)-1,ncol=ncol(tMean)-1)
			# Now we will create a matrix which is 1 row and 1 col smaller than our tMean (z-values) matrix but gives the sum of the steps between grid points
			# This was inspired by the demo(persp) volcano example and the zi <- ... call of the same configuration
			zInt <- tMean[-1,-1]+tMean[-1,-ncol(tMean)]+tMean[-nrow(tMean),-1]+tMean[-nrow(tMean),-ncol(tMean)]
				# This is a workaround for instances where we found that tMean was creating Inf values, this means that the quantiles do not cut into unique breaks
				# and thus we must deal with this in a round about way
				tCuts <- stats::quantile(zInt, seq(0,1, length.out = nrow(zInt)))
				rmInd <- NULL
				# Here we look at every index position and if the following one is the same then the cuts are not unique and we remove it.
				for (x in 1:(length(tCuts)-1)){
					if (tCuts[x]== tCuts[x+1]){
						rmInd <- c(rmInd,x)
					}
				}
				# We remove any indexes provided that rmInd is not the NULL value
				if (length(rmInd) != 0) {tCuts <- tCuts[-rmInd]}
			# Now we adjust our colour fill matrix to be based on those inter point values of our Z value matrix.
			fcol <- heat.colors(length(tCuts))[cut(zInt, tCuts, include.lowest = TRUE)]
			
			pdf(paste("sigStr_D",d,"_T", tr,"_CDNums_Grid.pdf", sep=""),width=12,height=8)
			# Now we plot our persp graph with colours like a heat map.
			myPersp <- persp(x=as.numeric(tXseq),y=as.numeric(tYseq),z=tMean, theta=150,phi=30, col=fcol, xlim=c(min(as.numeric(tXseq)),max(as.numeric(tXseq))), ylim=c(min(as.numeric(tYseq)),max(as.numeric(tYseq))), xlab = "Proportion of identical positively correlated pairs", ylab = "Percent of total site pairs as negatively correlated pairs", zlab = "Mean p-value (-log10)", ticktype="detailed")	
			# Now we add the plane which represents our p_Value of 0.05 threshold, this will allows us to visually identify values ranges of significance
			# This will be done by creating a grid of lines at hte appropriate height (-log(0.05,10)) and drawing a line from one end of an axis to another
			# at each tick point ### Hashed out at present as is not visually attractive.
			for (x in as.numeric(as.character(tXseq))){
				lines(trans3d(x,c(min(as.numeric(as.character(tYseq))),max(as.numeric(as.character(tYseq)))),z=-log(0.05,10),pmat=myPersp),col="black", lty=2)
			}
			for (y in as.numeric(as.character(tYseq))){
				lines(trans3d(c(min(as.numeric(as.character(tXseq))),max(as.numeric(as.character(tXseq)))),y,z=-log(0.05,10),pmat=myPersp),col="black", lty=2)
			}
			# Now we wish to add a line that shows the cut-off point of significance
			dev.off()
		}
	}
}

#################################################################################################
################  %A in AB vs. %Total of CD value: Persp plot p_Value ###########################
################  New colour means of representing significant region ###########################
#################################################################################################

# These lists will hold matrices with the mean and standard deviation for each run as well as limit vectors
tMean <- tSdev <- tXseq <- tYseq <- list()
tZseq <- list("32"=c(0,0),"64"=c(0,0),"128"=c(0,0))

for (tCon in "p_Value"){
	for (tr in 1:3){
		# Here we control for the fact that Tree_Type 3 only assumes the value of nSeq = 32
		for (d in if (tr != 3) {as.numeric(dLabel[-1])}else{32}){
			listName <- paste("T",tr,"_D",d,sep="")
			wFrame <- compFrame[intersect(which(compFrame$nSeq == d),which(compFrame$Tree_Type == tr)),] 
			# We use the factors of Run and Aprp (A proportion of AB) in order to group our data
			tXseq[[listName]] <- levels(factor(wFrame$Aprp))
			tYseq[[listName]] <- levels(factor(wFrame$CDprp))
			# Here we create our matrix that will hold all the values that will create the Z dimension of our persp plot
			tMean[[listName]] <- matrix(NA,nrow=length(tXseq[[listName]]),ncol=length(tYseq[[listName]]),dimnames=list(levels(factor(wFrame$Aprp)),levels(factor(wFrame$CDprp))))
			tSdev[[listName]] <- matrix(NA,nrow=length(tXseq[[listName]]),ncol=length(tYseq[[listName]]),dimnames=list(levels(factor(wFrame$Aprp)),levels(factor(wFrame$CDprp))))
			
			# We want to fill our tMean and tSdev matrices with the population data for a proportion (Aprp) and CD value (# of confusion patterns)
			for (i in tXseq[[listName]]){
				for (j in tYseq[[listName]]){
					# We define the rows that are relevant for taking the mean generating this mean pvalue
					tRows <- intersect(which(wFrame$Aprp== i),which(wFrame$CDprp==j))
					# Assign now our values to the matrices, the assignment of the else value is because at times the p_Value is reported as being zero, thus the -log will generate Inf
					# If this is the case we will simply assign the p_Value as being 100 times smaller than the smallest p_Value in the current data series.
					tMean[[listName]][i,j] <- if (-log(mean(as.numeric(wFrame[tRows,tCon])),10) != "Inf"){-log(mean(as.numeric(wFrame[tRows,tCon])),10)} else {-log((min(as.numeric(wFrame[which(wFrame[,tCon]!=0),tCon]))/10000),10)}
					tSdev[[listName]][i,j] <- sd(as.numeric(wFrame[tRows,tCon]))
				}
			}
			# We evaluate to find the maximum of either the current value in tZseq for this d or the largest value in tMean[[listName]]
			tZseq[[as.character(d)]][2] <- max(unlist(tMean[[listName]]),tZseq[[as.character(d)]][2]) 
		}
	}
	
	# Now we cycle back through the lists and create a plot for each of the list matrices, these cycles are broken up
	# explicitly so that I can evaluate a common zlim maximal value for plotting purposes.
	for (tr in 1:3){
		# Here we control for the fact that Tree_Type 3 only assumes the value of nSeq = 32
		for (d in if (tr != 3) {as.numeric(dLabel[-1])}else{32}){
			listName <- paste("T",tr,"_D",d,sep="") 
			# This is an attempt at colours to be placed onto the graph based on the height achieved
			# First we initialise the colours matrix we will use
			fcol <- matrix("red",nrow=nrow(tMean[[listName]])-1,ncol=ncol(tMean[[listName]])-1)
			# now we create an intermediary for of tMean which is just a code for whether or not that cell's value is greater than or less than -log(0.005,10)
			tSigmat <- matrix(sapply(tMean[[listName]],function(x){x >= -log(0.05,10)}),nrow=nrow(tMean[[listName]]),ncol=ncol(tMean[[listName]])) 
			# Now we will create a matrix which is 1 row and 1 col smaller than our tMean (z-values) matrix but gives the sum of the steps between grid points
			# This was inspired by the demo(persp) volcano example and the zi <- ... call of the same configuration
			zInt <- tSigmat[-1,-1]+tSigmat[-1,-ncol(tSigmat)]+tSigmat[-nrow(tSigmat),-1]+tSigmat[-nrow(tSigmat),-ncol(tSigmat)]
			# Now we create a colours matrix from zInt, where any zInt value greater than 4*-log(0.05,10) is significant
			fcol <- mapply(function(x){return(colSig[x+1])},zInt)
			
			pdf(paste("sigStr_D",d,"_T", tr,"_newCol.pdf", sep=""),width=12,height=8)
			# Now we plot our persp graph with colours like a heat map.
			myPersp <- persp(x=as.numeric(tXseq[[listName]]),y=as.numeric(tYseq[[listName]]),z=tMean[[listName]], theta=150,phi=30, col=fcol, 
				xlim=c(min(as.numeric(tXseq[[listName]])),max(as.numeric(tXseq[[listName]]))), ylim=c(min(as.numeric(tYseq[[listName]])),max(as.numeric(tYseq[[listName]]))),zlim=c(tZseq[[as.character(d)]][1],tZseq[[as.character(d)]][2]),
				xlab = "Prop. of pos. corr. pairs: (1,1)", ylab = "Neg. corr. pairs (% total)", zlab = "Mean p-value (-log10)", ticktype="detailed")	
			
			# Now we add the plane which represents our p_Value of 0.05 threshold, this will allows us to visually identify values ranges of significance
			# This will be done by creating a persp plane at the -log(0.05,10) level
			#for (x in as.numeric(as.character(tXseq))){
			#	lines(trans3d(x,c(min(as.numeric(as.character(tYseq))),max(as.numeric(as.character(tYseq)))),z=-log(0.05,10),pmat=myPersp),col="black")
			#}
			#for (y in as.numeric(as.character(tYseq))){
			#	lines(trans3d(c(min(as.numeric(as.character(tXseq))),max(as.numeric(as.character(tXseq)))),y,z=-log(0.05,10),pmat=myPersp),col="black")
			#}
			# Now we wish to add a line that shows the cut-off point of significance
			dev.off()
		}
	}
}

#################################################################################################
############################### Persp Plot A:B vs C:D with Constant Z lim #######################
########################################## configed for D32 ##################################### 
#################################################################################################

for (tCon in "p_Value"){
	for (tr in 1:3){
		# Here we control for the fact that Tree_Type 3 only assumes the value of nSeq = 32
		for (d in 32){
			wFrame <- compFrame[intersect(which(compFrame$nSeq == d),which(compFrame$Tree_Type == tr)),] 
			# We use the factors of Run and Aprp (A proportion of AB) in order to group our data
			tXseq <- levels(factor(wFrame$Aprp))
			tYseq <- levels(factor(wFrame$CDprp))
			# Here we create our matrix that will hold all the values that will create the Z dimension of our persp plot
			tMean <- matrix(NA,nrow=length(tXseq),ncol=length(tYseq),dimnames=list(levels(factor(wFrame$Aprp)),levels(factor(wFrame$CDprp))))
			tSdev <- matrix(NA,nrow=length(tXseq),ncol=length(tYseq),dimnames=list(levels(factor(wFrame$Aprp)),levels(factor(wFrame$CDprp))))
			
			# We want to fill our tMean and tSdev matrices with the population data for a proportion (Aprp) and CD value (# of confusion patterns)
			for (i in tXseq){
				for (j in tYseq){
					# We define the rows that are relevant for taking the mean generating this mean pvalue
					tRows <- intersect(which(wFrame$Aprp== i),which(wFrame$CDprp==j))
					# Assign now our values to the matrices, the assignment of the else value is because at times the p_Value is reported as being zero, thus the -log will generate Inf
					# If this is the case we will simply assign the p_Value as being 100 times smaller than the smallest p_Value in the current data series.
					tMean[i,j] <- if (-log(mean(as.numeric(wFrame[tRows,tCon])),10) != "Inf"){-log(mean(as.numeric(wFrame[tRows,tCon])),10)} else {-log((min(as.numeric(wFrame[which(wFrame[,tCon]!=0),tCon]))/10000),10)}
					tSdev[i,j] <- sd(as.numeric(wFrame[tRows,tCon]))
				}
			}
			
			print(max(tMean))
			
			# This is an attempt at colours to be placed onto the graph based on the height achieved
			# First we initialise the colours matrix we will use
			fcol <- matrix("red",nrow=nrow(tMean)-1,ncol=ncol(tMean)-1)
			# now we create an intermediary for of tMean which is just a code for whether or not that cell's value is greater than or less than -log(0.005,10)
			tSigmat <- matrix(sapply(tMean,function(x){x >= -log(0.05,10)}),nrow=nrow(tMean),ncol=ncol(tMean)) 
			# Now we will create a matrix which is 1 row and 1 col smaller than our tMean (z-values) matrix but gives the sum of the steps between grid points
			# This was inspired by the demo(persp) volcano example and the zi <- ... call of the same configuration
			zInt <- tSigmat[-1,-1]+tSigmat[-1,-ncol(tSigmat)]+tSigmat[-nrow(tSigmat),-1]+tSigmat[-nrow(tSigmat),-ncol(tSigmat)]
			# Now we create a colours matrix from zInt, where any zInt value greater than 4*-log(0.05,10) is significant
			fcol <- mapply(function(x){return(colSig[x+1])},zInt)
			
			pdf(paste("sigStr_D",d,"_T", tr,"_newCol.pdf", sep=""),width=12,height=8)
			# Now we plot our persp graph with colours like a heat map.
			myPersp <- persp(x=as.numeric(tXseq),y=as.numeric(tYseq),z=tMean, theta=150,phi=30, col=fcol, xlim=c(min(as.numeric(tXseq)),max(as.numeric(tXseq))), ylim=c(min(as.numeric(tYseq)),max(as.numeric(tYseq))), zlim=c(0,7), xlab = "Proportion of identical positively correlated pairs", ylab = "Percent of total site pairs as negatively correlated pairs", zlab = "Mean p-value (-log10)", ticktype="detailed")	
			
			# Now we add the plane which represents our p_Value of 0.05 threshold, this will allows us to visually identify values ranges of significance
			# This will be done by creating a persp plane at the -log(0.05,10) level
			#for (x in as.numeric(as.character(tXseq))){
			#	lines(trans3d(x,c(min(as.numeric(as.character(tYseq))),max(as.numeric(as.character(tYseq)))),z=-log(0.05,10),pmat=myPersp),col="black")
			#}
			#for (y in as.numeric(as.character(tYseq))){
			#	lines(trans3d(c(min(as.numeric(as.character(tXseq))),max(as.numeric(as.character(tXseq)))),y,z=-log(0.05,10),pmat=myPersp),col="black")
			#}
			# Now we wish to add a line that shows the cut-off point of significance
			dev.off()
		}
	}
}

#################################################################################################
######################## P-Value Distribution Group Plot by: Tree n nSeq ########################
#################################################################################################

# We will use a kernel density plot funciton of R in order to view the distrubutions of these data
# NOTE that this function exists for single ensity plots: plot(density(x))

# This will be a list that will hold the density information for each tree type
densityList <- list()
# This is a min max Matrix for the x and y values
mmMat <- matrix(NA,ncol=2,nrow=2,dimnames=list(c("x","y"),c("min","max")))
# This is a boolean for if this is the first loop or not
firstLoop <- TRUE

# This is a list that will hold all the p-values for a given tree and nSeq
for (tCon in "p_Value"){
	for (tr in 1:3){
		# Here we control for the fact that Tree_Type 3 only assumes the value of nSeq = 32
		for (d in if (tr != 3) {as.numeric(dLabel[-1])}else{32}){
			#wFrame <- compFrame[intersect(which(compFrame$nSeq == d),which(compFrame$Tree_Type == tr)),]
			listName <- paste("T",tr,"_D",d,sep="")
			densityList[[listName]] <- density(compFrame[intersect(which(compFrame$nSeq == d),which(compFrame$Tree_Type == tr)),tCon])
			# From experience the data series is rather distributed along the y axis so we will transform to a log scale to make it more 
			# visually comparable.
				#densityList[[listName]]$y <- log(densityList[[listName]]$y,10)
			# Here we obtain the max and min x and y values 
			# If this is a first isntance we know to simply take new values, else we will get the min or max from the current vs matrix
			if (firstLoop){
				mmMat["x","min"] <- min(densityList[[listName]]$x)
				mmMat["x","max"] <- max(densityList[[listName]]$x)
				mmMat["y","min"] <- min(densityList[[listName]]$y)
				mmMat["y","max"] <- max(densityList[[listName]]$y)
				firstLoop <- FALSE
			} else {
				mmMat["x","min"] <- min(mmMat["x","min"], min(densityList[[listName]]$x))
				mmMat["x","max"] <- max(mmMat["x","max"], max(densityList[[listName]]$x))
				mmMat["y","min"] <- min(mmMat["y","min"], min(densityList[[listName]]$y))
				mmMat["y","max"] <- max(mmMat["y","max"], max(densityList[[listName]]$y))
			}
			#Sanity Check
			#print(mmMat)		
		}
	}
	# We use the max and min density values obtain through the density function sotre in the min max Matrix
	tXseq <- seq(round(mmMat["x","min"],1),round(mmMat["x","max"],1),by=0.1)
	# Since this is loh scaled data and from experince the values should not fall outside of this range
	#tYseq <- seq(-3,4,by=1)
	tYseq <- seq(round(mmMat["y","min"],1),round(mmMat["y","max"],1),by=ceiling(mmMat["y","max"]/6))
} 

pdf(paste("sigStr_Denisty_grouped.pdf", sep=""),width=12,height=8)
# Our first plot will be the empiric data since it is singular and then we can loop the other series
#plot(densityList[[length(densityList)]], xlab="p-Value", col=colMat[length(densityList)], xlim=c(min(tXseq),max(tXseq)),ylim=c(min(tYseq),max(tYseq)))
plot(densityList[[length(densityList)]], xlab="p-Value", col=colMat[length(densityList)], xlim=c(min(tXseq),max(tXseq)),ylim=c(0,100),main=NULL,lwd=2)
# Now we add a vertical line at the point of 0.05 significance
abline(v=0.01, lty=2,lwd=1, col="black")
# Now we add the other lines
for (x in 1:(length(densityList)-1)){ lines(densityList[[x]],col=colMat[x],lwd=2) }
# And last append a legend
tLeg <- expand.grid(dLabel[-1],tLabel)
# Note we only use the first 7 rows since there is no empiric data for nSeq = 64, or 128
legend("topright",inset=c(0,0),cex=0.80,c(paste(tLeg[1:7,1]," sequences ",tolower(tLeg[1:7,2])," tree",sep="")),bty="n",fill=colMat[1:length(densityList)], ncol=length(tLabel))	
dev.off()


#################################################################################################
###################### P-Value locfit plot Seperate Plot by: Tree n nSeq =32 ####################
#################################################################################################

# This is a list that will hold all the p-values for a given tree and nSeq
for (tCon in "p_Value"){
	for (tr in 1:3){
		for (d in if (tr != 3 ){ dLabel[-1] } else {"32"}){
			wFrame <- compFrame[intersect(which(compFrame$nSeq == d),which(compFrame$Tree_Type == tr)),]		
			pdf(paste("sigStr_locfitDenisty_T",tr,"_D",d,".pdf", sep=""),width=6,height=6)
			# Our first plot will be the empiric data since it is singular and then we can loop the other series
			# the nn paramter is the nearest nieghbour joining parameter which affects the smoothing of the fit, smaller values create
			# more rugged plots and from visual inspection this value is optimal for this data set (it is the default), 
			lcPlot <- plot((locfit(~lp(p_Value,nn=0.7), data= wFrame,maxk=10000, kern="tcub")) , xlab="p-Value", ylab="Density", col=colMat[which(dLabel == d)-1,tr])
			# The call to par allows us to infer the x and ylim from xaxp and yaxp giving the maximal value as the second indexed number
			# From this we can set the text to appear in the top right-ish corner of the plot
			text(x=par(lcPlot,no.readonly=TRUE, "xaxp")$xaxp[2]*0.80,y=par(lcPlot,no.readonly=TRUE, "yaxp")$yaxp[2]*0.90, cex=1.0, c(paste("p(X <= 0.01) = ",round(length(which(wFrame$p_Value <= 0.01))/nrow(wFrame),2),sep="")))
			# We will use the legend function to create some additional text describing the proportiong of the data which is signficant
			#legend("topright",inset=c(0.1,0.1),cex=1.0,c(paste("p(X <= 0.5) = ",round(length(which(wFrame$p_Value <= 0.05))/nrow(wFrame),2),sep="")),bty="n",fill="white")	
			# Now we add a vertical line at the point of 0.05 significance
			abline(v=0.01, lty=2,lwd=1, col="black")
			dev.off()
		}
	}
} 

#################################################################################################
###################### P-Value histogram plot Seperate Plot by: Tree & nSeq #####################
#################################################################################################

# This is a list that will hold all the p-values for a given tree and nSeq
for (tCon in "p_Value"){
	for (tr in 1:3){
		for (d in if (tr != 3 ){ dLabel[-1] } else {"32"}){
			wFrame <- compFrame[intersect(which(compFrame$nSeq == d),which(compFrame$Tree_Type == tr)),]
			pdf(paste("sigStr_hist_T",tr,"_D",d,".pdf",sep=""), height=4, width = 6)
			plot(hist(wFrame$p_Value, breaks = seq(0,1,by=0.01) , ylab = "Frequency", xlab = "p-Value", main= NULL))
			dev.off()
		}
	}
} 

#################################################################################################
##############################  kde2d plots #####################################################
#################################################################################################

for (tCon in "p_Value"){
	for (tr in 1:3){
		# Here we control for the fact that Tree_Type 3 only assumes the value of nSeq = 32
		for (d in if (tr != 3) {as.numeric(dLabel[-1])}else{32}){
			wFrame <- compFrame[intersect(which(compFrame$nSeq == d),which(compFrame$Tree_Type == tr)),] 
			# We use the factors of Run and Aprp (A proportion of AB) in order to group our data
			tXseq <- levels(factor(wFrame$Aprp))
			tYseq <- levels(factor(wFrame$CDprp))
			# Here we create our matrix that will hold all the values that will create the Z dimension of our persp plot
			tMean <- matrix(NA,nrow=length(tXseq),ncol=length(tYseq),dimnames=list(levels(factor(wFrame$Aprp)),levels(factor(wFrame$CDprp))))
			tSdev <- matrix(NA,nrow=length(tXseq),ncol=length(tYseq),dimnames=list(levels(factor(wFrame$Aprp)),levels(factor(wFrame$CDprp))))
			
			# We want to fill our tMean and tSdev matrices with the population data for a proportion (Aprp) and CD value (# of confusion patterns)
			for (i in tXseq){
				for (j in tYseq){
					# We define the rows that are relevant for taking the mean generating this mean pvalue
					tRows <- intersect(which(wFrame$Aprp== i),which(wFrame$CDprp==j))
					# Assign now our values to the matrices, the assignment of the else value is because at times the p_Value is reported as being zero, thus the -log will generate Inf
					# If this is the case we will simply assign the p_Value as being 100 times smaller than the smallest p_Value in the current data series.
					tMean[i,j] <- if (-log(mean(as.numeric(wFrame[tRows,tCon])),10) != "Inf"){-log(mean(as.numeric(wFrame[tRows,tCon])),10)} else {-log((min(as.numeric(wFrame[which(wFrame[,tCon]!=0),tCon]))/10000),10)}
					tSdev[i,j] <- sd(as.numeric(wFrame[tRows,tCon]))
				}
			}
			# This is an attempt at colours to be placed onto the graph based on the height achieved
			# First we initialise the colours matrix we will use
			fcol <- matrix("red",nrow=nrow(tMean)-1,ncol=ncol(tMean)-1)
			# Now we will create a matrix which is 1 row and 1 col smaller than our tMean (z-values) matrix but gives the sum of the steps between grid points
			# This was inspired by the demo(persp) volcano example and the zi <- ... call of the same configuration
			zInt <- tMean[-1,-1]+tMean[-1,-ncol(tMean)]+tMean[-nrow(tMean),-1]+tMean[-nrow(tMean),-ncol(tMean)]
				# This is a workaround for instances where we found that tMean was creating Inf values, this means that the quantiles do not cut into unique breaks
				# and thus we must deal with this in a round about way
				tCuts <- stats::quantile(zInt, seq(0,1, length.out = nrow(zInt)))
				rmInd <- NULL
				# Here we look at every index position and if the following one is the same then the cuts are not unique and we remove it.
				for (x in 1:(length(tCuts)-1)){
					if (tCuts[x]== tCuts[x+1]){
						rmInd <- c(rmInd,x)
					}
				}
				# We remove any indexes provided that rmInd is not the NULL value
				if (length(rmInd) != 0) {tCuts <- tCuts[-rmInd]}
			# Now we adjust our colour fill matrix to be based on those inter point values of our Z value matrix.
			fcol <- heat.colors(length(tCuts))[cut(zInt, tCuts, include.lowest = TRUE)]
			
			pdf(paste("sigStr_D",d,"_T", tr,"_kde2d.pdf", sep=""),width=12,height=8)
			# Now we plot our persp graph with colours like a heat map.
			#myPersp <- persp(x=as.numeric(tXseq),y=as.numeric(tYseq),z=tMean, theta=150,phi=30, col=fcol, xlim=c(min(as.numeric(tXseq)),max(as.numeric(tXseq))), ylim=c(min(as.numeric(tYseq)),max(as.numeric(tYseq))), xlab = "Proportion of identical positively correlated pairs", ylab = "Percent of total site pairs as negatively correlated pairs", zlab = "Mean p-value (-log10)", ticktype="detailed")	
			
			tXY <- expand.grid(as.numeric(tXseq),as.numeric(tYseq))
			myCont <- kde2d(x=tXY[,1],y=tXY[,2],h=tMean, n= c(nrow(tMean),ncol(tMean)), lims= c(c(min(as.numeric(tXseq)),max(as.numeric(tXseq))),c(min(as.numeric(tYseq)),max(as.numeric(tYseq)))))
			image(myCont, zlim = c(min(tMean),max(tMean)))
			# Now we add the plane which represents our p_Value of 0.05 threshold, this will allows us to visually identify values ranges of significance
			# This will be done by creating a persp plane at the -log(0.05,10) level
			#for (x in as.numeric(as.character(tXseq))){
			#	lines(trans3d(x,c(min(as.numeric(as.character(tYseq))),max(as.numeric(as.character(tYseq)))),z=-log(0.05,10),pmat=myPersp),col="black")
			#}
			#for (y in as.numeric(as.character(tYseq))){
			#	lines(trans3d(c(min(as.numeric(as.character(tXseq))),max(as.numeric(as.character(tXseq)))),y,z=-log(0.05,10),pmat=myPersp),col="black")
			#}
			# Now we wish to add a line that shows the cut-off point of significance
			dev.off()
		}
	}
}

#################################################################################################
##################################  playground  #################################################
#################################################################################################
# This is an area for writting small pieces of code to test before integration or modification of working pieces.
