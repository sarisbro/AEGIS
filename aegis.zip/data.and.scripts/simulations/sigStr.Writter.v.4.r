# This is created to build all the necessary files and folders that will be part of my
# Simulation studies of epistatic recovery.  This version is created to generate the pair value combinations for
# each given job and then create a folder into which each will sit

# File naming structure follows A#_B#_C#_D# where they represent the number of pair values of (1,1),(0,0),(1,0),(0,1)
# respectively

# This is for MasterSigStr.v.2.r or later

# This is where all the new folders and files hould be created
wDir <- "/Users/Jdench/Desktop/SimulationRuns/PhaseSims/Pilots/sigStr/"
setwd(wDir)

# This reads in the Master Run Script file as an object to be later used
mFile <- readLines("MasterSigStr.v.2.r", -1)
# This is a simple object which defines the name of the Phase control files we want to copy
mControl <- "Sim_Phase_Control.sim"

################ These are optional parameters I can define here to more easily change whne writting files ###############
# This is an object for defining which system these jobs are intended to be run upon.
# 1 - Aleph, 2- HPCVL, anything else is interpreted as local machine, we use 0 as convention,
# Note local machine is null at present as my shell is not setup with a queue to be submitted toward.
# However, this script could still be used to create the folders
mSystem <- 2
# This is if we want to redefine the number of epistatic paris to be simulated
mPairs <- 1
# This is to help in defining the sequence length
mseqLen <- 2
# This is to help in defining the number of replicates tob edone
mReps <- 500
# This variable used when multiple file pathing structures exist across varying systems
mAcc <- 1
##########################################################################################################################

# These are some objects that should not be varried to maintain consistency, any changes here must be recorded and affects how we may
# cycle through combinatory analysis later on.

# This is required to prevent R from taking 0.0005 and making it into scientific notation, which INDELible can't use
options("scipen"=100, "digits"=6)
# These are used to interpret certain objects that are factors in our simulation but do not follow a simple 
# arithmetic series.  Usefull since we loop through simple series' to create our names and files\folers.
mLen <- c("0.0005", "0.001", "0.005", "0.01", "0.05", "0.1","0.00025","0.00075", "0.0025", "0.0075", "0.025", "0.075")
# These are kept as multiples of two in order to facilitate all tree types to be simulated
# NOTE: With tree type3 (user data) these are not factors!
mDer <- c(16,32,64,128)
# this is no longer a factor being considered in our experimentation
mOut <- 0

# this is used to handle the location where R exists, not mSystem !=1,2 are null as we wouldn't submit jobs in this way
if (mSystem == 1){
    rDir <- "/export/apps/R-3.1.1/bin/"
}else if (mSystem == 2){
	if (mAcc == 1) {rDir <- "/home/hpc3058/bin/R-3.1.2/bin/"}
	else if (mAcc == 2){rDir <- "/home/hpc3058/bin/R-3.1.2/bin/"}
	else if (mAcc == 3){rDir <- "/home/hpc3058/bin/R-3.1.2/bin/"}
}else{
    rDir <- ""
}

# For this writter we will be working with a number of objects that are different from a normal sim run, but for convenience we 
# will simply define certain aspects now used downstream in writting out .r Master file
l <- 4
d <- 2
o <- 1
tr <- 1
e <- 1

######## THESE ARE SOME PARAMETERS WHICH CAN BE SET WITH treeType == 3 ###############
# These define name of the user tree file and the outgroup sequences therein, called by their label.
# NOTE this tree must be present in the wDir folder as indicated in this script!
mtPath <- paste('"','JDett_Original.tree"',sep="")
mtOut <- 'c("S1","S3","S6","S8")'



# we create new working directories for each tree type and number of sequence combinations, into which we will be putting equivalent jobs
for (tr in 1:2){
	for (d in mDer[4]){
		system(paste("mkdir -p /Users/Jdench/Desktop/SimulationRuns/PhaseSims/sigStr/T",tr,"_D",d,sep=""))
		wDir <- paste("/Users/Jdench/Desktop/SimulationRuns/PhaseSims/sigStr/T",tr,"_D",d,"/",sep="")
		setwd(wDir)
		####### STRUCTURE OF THE NOMENCLATURE FOR RUNS ##############
		# A - This is the number of (1,1) pair values we will include
		# B - This is the number of (0,0) pair values we will include
		# C - This is the number of (1,0) pair values we will include
		# D - This is the number of (0,1) pair values we will include'
		
		# In all we will be looking at a series of 32 sequences, so we need to simulate no more than 32 of these pairs, and from
		# initial observations if we have more than ~5 pair values that are 0,1 or 1,0 we should not get FDR recovery,
		# Thus we will have A+B = 22->31 and C+D = 1->10, within each of these we want to vary the number of each type
		# so p+q = 1 = r+s, we will step by 0.1 for p+q and 0.2 for r+s, and then create new jobs when we have different values of
		# each A, B, C and ,D to run.  Each job will be replicated 500 times to shuffle placement of these pair values into rows
		# this should remove the shape and structure of the tree from our relative strength considerations
		
		# We will use p+q = 1 and r+s = 1 and create series of these pairs to generate our job groups, where
		# these letters represent the proportion of total for A->D respectively
		pSeq <- seq(0,1,by=0.1)
		rSeq <- seq(0,1,by=0.2)
		
		# We create sequences of the AB and CD number pairs in order to run through combinations
		# We want to look at all combinations of AB being between 69-99% of total, this means a minimum
		# of 10 possibilities for CD values when nSeq = 32		
		AB <- floor(d*seq(0.69,0.99,by=0.03))
		
		# This is a small funciton which when presented with a value that is .5 will return a vector of values 
		p05 <- function(aNum){
			aChar <- as.character(aNum)
			if (substr(aChar,nchar(aChar),nchar(aChar))=="5"){
				# Now we will generate a vector of two integers to output
				aNum <- c(floor(aNum),ceiling(aNum))
			} else { 
				aNum <- round(aNum)
			}
			return(aNum)
		}
		
		# 0.4 and 0.6 so that a round funciton will create one scenario of going up and down
		#############################################################
		
		# This will run through all parameter permutations and create the approrpiate files
		# NOTE: When changing a specific line, the index number should be the Smultron line number +1 (from experience)
		
		# These objects will be used to generate vectors of equal length which will be our job values
		numA <- numB <- numC <- numD <- 0
		
		for (ab in 1:length(AB)){
			cd <- (d-AB[ab])
			for (p in pSeq){
				for (r in rSeq){
					# Now we will start creating nuerical values four our jobs
					numA <- c(numA,p05(AB[ab]*p))
					numB <- c(numB,(AB[ab]-p05(AB[ab]*p)))
					numC <- c(numC,p05(cd*r))
					numD <- c(numD,(cd-p05(cd*r)))
					# Now we evaluate if either the numC or numA values just had a double addition, in which case we will replicate 
					# the corresponding pair, unless both had a repeated value.  This is done most simply by looking at if the length
					# of the numA is larger than numC, which ever is longer has one additional value and so we double the other
					if (length(numA) > length(numC)){
						# Then we double the last value of numC and numD
						numC <- c(numC, numC[length(numC)])
						numD <- c(numD, numD[length(numD)])
					} else if (length(numA) < length(numC)){
						# Then we double the last value of numA and numB
						numA <- c(numA, numA[length(numA)])
						numB <- c(numB, numB[length(numB)])
					}
				}
			}
		}
		
		# sanity check
		numsMat <- matrix(c(numA[-1],numB[-1],numC[-1],numD[-1]),nrow=4,byrow=TRUE)
		# sanity check, this takes the columnar sum, which should at all times be 32, thus the mean should be 32
		#cde <- apply(numsMat,2,function(x){print(sum(x))})
		#mean(cde) 
		
		# Now we introduce our siteID building function to remove non-novel combinations from this matrix
		all_identical <- function(v) all(sapply( as.list(v[-1]),FUN=function(z) {identical(z, v[1])}))
		# Initialise our variables for use, the simptMat is used in a comparative means
		simptMat <- matrix(nrow = nrow(numsMat), ncol = ncol(numsMat)) 
		siteID <- list()
		nb_site_patterns <- 0
		numMono <- 0
		for(j in 1:ncol(numsMat)){
		    if(!(all_identical(numsMat[,j]))){ # then this site is polymorphic
		        # test if site pattern is a new one
		        if(nb_site_patterns >= 1){
		            # first we need to parse recorded site patterns to test if at least one is new
		            nb_nonidentical_site_patterns <- 0
		            for(i in 1:nb_site_patterns){
		            	# Is the current site pattern (numsMat[,j] already in the list of recorded unique sites?
		            	# If this current site pattern is not presented anywhere then nb_non_identical will be < nb_site_patterns
		                if(sum(abs(simptMat[,i] - numsMat[,j]),na.rm=T) != 0){ 
		                    nb_nonidentical_site_patterns <- nb_nonidentical_site_patterns + 1
		                }
		            }
		            # if there are fewer nb_nonidentical_site_patterns than nb_site_patterns
		            # then the current pattern already exists
		            if(nb_nonidentical_site_patterns == nb_site_patterns){
		            	nb_site_patterns <- nb_site_patterns + 1
		                simptMat[,nb_site_patterns] <- numsMat[,j]               
		                siteID[[nb_site_patterns]] <- j # indexing the sites
		            }
		        # If nb_site_patterns is not yet more than 0 this is our first pattern
		        }else{ 
		        	# basically if(j =< 1), the first polymorphic site in simptMat is always a new site pattern
		        	nb_site_patterns <- 1
		            simptMat[,nb_site_patterns] <- numsMat[,j]
		            siteID[[nb_site_patterns]] <- j
		        }
		    # We want a way to count the number of monomorphic sites that exist, since they are not calculated we remove
		    # this many sites from seqLen with respect to calculating false negatives in post analysis    
		    } else {
		    	numMono <- numMono + 1
		    }
		}
		
		# We create our built matrix that will be used to generate runs
		builtMat<- matrix(mapply(FUN=function(x){return(as.numeric(x))},simptMat[,1:length(siteID)]),nrow=nrow(numsMat),ncol=length(siteID))
		
		# We will save the relevant matrices generated here in case we need them latter for bookeeping
		save(builtMat,numsMat,file=paste(wDir,"Job_Matrices.RData",sep=""))

		# Now all we do is create a job folder for each column of numsMat using each row as A,B,C,D respectively
		# In the event of any repetition this will simply cause the folder to be written anew with the same information
		for (j in 1:ncol(builtMat)){
			# The c(rep,rep,rep,rep,rep,....) uses the numsMat values to generate what will be, in matrix form bycolumn, the site pattern
			# we mean to represent
			sitePattern <- matrix(c(rep(1,builtMat[1,j]),rep(0,builtMat[2,j]),rep(1,builtMat[3,j]),rep(0,builtMat[4,j]),rep(1,builtMat[1,j]),rep(0,builtMat[2,j]),rep(0,builtMat[3,j]),rep(1,builtMat[4,j])),ncol=2)
			
			# we define our a,b,c,d values for this run
			tA <- builtMat[1,j]
			tB <- builtMat[2,j]
			tC <- builtMat[3,j]
			tD <- builtMat[4,j]
			rName <- paste("A",tA,"_B",tB,"_C",tC,"_D",tD,sep="")
			system(paste("mkdir -p ", wDir, rName))
			# Special to this signal strenght simulation scenario we will want to save the sitePattern we generated
			save(sitePattern,file=paste(wDir, rName,"/sitePattern.RData",sep=""))
			
			# This creates the job's specific submit file, at pressent if it's not on Aleph it's going to HPCVL, local machine doesn't need submits....
			if (mSystem !=2){
				cat(paste("qsub -N T",tr,"A",tA,"B",tB,"C",tC,"D", tD," -pe orte 4 -cwd -j y -b y ",rDir,"R CMD BATCH Master",rName,".r", sep=""), file= paste(wDir, rName, "/Sub", rName, ".sh", sep=""), append=TRUE)
			} else {
				# the reason for the difference on HPCVL is to request a specific queue where x86 architecture is supported.
				cat(paste("qsub -q abaqus.q -N T",tr,"A",tA,"B",tB,"C",tC,"D", tD," -pe dist.pe 4 -cwd -j y -b y ",rDir,"R CMD BATCH Master",rName,".r", sep=""), file= paste(wDir, rName, "/Sub", rName, ".sh", sep=""), append=TRUE)
			}
			# Must make the shell files executable for the runs to work, gives permissions to all users
			system(paste("chmod a+x ", wDir, rName, "/Sub", rName, ".sh", sep=""))
			
			# This create the Master submit job file, one for each D,O and T, each master will represent 12 jobs (E x L)
			# This adds all the job calls to the MasterSubmit job file
			cat(paste("cd ../", rName, sep=""), file= paste(wDir, "MasterSubmission.sh", sep=""), append=TRUE, sep="\n")
			cat(paste("./Sub", rName, ".sh", sep=""), file= paste(wDir, "MasterSubmission.sh", sep=""), append=TRUE, sep="\n")
			
			
			# This writes the Master R file which will execute the run
			mFile[35] <- paste("nReps <- ", mReps, sep="")
			mFile[36] <- paste("seqLen <- ", mseqLen, sep="")
			# We multiply the number of ePairs by e, since e controls if this will be zero or have epistasis
			mFile[38] <- paste("ePairs <- ", mPairs*e, sep="")
			mFile[45] <- paste("sEpi <- ", e, sep="")
			mFile[49] <- paste("wSystem <- ", mSystem, sep="")
			# Here we make the account based adjustment for HPCVL locations, where mAcc == 1, jonathan; mAcc == 2 Stephane's
			if (mAcc == 1){
				# For jonathan's account this is the folder system
				mFile[59] <- '    bDir <- "/home/hpc3058/jonathan/"'
				mFile[60] <- '    phaseLoc <- "/home/hpc3058/bin/phase2.0/"'
				mFile[61] <- '    bayesLoc <- "/home/hpc3058/bin/BayesTraitsV2/"'
			} else if (mAcc == 2){
				# for Stephane's account this is the folder system
				mFile[59] <- '    bDir <- "/home/hpc3028/jonathan/"'
				mFile[60] <- '    phaseLoc <- "/home/hpc3028/bin/phase2.0/"'
				mFile[61] <- '    bayesLoc <- "/home/hpc3028/bin/BayesTraitsV2/"'
			} else if (mAcc == 3){
				# for Stephane's account this is the folder system
				mFile[59] <- '    bDir <- "/home/hpc3060/jonathan/"'
				mFile[60] <- '    phaseLoc <- "/home/hpc3060/bin/phase2.0/"'
				mFile[61] <- '    bayesLoc <- "/home/hpc3060/bin/BayesTraitsV2/"'
			}
			mFile[71] <- paste('wDir <- "SimulationRuns/PhaseSims/Pilots/sigStr/T',tr,'_D',d,'"',sep="")
			mFile[73] <- paste('xDir <- "', rName,'" ',sep="")
			mFile[92] <- paste("nDer <- ", d, sep="")
			mFile[94] <- paste("nOut <- ", mOut[o], sep="")
			mFile[100] <- paste("bLen <- ", mLen[l],sep="")
			mFile[103] <- paste("treeType <- ", tr, sep="")
			
			# Here we set the treetype3 specific items
			if (tr == 3){
				mFile[106] <- paste("treePath <- ", mtPath, sep="")
				mFile[109] <- paste("treeOut <- ", mtOut, sep="")
			}
			# We now write out the Master.r script for this particular run
			writeLines(mFile, paste(wDir, rName, "/Master",rName,".r", sep=""))
			# This copies a phase control file into the proper directory, we don't need a control file in these runs
			#system(paste("cp ",wDir,mControl," ",wDir,rName,sep=""))
		}
		
		# This fixes the first job called in each MAsterSubmit file 
		mSub <- readLines(paste(wDir, "MasterSubmission.sh", sep=""),-1)
		# This will always be the first job called from any run since we bundle Master files by branch length
		mSub[1] <- paste("cd A",builtMat[1,1],"_B",builtMat[2,1],"_C",builtMat[3,1],"_D", builtMat[4,1], sep="")
		writeLines(mSub, paste(wDir, "MasterSubmission.sh", sep=""))
		# Must make the shell files executable for the runs to work
		system(paste("chmod a+x ", wDir, "MasterSubmission.sh", sep=""))
	}
}
