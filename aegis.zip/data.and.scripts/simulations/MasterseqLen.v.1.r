# This will be the master file that combines all portions previously written and considered
# condensed as a single run file uses script previously used written by:
# Main Author: Jonathan Dench -
# Contributing Authors: Jean-Claude N., Stephane Aris-Brossou for some historical portions not entirely re-written
# also their experience and support has helped produce this.

# This program is designed to detect epistasis at the SNP level from nucleotide sequences
# It considers an outgroup as being sequence(s) which have not experienced the selection
# of interest that may be creating epistasis (basically if the character state has not changed from the ancestral sequence simulated)

# load library to read alignments
library(ape)
library(seqinr)
library(doMC)
library(foreach)
# library(locfit) # This used to be used for certain plotting functions, but not at present.

# First clean the session to make certain there are no other objects or items loaded
# This removes any hidden previous session info
system("rm .RData")
# This also removes any objects
rm(list=ls())
# This is to accomodate when we are writting files with particularly small branch lengths, it ensures numbers are not written in scientific format.
options("scipen"=1000, "digits"=6)

###################################################################################################
################# BEGIN OF PREDEFINITIONS #########################################################
###################################################################################################
# This section includes those objects/variables that the user should predefine before running the script
# It is a convenient way to change the input output of many downstream files

############# Run Definitions ##############
# It would be best to have the nReps, nSeq, bLen items read in from user input, but I have not chosen to implement this.....
# The number of replicates to be performed and total sequence length desired
nReps <- 2
seqLen <- 30
# This defines the number of epistatic pairs that we want to simulate (Note 2 n.t will be simulate for each pair)
ePairs <- 3
# Here we create a list of the possible characters our n.t.s can take, ### Note: this is no longer in use, we replaced it with ntVec downstream
#nTs <- c("A", "C", "G", "T")
# These are vectors defining which characters are purines or pyrimidines, no longer implemented in this version
#transPur <- c("A","G")
#transPyr <- c("C","T")
# Here we define if this run will have epistasis simulated 1 = Yes, 0 = No
sEpi <- 1

############# System Definitions ##############
# which computer is this script intended to be run on  -- NOTE: this was circumstancial to our computer resources, most users would use 0
wSystem <- 0 	# 1: run on uOttawa SGE cluster, #2: run on HPCVL, any other value local machine
# define how many cores we will request with doPar
registerDoMC(cores=4)
# This is the root file path dependent on the location that a run is submitted.  Also wcAdj adjusts the wc value to report on data. ## NOTE You may find your local machine needs a different wcAdj value, this is based on how the BayesTraits output tables are written by your system
if (wSystem == 1){
    bDir <- "/export/home/jonathan/"
    phaseLoc <- "/export/home/jonathan/phase2.0/"
    bayesLoc <- "/export/apps/"
    wcAdj <- 1
}else if (wSystem == 2){
    bDir <- "/home/hpc3058/jonathan/"
    phaseLoc <- "/home/hpc3058/bin/phase2.0/"
    bayesLoc <- "/home/hpc3058/bin/BayesTraitsV2/"
    wcAdj <- 2
}else{
    bDir <- "/Users/Jdench/Desktop/"
    phaseLoc <- "/Users/Jdench/Desktop/Jonathan_Dench/3rd_Party_Software/phase-2.0-src/"
    bayesLoc <- "/Users/Jdench/Desktop/Jonathan_Dench/3rd_Party_Software/BayesTraitsV2-Beta-OSX/"
    wcAdj <- 1
}

# This is the working directory which should share the same filepath across all machines for ease of later compilation
wDir <- "SimulationRuns/PhaseSims/Pilots/"
# This sets the true working directory where a particular run will take place, NOTE this directory must exist (yes I could implement a mkdir -p call but I didn't)
xDir <- "ToyProof"

# We set a single object for the true working directory to save time on filepath calls later on.
trueWD <- paste(bDir,wDir,xDir, sep="")
# Create one subfolder for each replicate run that will be performed as indicated by nReps
for (d in 1:nReps) system(paste("mkdir -p ",trueWD,"/Rep",d,sep=""))
# set the working directory for R
setwd(trueWD)

############# Tree Definitions ##############
# This section is to define tree topology to be used, and key downstream information

# NOTE NOTE NOTE the read.tree might allow me to obtain most of this infor directly from tree file
# Thus I may be able to to set the tree type first and then read.tree to file out nSeq and or other tree info.

## NOTE: If using real data this must be known ##
# Define the number of dervied sequences this tree will hold
# NOTE: If treeType == 1 then this should be a multiple of 2 or the lowest multiple
# of two will correspond to how many sequences are generated.
nDer <- 32 
# Define the number of outgroup sequences this tree will hold
nOut <- 0
# This is the total number of sequences that will be in this tree
# Note this is subject to change as it may be re-evaluated once the tree is read
nSeq <- nDer + nOut
# bLen represents the length of branches and nodes which would all be the same, rDepth is the total root depth
rDepth <- 0.60
bLen <- 0.01
# This is an object that will have defined values to indicate if the tree to be used will be 
# 1 - symmetrical, 2 - pectinate, 3- predefined tree (ex: from real data)
treeType <- 1
###### USER TREE INFO ######### Only for treeType <- 3, otherwise downstream will change these values
# This is the filename of the user tree we want to load, note this tree must exist in each run base folder
treePath <- "JDett_Original.tree"
# This needs to be the branch labels which identify an outgroup sequences
# If these are not absolutely correct there will be downstream errors with proper analysis of derived state.
treeOut <- c("S1","S3","S6","S8")

###################################################################################################
################# END OF PREDEFINITIONS ###########################################################
###################################################################################################

###################################################################################################
###################### Start Definition of Functions ##############################################
###################################################################################################

# This function will determine the largest power of 2 that is less than the number entered
# This is only established to function with positive powers of 2.
sQrt <- function(vAlue){
	cOunt <- 0
	# If the value is less than 2 then we return this as 0 and stop
	if (vAlue >= 2){
		# Otherwise we know that this is at least a power of 2, this adjustment is needed 
		# as determined from practice
		cOunt <- 1
		# create a temporray value to compare against vAlue
		tmpNum <- 1
		while (tmpNum < vAlue){
			tmpNum <- tmpNum *2
			# This line account for when vAlue is larger than the current assesed power of 2
			# but not larger than that next value
			if (tmpNum *2 <= vAlue) { cOunt <- cOunt + 1 }
		}
		
	}
	return(cOunt)
}

# This will help us rebuild the true siteID once we have collapsed our traitMat into our builtMat
# Since we only analyse the builtMat, those sites we compare can each be equivalent to numerous other sites
# This scans each siteID value, and rebuilds that list[[]] into a list of all matching traitMat columns
trueSite <- function(siteList){
	trueList <- lapply(siteList,function(x){
		for (j in x:ncol(traitMat)){
			# If we find a matching column then we add it to the list of trueID's
			if (all(traitMat[,j] == traitMat[,x])) {x <- c(x, j)}
		}
		# The since we chekc the actual siteID traitMat column as the first value we must remove it afterward
		return(x[-1])
	})
	return(trueList)
}

# This is a function to take a list or vector and return a string of all the items separated by underscores
aString <- function(iVec){
	tmpVec <- NULL
	for (i in 1:length(iVec)){
		tmpVec <- paste(tmpVec,iVec[i],sep="_")
	}
	# Now we trim off the initial _ that get's placed
	tmpVec <- substr(tmpVec,2,nchar(tmpVec))
	return(tmpVec)
}

# This function will accept any site pattern matrix produced by the pipeline, entered as inpMat
# aLpha is the signficance alpha value to be considered
# s1Col, s2Col and pCol should be the column number of the inpMat column to identify proper columns
# to be used in calculations
postAnal <- function(inpMat, aLpha, s1Col, s2Col, pCol){
	### NOTE this postAnalysis accounts for true siteID's and is adjusted such that even though total # of comparisons
	# made is less than the presented FN, we are weighting all these values by the fact that the calculations are identical
	# across all comparisons of equal trueID, BUT not adjusted for the fact that monomorphic sites are not evaluated.
	
	############## Here we initialise certain objects for use downstream ########################
	# This will capture the name of the object passed into it, to be used in writting files
	objName <- deparse(substitute(inpMat))	
	# This dataframe will hold the summary information we care about
	sumMat <- data.frame("Rep"=tRep,"TP"=0, "FP"=0, "TN"=0, "FN"=0, "Num_ePairs"=ePairs,"All_ePairs"="", "IDed_TP"="", "Run_Time"=0, "p_Value"=0, "q_Value"=0, "Num_Comps"=0)
	# This will hold the rows at which we have significant sites as identified by pCol and aLpha		
	sigRow <- which(inpMat[,pCol] <= aLpha)
	# We can immediately assign the pValue and qValue since our inpMat will hold these, since we are only calling the FDR
	# The pCol is the qValue column and thus pCol -1 is the pValue column for the site 1 and site 2 comparisson	
	sumMat$p_Value <- inpMat[intersect(which(inpMat[,s1Col] == 1),which(inpMat[,s2Col] == 2)),(pCol -1)]
	sumMat$q_Value <- inpMat[intersect(which(inpMat[,s1Col] == 1),which(inpMat[,s2Col] == 2)),pCol]
	# Here we add in the number of pairwise comparissons that were made, this is measured as a function of the length of siteID
	sumMat$Num_Comps <- ((length(siteID)*(length(siteID)-1))/2)
	# The number of ePairs defines the total number of epistatic pairs we should find
	# and the first ePairs*2 positions in the sequence will be the pairs such that if ePairs = 3
	# the first six sites will be ePair sites and pairs are (1,2),(3,4),(5,6)
	# This will be a means of easily identifying hwich sites should be considered as significant
	if (sEpi == 1){
		# We create a list of all possible ePairs, but if we did not simulate epistasis this is null
		eSites <- c(1:(2*ePairs))
		for (e in 1:ePairs){
			# Since epistatic pairs are the sequential first ePair # of pairs we just combine 1 and 2 +
			# an adjustment of 2*(e-1) for the number of iterations we've done
			sumMat$All_ePairs <- paste(sumMat$All_ePairs,1+(2*(e-1)),".",2+(2*(e-1)),"_",sep="")
		}
		# We just tidy up sumMat$IDed_TP a bit by removing that last _
		sumMat$All_ePairs <- substr(sumMat$All_ePairs,1,(nchar(sumMat$All_ePairs)-1))
		# We identify the number of TP
		# To do this we scan the significant site pairs and confirm which are true positives
		for (r in sigRow){
			# If there is a epistatic site that was found we proceed
			if (length(intersect(trueID[[as.numeric(inpMat[r,s1Col])]],eSites)) > 0){
				# First identify the significant site identified
				sigSite1 <- intersect(trueID[[as.numeric(inpMat[r,s1Col])]],eSites)
				# Now we need to identify if the paired site is present, since each odd# is paried with the subsequent
				# even numbered position this becomes an easy calculation
				# We loop this calculation for each element of sigSite1
				sigSite2 <- sapply(sigSite1,function(x){
					if (x %% 2 == 0){
						# This means the number is even so we look to sigSite - 1
						return(x - 1)
					} else {
						# This means the number is odd so we look to sigSite + 1
						return(x + 1)
					}
				})
				if (length(intersect(trueID[[as.numeric(inpMat[r,s2Col])]],(sigSite2))) > 0){ 
					# We multiply the number of TP by the number of coordinated intersections there was between
					# This is identified by the length of the intersect between s2's trueID[[]] and the sigSite2 object
					# intersections
					sumMat$TP <- as.numeric(sumMat$TP) + 1*(length(intersect(trueID[[as.numeric(inpMat[r,s2Col])]],(sigSite2))))
					# Now to we store the trueID of the sigSite's that were recovered, this is done by taking the indexes of sigSite1 and sigSite2 which had intersections
					for (z in which(sigSite2==intersect(trueID[[as.numeric(inpMat[r,s2Col])]],(sigSite2)))){
						sumMat$IDed_TP <- paste(sumMat$IDed_TP,sigSite1[z],".",sigSite2[z],"_",sep="")
					}
				}			
			} 
		}
		# If no significant sites were found then there will be nothing written in IDed_TP so we handle this in two cases
		# First is when there were no sigRows
		if (length(sigRow)==0){sumMat$IDed_TP <- "None "}
		# The other is when there were not sigRows that had two properly paired sites meaning out identifier is blank
		if (sumMat$IDed_TP == ""){sumMat$IDed_TP <- "None "}
		# We just tidy up sumMat$IDed_TP a bit by removing that last _
		sumMat$IDed_TP <- substr(sumMat$IDed_TP,1,(nchar(sumMat$IDed_TP)-1))
	} else if (sEpi == 0){
		# There are no true positives thus we simply assign
		sumMat$IDed_TP <- "None"
		sumMat$All_ePairs <- "None"
		sumMat$TP <- 0
	}
		
	# Now we add a number of FP for the length of the trueID's that matches s1 and s2 within each sigRow and adjusting by simply subtracting the number of TP's
	# we simply loop throug each sigRow, take the length of the trueID[[]] at both site's and multiply them
	# One condition is that this calculation changes if sigRow is == 0, in which case FP simply equals 0, which is our default value
	if (length(sigRow) > 0){
		sumMat$FP <- sum(sapply(sigRow,function(r){
			as.numeric(sumMat$FP) + 1*(length(trueID[[as.numeric(inpMat[r,s1Col])]])*length(trueID[[as.numeric(inpMat[r,s2Col])]]))
		}))
		# This is the final adjustment of removing those TP we have found, however it is possible we found more TP than FP
		# in which case we simply leave the number false positives as 0.  Note this shouldn't be possible considering how we calculate FP
		# but this acts as a fail safe, such that if #TP is greater than #FP we leave the value as is (i.e. zero the initial value 
		if (as.numeric(sumMat$FP) >= as.numeric(sumMat$TP)){
			sumMat$FP <- as.numeric(sumMat$FP) - as.numeric(sumMat$TP)
		}
	}
	
	# We identify the number of FN, this is simply the total number of pairs possible - TP
	sumMat$FN <- ePairs - as.numeric(sumMat$TP)
	
	# We identify the number of TN, this is simply the number of comparrisons made that were not TP, FP or TN
	# The number of comaprisons made, in a pariwise system will be n(n-1)/2
	sumMat$TN <- ((seqLen-numMono)*(seqLen-numMono-1)/2) - sumMat$FN - sumMat$TP - sumMat$FP
	
	# The time taken to perform the BayesTraits Analysis, we round this to 3 decimal places
	sumMat$Run_Time <- round(sum(time_par1[1:5]), digits=3)
	
	# Here we write out files for latter batch analysis
	return(sumMat)
}
	
###################################################################################################
######################### End Definition of Functions #############################################
###################################################################################################

###################################################################################################
######################### Start of Tree Writting/Handling #########################################
###################################################################################################

# The first portion is for creating the tree topologies to be written out and latter used
# We will be creating ultrametric trees and providing files for the derived and outgroup
# portions respectively such that we can simulate outgroup sequences without the epistatic partition
if (treeType != 3){
	######################## TRUE TREE SIMULATION ##############################################
	# This portion generates the full simulate tree topology and some accessory tree files that 
	# may or may not be used, at present they are not (outgroup and dervied tree topologies which have
	# had their total branch lengths adjusted to mirror total full tree branch length
	if (treeType == 1){
		# This identifies the number of bifurcations we must run for outgroup and dervied sequences. 
		sqDer <- sQrt(nDer)
		# Here we take the rDepth and then adjust bLen to be a function of this value since that is the point
		# of the seqLen simulations, we add 1 to the sqDer value to include the root depth, which while not simulated within the tree
		# itself nor evaluated as evolutionary time in Phase, this has been the consistent means up to now.
		bLen <- rDepth/(sqDer +1)
		# This will build the basic object of tree Topology and I will copy it over for the number of symertical bifurcations, 
		# other than the outgroup, which is identified by the sqDer object (power of 2 i.e. 2^thereof)
		dTopology <- paste("(Leaf:",bLen,",Leaf:",bLen,"):",bLen, sep="")
		# This builds the dervied sequence's topology
		if (sqDer >= 2){
		# Here we take our topology object and for each iteration of dervied depth we insert the previous topology noded to itself
		# The structure basically is considered as (object,object):BranchLength
		    for (n in 1:(sqDer-1)){
		        dTopology <- paste("(",dTopology,",",dTopology,"):",bLen, sep="")
		    }
		} else if (sqDer == 1){
			# In this case there is nothing to change based on the current setup of dTopology
		} else if (sqDer == 0){
			# Here we simply create the open stub of 1 sequence that oTopology will build up properly
			# This situation is however quite unintersting
			dTopology <- paste("Leaf:",bLen, sep="")
		}
		# We need to make an adjustment to the final dervied length by one aditional node lenth
		# This is to represent the missing root point so we trim off the final bLen and add bLen*2 in it's place
		# NOTE this was mostly required only when dealing with a combination of outgroup and derived group sequences
		# As a single simulation tree this is not strictly required 
		fTopology <- paste(substr(dTopology,1,(nchar(dTopology)-nchar(as.character(bLen)))),bLen*2,";",sep="")
	} else if (treeType == 2){
		# Here we take the rDepth and then adjust bLen to be a function of this value since that is the point
		# of the seqLen simulations.
		bLen <- rDepth/(nSeq)
		# This is the simple pectinate topology structre we will use to build out comblike tree
		fTopology <- paste("(Leaf:",bLen,",Leaf:",bLen,sep="")  #,"):",bLen
		nTopology <- NULL
		# All we do not is just loop this basic structure for a number of times as we have sequences
		# and keep adding an additional basic topology, note we multiply the branch length by n so that 
		# this pectinate tree becomes and ultrametric one
		for (n in 1:(nSeq-2)){ 
			fTopology <- paste("(Leaf:",bLen*(n+1),",", fTopology,sep="") 
			# As a pectinate tree has all it's node on the exterior of all branch groupings we define the main
			# and node topologies separately and then just paste the two
			nTopology <- paste(nTopology,"):",bLen,sep="")
		}
		# We make that final paste of and fTopologies and close the structure with a root
		fTopology <- paste(fTopology,nTopology,");",sep="")
	}
	
	# The way we label our tree depends on the topology being used, so we create a labeling sequence
	# which accounts for treeType
	if (treeType == 1){
		# for symmetrical bifurcating trees we count upward
		lSeq <- (1:nSeq)
	} else if (treeType == 2){
		# For a pectinate tree we work backward.
		lSeq <- (nSeq:1)
	}
	
	# Now we need to add in the Leaf# for each of the Leaves that we have in the topology
	# the object "l" will be used to be our leaf number and thus we start it at 1
	for (l in lSeq){
	    fTopology <- sub("Leaf:",paste("Leaf",l,":",sep=""),fTopology)
	}
	# This is to write out the tree topologies we will use for simulation
	cat(fTopology, file= paste(trueWD,"/FullSimTree.tree",sep=""),append=FALSE)
	
	# This is the four above file names and is used to simplyfy downstream calls as when using a user tree
	# We would normally call that defined filename as entered in the Pre-Definitions section
	simPath <- c("FullSimTree.tree")
} else if (treeType == 3) {
	# If the tree is data defined then we simply read it 
	tTree <- read.tree(file=paste(bDir,wDir,treePath,sep=""))
	# Now we need to remove any multifurcations
	tTree_mod <- multi2di(tTree)
	# Now if there are any edge lengths that are too close to zero we set them to a minimal value
	tTree_mod$edge.length[tTree_mod$edge.length<.0001] <-.0001
	# Here we remove the node.labels which cannot be handled by either simulate or BayesTraits
	tTree_mod$node.label <- NULL # required by BayesTraits (no support values)
	# Now we write out our modified tree so that it can be used by the simulation program
	# In order to generate sequences 
	write.tree(tTree_mod, file= paste(trueWD,"/FullSimTree.tree",sep=""),append=FALSE)
	# We also write the tree in nexus format as BayesTraits requires this format for input
	write.nexus(tTree_mod, file = paste(trueWD,"/NexusSimTree.tree",sep=""))
	
	# We now update two previously defined variables based on the user input information 
	# Here we set the number of sequences based on the user data to ensure no errors from the above definitions
	nSeq <- length(tTree$tip.label)
	# Here we capture the labels as an object that can leter define which labels the tree contains
	tLabels <- tTree$tip.label
	# We trust that the outgroup sequences were properly identified and use the length of labels provided as 
	# the number of outgroups
	nOut <- length(treeOut)
	# The number of dervied sequences is thus the difference between the total and outgroup
	nDer <- nSeq - nOut	
	# Now we need to make an adjustment for the epistatic pairs to be simulated, this means taking the generated tree
	# and we will force the edge lengths to be a large value such that when generating paired sites there is a great chance
	# of one or at most two changes to occur, from experience and bionimial distribution 0.25 is best.
	tTree_epi <- tTree_mod
	# We preform the above described calculation and repeat it over the number of number of edge lengths to recreate all lengths
	tTree_epi$edge.length <- rep(0.25,length(tTree_epi$edge[,1]))
	write.tree(tTree_epi, file= paste(trueWD,"/EpiSimTree.tree",sep=""),append=FALSE)
	# This is an object with the name of the files we have generated for latter handling
	simPath <- c("FullSimTree.tree")
}
	
# Here we reload the FullTreeSim.txt item simPath[1] in order that we have our tree object loaded and 
# can write it out as a nexus formated object for Bayes traits
fTree <- read.tree(paste(trueWD,"/",simPath[1],sep=""))
write.nexus(fTree, file = paste(trueWD,"/NexusSimTree.tree",sep=""))

# If the tree is user input we will have already generated the list of labels If not then we need to generate a list of labels, 
if (treeType != 3){
	tLabels <- NULL
	# One label per sequence
	for (l in 1:nSeq){
		tLabels <- c(tLabels, paste("Leaf",l,sep=""))
	}
}

#########################################################################################
####### Brief interuption to write files not needed to be replicated ####################
#########################################################################################
# Here we write two simple control files for Bayes Traits to use downstream
# Here we write the control files for BayesTraits, where 1st string is model type: 
# 2 = Independent, 3 = Dependent, 2nd string is for MLE or Bayesian and 1 = MLE, 2 - Bayesian 
# 3rd string is to run the program
cat(paste("3","1","run", sep="\n"), file= paste(trueWD,"/InputBT_ML_dep.txt",sep=""), append=FALSE)
cat(paste("2","1","run", sep="\n"), file= paste(trueWD,"/InputBT_ML_indep.txt",sep=""), append=FALSE)

# Here we establish two data frames that will handle all our post analysis information
#analMat <- data.frame("Rep"=0,"TP"=0, "FP"=0, "TN"=0, "FN"=0,"Num_ePairs"=ePairs, "All_ePairs"="", "IDed_TP"="", "Run_Time"=0,"p_Value"=0, "q_Value"=0)
fdrMat <- data.frame("Rep"=0,"TP"=0, "FP"=0, "TN"=0, "FN"=0,"Num_ePairs"=ePairs, "All_ePairs"="", "IDed_TP"="", "Run_Time"=0,"p_Value"=0, "q_Value"=0, "Num_Comps"=0)
#########################################################################################
#########################################################################################

###################################################################################################
######################### End of Tree Writting/Handling ###########################################
###################################################################################################

# Now is where we need to start replciating our work for each replicate
for (tRep in 1:nReps){
	# We create a new path object which defines the current directory for this run
	curDir <- paste(trueWD,"/Rep",tRep,"/",sep="")
	
	
	###################################################################################################
	######################### Start of Control File Handling ##########################################
	###################################################################################################
	# This whole section can be moved out into the filewritter... think about it!
	
	# This section will take the simulate control file template provided in the bDir,wDir location
	# And then modify it as is appropriate based on the system and Tree type as well as other run parameters
	# A unique control file for each replicate exists such that if I need to control items within this but between
	# runs this can now be done (such as random seed) 
	mControl <- readLines(paste(trueWD,"/Sim_Phase_Control.sim",sep=""))
	
	# Since Phase uses computer speed and time to generate it's random seed, and the calls we will make are done
	# rather quickly we will instead identify the random seed as a number sampled using R
	mControl[27] <- paste("Random seed = ",sample(1:9999999,1),sep="")

	# This is how we modify if epistasis will be simulated or not, 1-yes, 0-no
	if (sEpi == 1){
		# This identifies the tree file location to be read
		mControl[32] <- paste("Tree file = ",trueWD,"/FullSimTree.tree",sep="")
		# in phase's simulate this identifies independent elements
		mControl[8] <- "    Model = REV"
		mControl[9] <- "    Discrete gamma distribution of rates = yes"
		mControl[10] <- "    Number of gamma categories = 4"
		# This identifies where the model information file is stored which should be universal to thus stored in bDir,wDir
		mControl[16] <- paste("Model parameters file = ",bDir,wDir,"REV.mod",sep="")
		mControl[47] <- "Structure for the elements of class 1 = ."
		# These identify the number of sequence elements that need to be written where class 1 are the independent sites
		# and class 2 are the paired sites.
		mControl[43] <- paste("Number of symbols from class 1 = ",(seqLen-2*ePairs),sep="")
		mControl[74] <- paste("Number of nucleotides from class 1 = ",(seqLen-2*ePairs),sep="")
		mControl[50] <- paste("Output file = ",curDir,"FullSim_MSeq.dna",sep="")
		# We can now write back out our control file as it has been properly adjusted for this run
		writeLines(mControl,paste(curDir,"Epi_REV_MSeq.sim",sep=""))
		
		# This identifies the tree file location to be read
		mControl[32] <- paste("Tree file = ",trueWD,"/EpiSimTree.tree",sep="")
		# Now we repeat this again for the ePairs to have their own sequence but adjust for model parameters
		mControl[8] <- "    Model = RNA7D"
		mControl[9] <- "    Discrete gamma distribution of rates = no"
		mControl[10] <- "#    Number of gamma categories = 4"
		# This identifies where the model information file is stored which should be universal to thus stored in bDir,wDir
		mControl[16] <- paste("Model parameters file = ",bDir,wDir,"RNA7D.mod",sep="")
		mControl[47] <- "Structure for the elements of class 1 = ()"
		# These identify the number of sequence elements that need to be written where class 1 are the independent sites
		# and class 2 are the paired sites.  For so long as we simulate 
		mControl[43] <- "Number of symbols from class 1 = 1"
		mControl[74] <- "Number of nucleotides from class 1 = 2"
		# Now we will write out a separate control file for each ePair to be made, in this way we only read and write
		# at one stage and this will handle the multiple simulation instances we are trying to accomplish
		for (i in 1:ePairs){
			# We generate new random seeds for each ePair simulation
			mControl[27] <- paste("Random seed = ",sample(1:9999999,1),sep="")
			# We writeout a unique control file for each ePair to be simulated
			mControl[50] <- paste("Output file = ",curDir,"FullSim_E",i,"Seq.dna",sep="")
			# We can now write back out our control file as it has been properly adjusted for this run
			writeLines(mControl,paste(curDir,"Epi_RNA7D_Seq",i,".sim",sep=""))
		}
	} else if (sEpi == 0){
		# This identifies the tree file location to be read
		mControl[32] <- paste("Tree file = ",trueWD,"/FullSimTree.tree",sep="")
		# If there is no simulated epistasis we can simply just simulate the whole sequence and avoid downstream 
		# concatenation, this will save computational time.
		# in phase's simulate this identifies independent elements
		mControl[8] <- "    Model = REV"
		mControl[9] <- "    Discrete gamma distribution of rates = yes"
		mControl[10] <- "    Number of gamma categories = 4"
		# This identifies where the model information file is stored which should be universal to thus stored in bDir,wDir
		mControl[16] <- paste("Model parameters file = ",bDir,wDir,"REV.mod",sep="")
		# in phase's simulate this identifies independent elements
		mControl[47] <- "Structure for the elements of class 1 = ."
		# These identify the number of sequence elements that need to be written where class 1 are the independent sites
		# and class 2 are the paired sites.
		mControl[43] <- paste("Number of symbols from class 1 = ",(seqLen),sep="")
		mControl[74] <- paste("Number of nucleotides from class 1 = ",(seqLen),sep="")
		mControl[50] <- paste("Output file = ",curDir,"FullSim_MSeq.dna",sep="")
		# We can now write back out our control file as it has been properly adjusted for this run
		writeLines(mControl,paste(curDir,"Epi_REV_MSeq.sim",sep=""))
	}
	
	###################################################################################################
	######################### End of Control File Handling ############################################
	###################################################################################################
		
	###################################################################################################
	######################### Start of Phase Simulation ###############################################
	###################################################################################################
	
	# We make the call to run simualte from phase package this calls simulate and as an argument provides the path
	# to the control file
	system(paste(phaseLoc,"simulate ",curDir,"Epi_REV_MSeq.sim",sep=""))
	# We don't actually need to simulate any epistatic pairs...
	#if (sEpi == 1){
	#	# If we are simulating epistasis then we will simulate one dinucleotide pair
	#	# for each ePair requested
	#	for (i in 1:ePairs){  
	#    	system(paste(phaseLoc,"simulate ",curDir,"Epi_RNA7D_Seq",i,".sim",sep=""))
	#	}
	#}
	
	###################################################################################################
	######################### End of Phase Simulation #################################################
	###################################################################################################
	
	###################################################################################################
	######################### Start of Sequence Concatenation and Treatment ###########################
	###################################################################################################
	
	# No matter wether or not we simulate epistasis we have to pull out our mainsequence so we can universaly load this.
	mseqFile <- readLines(paste(curDir,"FullSim_MSeq.dna",sep=""))
	# In the event that we are simulating the trees we need to quickly grab out the ancestral main sequence
	if (treeType != 3) {
		# Here we grab the main ancetral sequence from mseqFile, this is possible in this manner due to our current model and mask structure
		# and phase's standard output file types meaning the ancestral sequence is always found on line 15 of the file starting with a "#"
		mAnc <- substr(mseqFile[15],2,nchar(mseqFile[15]))
	}
	# We can immediately remove any lines that has a # in it as those are comment lines and the only ones that will
	# contain labels which could confuse our sequence search
	mseqFile <- mseqFile[-grep("#",mseqFile)]
	# Now we define a data.frame where we store the labels of our sequences
	mseqMat <- data.frame(Sequence=rep(NA,length(tLabels)),row.names=tLabels)
	# No we grab the main sequence associated to each of our labels
	mseqMat$Sequence <- sapply(rownames(mseqMat),function(x){
		# This finds any line that holds the sequence we are requesting, since if we are using numerical
		# termination then a 1, 11, 104, etc.. all look the same, thus what we really want is to find the line
		# which has the fewest characters and still matches our query, then we extract this line +1 == the sequence
		# This line reads, grep for x in our file then take the index of that response which corresponds to the smallest
		# matching string, thereby grabbing what should be the correct sequence.
		mseqFile[grep(x,mseqFile,fixed=TRUE)[which(nchar(mseqFile[grep(x,mseqFile,fixed=TRUE)]) == min(nchar(mseqFile[grep(x,mseqFile,fixed=TRUE)])))]+1]
	})
	
	# In the event we are simulating the trees (so not user defined) we will need to store and ancestral nt sequences for ePairs
	if (treeType != 3) {
		ancMat <- matrix(NA,ncol=seqLen,nrow=1)		
		# Now we fill the ancMat with the ancestral sequence as found in the mAnc from mseqFile[15]
		for (l in 1:nchar(mAnc)){
			# Here we will fill ancMat with the mAnc and maintain proper actual sequence position by adjusting for the number of 
			# nt reserved to be the ePair nts.
			# In the event we simulate epistasis we adjust ancMat seqeunce positions to leave room for ePairs, otherwise
			# we just fill for every sequence element, since no simulated epistasis is sEpi == 0 this works
			ancMat[1,(l+(ePairs*2*sEpi))] <- toupper(substr(mAnc,l,l))
		}
	}
	
	# If there is epistasis being simulated, this defines if we need to contate or not
	if (sEpi == 1){
		# Here we tack on the additional two values of 00 into our ancMat, this way if there is an intersect our values remain 0
		# else we will preserve our values of 1
		ancMat[1,c(1:(ePairs*2))] <- 0
		
		# Here we load our pre-written epistatic pair sites by the given filename and which should contain the object epiMat
		# Note this requires that the rownames of epiMat be a sequence of Leaf# from 1:nSeq, and that each column be a sitePair
		load(paste(trueWD, "/epiPattern",nDer,".RData",sep=""))
		# Now we define a data.frame where we store the labels of our sequences
		eseqMat <- epiMat
		# Now we need to concatenate all these items together
		mseqMat$Sequence <- sapply(rownames(mseqMat),function(x){
			tmpSeq <- mseqMat[x,"Sequence"]
			# We need to concatenate for each ePair that we have, we start with the last value such that
			# the first simualted pairs will be positions 1,2, second 3,4 etc....
			for (e in ePairs:1){
				tmpSeq <- paste(eseqMat[x,e],tmpSeq,sep="")
			}
			# Since we simulated the epistatic sites with RNA model there are U's where T's should be
			# now we simply will perform a gsub of U to being T
			tmpSeq <- gsub("U","T",toupper(tmpSeq))
			# Again if we are simulating a tree we need to fix the ancMat characters of U --> T
			return(tmpSeq)
		})
			# We change all U --> T in our ancestral Matrix, an object not used by treeType3
		if (treeType != 3) {
				# Here we will simply add nt sequentially to preserve their position and pairing
				ancMat <- gsub("U","T",toupper(ancMat))
		}
	}
	
	# Now we will write out our alignment as a fasta formatted file to simplify the downstream applications which
	# expect this type of input.  We will initialise the file then write out each sequence
	sapply(rownames(mseqMat),function(x){ write.fasta(mseqMat[x,"Sequence"],x,paste(curDir,"MrgdSeq_",xDir,"_Rep",tRep,".fas",sep=""),open="a")})
	
	save.image(paste(curDir,"step1.RData",sep=""))
	###################################################################################################
	######################### End of Sequence Concatenation and Treatment #############################
	###################################################################################################
	
	
	###################################################################################################
	######################### Start of traitMat and siteId Build ######################################
	###################################################################################################

    #Here we create matrices from our sequences which we convert to trait states
    # In this we compare if the current nucleotide considered is different from the ancestral sequence
    # This will represent derived state and will be represented by a 1, otherwise we assign a 0
    # If there was a gap in the sequence then assign a value of 2, to be used as either character in BayesTraits calc.
    # First we create a list of all the sequences and break them into single characters
	tmpList <- sapply(mseqMat$Sequence,function(x){strsplit(x,"")})
	# Now we prepare a matrix to take all the characters once modified to numbers based on our derived state
	# definition
	traitMat <- matrix(nrow = nSeq, ncol = seqLen)

	# We initialise our ntVec for comparison downstream
	ntVec <- c("A","C","G","T")
	# Here we go through a majority rule means of defining what is an outgroup sequence.  Where knowing the number of sequences
	# which we consider to be an outgroup we look at the nucleotides present at a given site, find which nucleotides are present
	# in at least 50% of the outgroup sequences and then define those as being ancestral.  This means that never more than 2 nucleotides
	# will be considered as outgroup\ancestral
	for (j in 1:seqLen){		
		# We only need to define the outgroup consensus against certain rows or the aligned seqence in the event
		# of this being a user tree, since at present we are not using nOut as a factor in simulated trees
		if (treeType == 3){
			# We need to reinitialise our counter for each site position
			ntCount <- rep(0,4)
			# Here we identify which rows are the outgroup rows 
			tmpRow <- sapply(treeOut,function(x){tmpRow <- which(rownames(mseqMat)==x)})
			# This will cycle through all the outgroup sequences and count the nt frequencies
			for (z in tmpRow){
				tmpRow <- NULL
				tmpRow <- sapply(treeOut,function(x){tmpRow <- c(tmpRow,which(rownames(mseqMat)==x))})
				# Count up the number of nucleotides found of a particular type, we use ntVec and ntCount as references
				# and take advantage that their index #s correspond in a meaningful fashion.
				ntCount[which(ntVec==toupper(tmpList[[z]][j]))] <- ntCount[which(ntVec==toupper(tmpList[[z]][j]))] + 1
			}	
			# Now we adjust the ntCount to find the 50% majority rule counts
			ntCount <- ntCount/nOut
			# We define an outgroup nucleotide as one which is at least 50% present
			outNT <- ntVec[which(ntCount >= 0.5)]
			for (i in 1:nSeq){
				# If there is a special character such as N or a gap "-" then we assign a value of 2
				if (toupper(tmpList[[i]][j]) == "N" || toupper(tmpList[[i]][j]) == "-") { traitMat[i,j] <- 2 }
				# If the nt in tmpList[[i]][j] does not match our outgroup nucleotides this is derived = 1
				else if (length(intersect(toupper(tmpList[[i]][j]),outNT)) == 0) {traitMat[i,j] <- 1} 
				# If the nt in tmpList[[j]][i] does match at least one of our outgroup nucleotides it is outgroup = 0
				else if (length(intersect(toupper(tmpList[[i]][j]),outNT)) > 0) {traitMat[i,j] <- 0}  
			}
		} else if (treeType != 3) {
			# in this case it is very simple we simply compare the tmpList[[i]][j] nt against the ancMat[j] nt.
			for (i in 1:nSeq){
				# If there is a special character such as N or a gap "-" then we assign a value of 2
				if (toupper(tmpList[[i]][j]) == "N" || toupper(tmpList[[i]][j]) == "-") { traitMat[i,j] <- 2 }
				# If the nt in tmpList[[i]][j] does not match our outgroup nucleotides this is derived = 1
				else if (toupper(tmpList[[i]][j]) != toupper(ancMat[1,j])) {traitMat[i,j] <- 1} 
				# If the nt in tmpList[[j]][i] does match at least one of our outgroup nucleotides it is outgroup = 0
				else if (toupper(tmpList[[i]][j]) == toupper(ancMat[1,j])) {traitMat[i,j] <- 0}  
			}		
		}
	}    
    
    # matrix simplification by removal of identical site patterns
    # siteId stores the first instance of a unique site pattern, in post analysis we will recover true site locations
    # using siteID and finding all identical columns from traitMat
    all_identical <- function(v) all(sapply( as.list(v[-1]),FUN=function(z) {identical(z, v[1])}))
    # Initialise our variables for use, the simptMat is used in a comparative means
    simptMat <- matrix(nrow = nSeq, ncol = seqLen) 
    siteID <- list()
    nb_site_patterns <- 0
    numMono <- 0
    
    for(j in 1:seqLen){
        if(!(all_identical(traitMat[,j]))){ # then this site is polymorphic
            # test if site pattern is a new one
            if(nb_site_patterns >= 1){
                # first we need to parse recorded site patterns to test if at least one is new
                nb_nonidentical_site_patterns <- 0
                for(i in 1:nb_site_patterns){
                	# Is the current site pattern (traitMat[,j] already in the list of recorded unique sites?
                	# If this current site pattern is not presented anywhere then nb_non_identical will be < nb_site_patterns
                    if(sum(abs(simptMat[,i] - traitMat[,j]),na.rm=T) != 0){ 
                        nb_nonidentical_site_patterns <- nb_nonidentical_site_patterns + 1
                    }
                }
                # if there are fewer nb_nonidentical_site_patterns than nb_site_patterns
                # then the current pattern already exists
                if(nb_nonidentical_site_patterns == nb_site_patterns){
                	nb_site_patterns <- nb_site_patterns + 1
                    simptMat[,nb_site_patterns] <- traitMat[,j]               
                    siteID[[nb_site_patterns]] <- j # indexing the sites
                }
            # If nb_site_patterns is not yet more than 0 this is our first pattern
            }else{ 
            	# basically if(j =< 1), the first polymorphic site in simptMat is always a new site pattern
            	nb_site_patterns <- 1
                simptMat[,nb_site_patterns] <- traitMat[,j]
                siteID[[nb_site_patterns]] <- j
            }
        # We want a way to count the number of monomorphic sites that exist, since they are not calculated we remove
        # this many sites from seqLen with respect to calculating false negatives in post analysis    
        } else {
        	numMono <- numMono + 1
        }
    }
    # This is to prevent a crash out in the circumstances where all sites are monomorphic
    # It will cause us to simply check the next replicate
    if(length(siteID) >= 2){
	    # Now we convert our reduced matrix into one that Bayes traits can use, so we assign the gap
	    # characters back which BayesTraits simply uses as either 0 or 1, and we make all value characters.
	    builtMat<- matrix(mapply(FUN=function(x){
	    	if(x == 2){
	        	return("-")
	        }else{
	        	return(as.character(x))
	        }
	    },simptMat[,1:length(siteID)]),nrow=nSeq,ncol=length(siteID))
	    ## Sanity check for debugging
	    #builtMat
	    
	    save.image(paste(curDir,"step2.RData",sep=""))
	    unlink(paste(curDir,"step1.RData",sep=""))
	    
	    ###################################################################################################
		######################### End of traitMat and siteId Build ########################################
		###################################################################################################
	    
	    ###################################################################################################
		######################### Start of BayesTraits Anaylis ############################################
		###################################################################################################
	    # parallel version 1
	    sp_names <- rownames(mseqMat)
	    
	    # initialize object containing results
	    pairAMat<- matrix(nrow=1,ncol=6)
	    # starts the clock
	    ptm <- proc.time()
	    # start the loops; only inner loop forks processes
	    for(i in 2:length(siteID)){
	        pairAMat_tmp <- foreach(j = 1:(i-1),.combine='rbind') %dopar% {
	            print(paste("Now doing pair of sites ",j," / ",i,sep=""))
	            #sp_names <- attributes(aln)$names
	            col1 <- col1bis <- builtMat[,j]
	            col2 <- col2bis <- builtMat[,i]
	            
	            # remove cols w/ "-" if there is an "-" in either site both sites are NAed
	            col1bis[which(col2bis=="-")] <- NA
	            col2bis[which(col2bis=="-")] <- NA
	            col2bis[which(col1bis=="-")] <- NA
	            col1bis[which(col1bis=="-")] <- NA
	            if(!identical(col1bis,col2bis)){
	                trait_data <- data.frame(sp_names, col1, col2)
	                colnames(trait_data) <- NULL
	                write.table(trait_data, paste(curDir,"traits.",i,".",j,".txt",sep=""),quote=F,row.names=F)
	                
	                # run BayesTraits under the dependent and indep models
	                ########### NOTE: The Input files InputBT_ML_indep.txt, InputBT_ML_dep.txt must be placed into each wd
	                system(paste(bayesLoc, "BayesTraits ",trueWD,"/NexusSimTree.tree ",curDir,"traits.",i,".",j,".txt < ", trueWD,"/InputBT_ML_indep.txt > ",curDir,"traits_res_indep.",i,".",j,".txt",sep=""))
	                system(paste(bayesLoc, "BayesTraits ",trueWD,"/NexusSimTree.tree ",curDir,"traits.",i,".",j,".txt < ", trueWD,"/InputBT_ML_dep.txt > ",curDir,"traits_res_dep.",i,".",j,".txt",sep=""))
	                
	                # extract likelihood values, by counting the # of lines in the traits_res_indep.i.j.txt file
	                system(paste("wc -l ",curDir,"traits_res_indep.",i,".",j,".txt > ",curDir,"wc",i,".",j,".txt",sep=""))
	                # This reads the wc file produce which should have simply the number of lines in the file
	                wc <- read.table(paste(curDir,"wc",i,".",j,".txt",sep=""))
	                # Since the last line in the "traits" file is the valuable output from ByesTraits, we skip wc[1] -1 lines, to read the last.
	                res_indep <- read.table(paste(curDir,"traits_res_indep.",i,".",j,".txt",sep=""),header=F,fill=T,skip=as.numeric(wc[1]-wcAdj))
	                # Repeat now for the dependent model
	                system(paste("wc -l ",curDir,"traits_res_dep.",i,".",j,".txt > ",curDir,"wc",i,".",j,".txt",sep=""))
	                wc <- read.table(paste(curDir,"wc",i,".",j,".txt",sep=""))
	                res_dep <- read.table(paste(curDir,"traits_res_dep.",i,".",j,".txt",sep=""),header=F,fill=T,skip=as.numeric(wc[1]-wcAdj))
	                # This adjustment is required only beacuse on the HPCVL server the traits_res_indep & _dep files contain an additional line
	                # after results section leading to a table read in with 2 rows, yet we only need to 1 row's value.
	                res_dep <- res_dep[1,]
	                res_indep <- res_indep[1,]
	                # cleanup tmp files releasing them from memory
	                unlink(paste(curDir,"traits_res_indep.",i,".",j,".txt",sep=""))
	                unlink(paste(curDir,"traits_res_dep.",i,".",j,".txt",sep=""))
	                unlink(paste(curDir,"traits.",i,".",j,".txt",sep=""))
	                unlink(paste(curDir,"traits.",i,".",j,".txt.log.txt",sep=""))
	                unlink(paste(curDir,"wc",i,".",j,".txt",sep=""))
	                unlink(paste(curDir,"traits.",i,".",j,".txt.log.txt.Schedule.txt",sep=""))
	                
	                # Since we expect our Bayes values to be negative this tests to assure us we are within expectations otherwise ignore
	                if((res_indep[,2] < 0) & (res_dep[,2] < 0)){
	                    # As this is a two sided test we multiply our test stat by two
	                    test_stat <- 2 * abs(res_indep[,2] - res_dep[,2])
	                    # this should be the last instruction of the foreach loop
	                    # This caculatees the significance of our Bayes Factor and other information in a vector
	                    return(c(j, i, res_indep[,2], res_dep[,2], test_stat, 1-pchisq(test_stat,4)))
	                }
	            }
	        }
	        # merge objects into pairAMatto build a memory of each bayesTraits run
	        print(paste("Sites ",i,j,sep=""))
	        print(pairAMat_tmp)
	        print(pairAMat)
	        pairAMat<- rbind(pairAMat, pairAMat_tmp)
	        print(pairAMat)
	    }
	    # Stop the clock
	    time_par1 <- proc.time() - ptm
	    
	    colnames(pairAMat) <- c("siteID_1","siteID_2","lkl_indep","lkl_dep","test_stat","pvalue")
	    pairAMat<- na.omit(pairAMat)
	    pairAMat<- data.frame(pairAMat)
	    
	    # FDR calculation, add actual site positions and sort by P-value
	    adj_p <- p.adjust(pairAMat$pvalue, "BH")
	    pairAMat_adj <- cbind(pairAMat, adj_p)
	    
	    colnames(pairAMat_adj) <- c(colnames(pairAMat), "pvalue_fdr")
	    pairAMat_adj_sorted <- pairAMat_adj[order(pairAMat_adj$pvalue),]
	    
	    # Here we rebuilt the list of all true SiteID's, since siteID only has the indexes of sites from builtMat (which is reduced in site length)
	    trueID <- trueSite(siteID)
	    
	    # We initialise two new columns that we will populate with trueIDs, I used to have a less explicit description for adding
	    # these two new columns, it seemed cleaner, but gotr rejected on HPCVL servers.  so this more cumbersome but explicit
	    # manner has been adopted.
	    pairAMat_adj_sorted <- cbind(pairAMat_adj_sorted,rep(0,nrow(pairAMat_adj_sorted)),rep(0,nrow(pairAMat_adj_sorted)))
	    colnames(pairAMat_adj_sorted) <- c("siteID_1","siteID_2","lkl_indep","lkl_dep","test_stat","pvalue","pvalue_fdr","true_S1","true_S2")
	    
	    # Now we add a few new column values to our dataframe with our trueID's
	  	for (s in 1:length(trueID)){
	  		# The if statements are to prevent a crash in the event there is no intersection
	  		# The actions taken are to assign strings of those trueId's which match the siteID's identified.  Done for site 1 and 2
	  		# We take advatage of the fact that siteID and trueID have the same length and the siteID's identified are by 1:length(siteID)
	  		# as defined by our builtMat column #'s
	  		if (length(which(pairAMat_adj_sorted$siteID_1==s))!=0){
	    		pairAMat_adj_sorted$true_S1[which(pairAMat_adj_sorted$siteID_1== s)] <- aString(trueID[[s]])
	  		}
	  		if (length(which(pairAMat_adj_sorted$siteID_2==s))!=0){
	    		pairAMat_adj_sorted$true_S2[which(pairAMat_adj_sorted$siteID_2== s)] <- aString(trueID[[s]])
	  		}

	  	}
	    
	    # write results to file
	    write.csv(pairAMat_adj_sorted, paste(curDir,"pairAMat_adj_sorted.csv",sep=""), quote=F, row.names=F) # relocated and set row.names to "F"
	    
	    save.image(paste(curDir,"step3.RData",sep=""))
	    unlink(paste(curDir,"step2.RData",sep=""))
	    ###################################################################################################
		######################### End of of BayesTraits Anaylis ###########################################
		###################################################################################################
	    
		###################################################################################################
		######################### Start of Post Analysis  #################################################
		###################################################################################################
		
		# Here we will run the post analysis for our two matrices of interest pairAMat, pairAMat_adj
		# And within those for the alpha value of interest
		
		# This is done because it was found when sEpi <- 0 and ePairs <- 0, somehow ePairs was being considered as <- 3
		# in final analysis, so here we are trying to force the situation to test where the issue is arising.
		#if (sEpi == 0){ePairs <- 0}
		
		#analMat <- rbind(analMat, postAnal(pairAMat,0.05,1,2,6))
		# In this script there is no value in looking at the preFDR values as being separated from the postFDR we will report on both values
		# in our output analysis .csv, the preFDR values should not be changing much
		fdrMat <- rbind(fdrMat, postAnal(pairAMat_adj,0.05,1,2,7))

	    save.image(paste(curDir,"step4.RData",sep=""))
	    unlink(paste(curDir,"step3.RData",sep=""))
	    ################################################################################################
	    ################################################################################################
	    # These are conditionals built up from siteID portion helping to step out of runs that are banal
	    # due to a lack of site patterns.
	    }else{
    		cat(paste("All but ", length(siteID), " site(s) is(are) monomorphic, no tests to run", sep=""), file=paste(curDir,"BanalRun.txt",sep=""), append = TRUE) 
	    }
# Now we write out our two post analysis matrices without the first initialising row
#write.csv(analMat[-1,], paste(trueWD,"/RunPostAnalysis.csv",sep=""), quote=F, row.names=F)
write.csv(fdrMat[-1,], paste(trueWD,"/RunPostAnalysis_FDR.csv",sep=""), quote=F, row.names=F)	   
}    

q(save="no")
